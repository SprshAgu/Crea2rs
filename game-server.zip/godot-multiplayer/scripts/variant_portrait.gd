extends Control
# Portrait widget that uses the exact same moving aura as combat creatures.
# It is only created for owned Blessed/Corrupt forms, never locked silhouettes.
const AURA_FX = preload("res://scripts/variant_aura_fx.gd")
var creature_texture: Texture2D
var variant_form: String = "normal"
var creature_tint: Color = Color.WHITE

func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	set_process(true)

func _process(_delta: float) -> void:
	if variant_form != "normal" and is_visible_in_tree():
		queue_redraw()

func _draw() -> void:
	if creature_texture == null:
		return
	var center := size * 0.5
	var radius := minf(size.x, size.y) * 0.385
	var elapsed := float(Time.get_ticks_msec()) * 0.001
	AURA_FX.draw_back(self, center, radius, variant_form, elapsed)
	draw_texture_rect(creature_texture, Rect2(Vector2.ZERO, size), false, creature_tint)
	AURA_FX.draw_front(self, center, radius, variant_form, elapsed)
