extends RefCounted

const OBSTACLE_COUNT := 230
const ROAD_CLEARANCE := 165.0
const SPAWN_CLEARANCE := 240.0

static func road_distance(point: Vector2, roads: Array) -> float:
	var distance := INF
	for road in roads:
		for index in range(road.size() - 1):
			distance = minf(distance, point.distance_to(Geometry2D.get_closest_point_to_segment(point, road[index], road[index + 1])))
	return distance

static func generate(world: Vector2, seed_value: int) -> Dictionary:
	var random := RandomNumberGenerator.new()
	random.seed = seed_value
	var center := world * 0.5
	var roads: Array[PackedVector2Array] = []
	# Four connected trails lead from the central clearing toward each map edge.
	var ends := [Vector2(-40, random.randf_range(world.y * 0.2, world.y * 0.8)),
		Vector2(world.x + 40, random.randf_range(world.y * 0.2, world.y * 0.8)),
		Vector2(random.randf_range(world.x * 0.2, world.x * 0.8), -40),
		Vector2(random.randf_range(world.x * 0.2, world.x * 0.8), world.y + 40)]
	for endpoint in ends:
		var road := PackedVector2Array([center])
		var across := (Vector2(endpoint) - center).normalized().orthogonal()
		for index in range(1, 7):
			var fraction := float(index) / 7.0
			var point := center.lerp(endpoint, fraction) + across * random.randf_range(-190.0, 190.0)
			road.append(point.clamp(Vector2(90, 90), world - Vector2(90, 90)))
		road.append(endpoint)
		roads.append(road)
	var props: Array[Dictionary] = []
	var obstacle_positions: Array[Vector2] = []
	# Jittered sectors spread candidates over the whole world, then extra samples
	# fill any sectors excluded by roads. Separation avoids overlapping bases.
	var candidates: Array[Vector2] = []
	for y in range(15):
		for x in range(20):
			candidates.append(Vector2((float(x) + random.randf_range(0.25, 0.75)) * world.x / 20.0,
				(float(y) + random.randf_range(0.25, 0.75)) * world.y / 15.0))
	# Use the local seeded RNG; Array.shuffle would use unrelated global state.
	for index in range(candidates.size() - 1, 0, -1):
		var other := random.randi_range(0, index)
		var temporary := candidates[index]
		candidates[index] = candidates[other]
		candidates[other] = temporary
	for attempt in range(12000):
		if obstacle_positions.size() >= OBSTACLE_COUNT:
			break
		var point := candidates[attempt] if attempt < candidates.size() else Vector2(random.randf_range(150, world.x - 150), random.randf_range(150, world.y - 150))
		if point.x < 320 or point.y < 320 or point.x > world.x - 320 or point.y > world.y - 320:
			continue
		if point.distance_to(center) < SPAWN_CLEARANCE or road_distance(point, roads) < ROAD_CLEARANCE:
			continue
		var separated := true
		for existing in obstacle_positions:
			if point.distance_squared_to(existing) < 190.0 * 190.0:
				separated = false
				break
		if not separated:
			continue
		obstacle_positions.append(point)
		props.append({"p": point, "kind": 0, "size": random.randf_range(0.8, 1.3)})
	# Flowers and low greenery retain the previous map's decoration density.
	for index in range(450):
		props.append({"p": Vector2(random.randf_range(320, world.x - 320), random.randf_range(320, world.y - 320)),
			"kind": 2 if random.randf() < 0.5 else 3, "size": random.randf_range(0.8, 1.3)})
	props.sort_custom(func(a: Dictionary, b: Dictionary) -> bool: return Vector2(a["p"]).y < Vector2(b["p"]).y)
	var patches: Array[Dictionary] = []
	for index in range(65):
		patches.append({"p": Vector2(random.randf_range(0, world.x), random.randf_range(0, world.y)),
			"radius": random.randf_range(90, 240), "tint": Color(0.16, random.randf_range(0.3, 0.44), 0.27, 0.2)})
	var grass: Array[Vector2] = []
	for index in range(90):
		grass.append(Vector2(random.randf_range(30, world.x - 30), random.randf_range(30, world.y - 30)))
	return {"props": props, "roads": roads, "patches": patches, "grass": grass}
