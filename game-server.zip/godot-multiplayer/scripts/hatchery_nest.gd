extends Control
# Lightweight pixel-like nest, braided grass and a speckled egg in Godot UI.
var has_egg := false
var pulse := 0.0

func setup(show_egg: bool) -> void:
	has_egg = show_egg
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST

func _process(delta: float) -> void:
	pulse += delta
	if has_egg and is_visible_in_tree():
		queue_redraw()

func _oval(center: Vector2, rx: float, ry: float, color: Color) -> void:
	var points := PackedVector2Array()
	for i in range(33):
		var angle := float(i) / 32.0 * TAU
		points.append(center + Vector2(cos(angle) * rx, sin(angle) * ry))
	draw_colored_polygon(points, color)

func _draw() -> void:
	var c := size * 0.5 + Vector2(0, 14)
	_oval(c + Vector2(0, 10), 58, 19, Color("2d2419"))
	_oval(c + Vector2(0, 5), 56, 18, Color("a77840"))
	_oval(c + Vector2(0, 2), 49, 13, Color("664726"))
	_oval(c + Vector2(0, 5), 35, 9, Color("3c331f"))
	for i in range(19):
		var a := float(i) * TAU / 19.0
		var p := c + Vector2(cos(a) * 42, sin(a) * 11)
		var q := p + Vector2(cos(a + 0.7) * 15, sin(a + 0.7) * 6)
		draw_line(p, q, Color("dcb770") if i % 3 == 0 else Color("79542c"), 3.0, false)
	if not has_egg:
		return
	var bob := sin(pulse * 2.2) * 1.2
	var ec := c + Vector2(0, -16 + bob)
	_oval(ec + Vector2(1, 11), 22, 24, Color("3b3429"))
	_oval(ec, 20, 27, Color("e9e9d7"))
	_oval(ec + Vector2(-5, -5), 13, 18, Color("faf6df"))
	_oval(ec + Vector2(9, 10), 5, 5, Color("98bbb8"))
	_oval(ec + Vector2(-9, 10), 3, 4, Color("8fa2c2"))
	_oval(ec + Vector2(6, -9), 2.5, 3.5, Color("c4d4bb"))
	draw_line(ec + Vector2(-8, -13), ec + Vector2(-3, -18), Color("ffffff"), 2.0)
