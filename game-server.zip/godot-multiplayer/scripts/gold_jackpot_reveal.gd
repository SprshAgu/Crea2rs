extends Control
# Slot-only Gold variant celebration, drawn procedurally so no animation assets
# are needed. Each Gold result gets its own instance (including duplicates).
signal reveal_finished

const AURA_FX = preload("res://scripts/variant_aura_fx.gd")
const ANIMATION_SECONDS := 4.3

var creature_texture: Texture2D
var creature_name := ""
var first_unlock := true
var duplicate_gold := 0
var pull_number := 1
var batch_size := 1
var queued_after := 0
var elapsed := 0.0
var finished := false

func setup(portrait: Texture2D, display_name: String, is_new: bool, payout: int, pull_index: int, total_pulls: int, still_queued: int) -> void:
	creature_texture = portrait
	creature_name = display_name
	first_unlock = is_new
	duplicate_gold = payout
	pull_number = pull_index
	batch_size = total_pulls
	queued_after = still_queued

func _ready() -> void:
	position = Vector2.ZERO
	size = Vector2(1152, 648)
	mouse_filter = Control.MOUSE_FILTER_STOP
	texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	set_process(true)
	_add_label("✦  GOLD JACKPOT!  ✦", Rect2(306, 116, 540, 59), 41, Color("ffe785"))
	_add_label("A LEGENDARY GOLD FORM APPEARED", Rect2(326, 173, 500, 29), 18, Color("ffefd1"))
	_add_label(creature_name.to_upper(), Rect2(305, 423, 542, 53), 35, Color("ffdc5b"))
	_add_label("MIDAS PERK  •  +50% GOLD PICKUP BONUS", Rect2(319, 471, 514, 28), 17, Color("fff1a6"))
	var status_text := "NEW GOLD FORM UNLOCKED!" if first_unlock else "DUPLICATE GOLD  •  +%d GOLD" % duplicate_gold
	_add_label(status_text, Rect2(316, 497, 520, 27), 16, Color("caffdc") if first_unlock else Color("ffe9ad"))
	var next_label := "NEXT GOLD REVEAL" if queued_after > 0 else "CONTINUE"
	var next_button := Button.new()
	next_button.text = next_label
	next_button.position = Vector2(460, 533)
	next_button.size = Vector2(232, 48)
	next_button.focus_mode = Control.FOCUS_NONE
	next_button.add_theme_font_size_override("font_size", 18)
	next_button.add_theme_color_override("font_color", Color("33200b"))
	for mode in ["normal", "hover", "pressed"]:
		var style := StyleBoxFlat.new()
		style.bg_color = Color("fff0a7") if mode == "hover" else Color("dca73d") if mode == "pressed" else Color("fbd55a")
		style.border_color = Color("fff5c8")
		style.set_border_width_all(3)
		style.corner_radius_top_left = 5
		style.corner_radius_top_right = 5
		style.corner_radius_bottom_left = 5
		style.corner_radius_bottom_right = 5
		next_button.add_theme_stylebox_override(mode, style)
	next_button.pressed.connect(_finish_reveal)
	add_child(next_button)
	_add_label("PULL %d / %d%s" % [pull_number, batch_size, "   •   %d GOLD REVEAL(S) FOLLOW" % queued_after if queued_after > 0 else ""], Rect2(305, 589, 542, 28), 13, Color("e8ca87"))

func _add_label(value: String, bounds: Rect2, font_size: int, tint: Color) -> void:
	var label := Label.new()
	label.text = value
	label.position = bounds.position
	label.size = bounds.size
	label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	label.add_theme_font_size_override("font_size", font_size)
	label.add_theme_color_override("font_color", tint)
	label.add_theme_color_override("font_outline_color", Color("321e0d"))
	label.add_theme_constant_override("outline_size", 3)
	add_child(label)

func _process(delta: float) -> void:
	elapsed += delta
	queue_redraw()
	if elapsed >= ANIMATION_SECONDS:
		_finish_reveal()

func _finish_reveal() -> void:
	if finished:
		return
	finished = true
	set_process(false)
	reveal_finished.emit()

func _draw() -> void:
	var intro := clampf(elapsed / 0.30, 0.0, 1.0)
	var fade := clampf((ANIMATION_SECONDS - elapsed) / 0.26, 0.0, 1.0)
	var opacity := intro * fade
	var center := Vector2(576, 316)
	# Darken the rest of the arcade so the actual rare result is the focus.
	draw_rect(Rect2(Vector2.ZERO, size), Color(0.035, 0.028, 0.075, 0.88 * opacity))
	# Expanding radial rays, oscillating halo rings and glittering embers.
	var pulse := 0.5 + 0.5 * sin(elapsed * 5.0)
	for i in range(28):
		var index := float(i)
		var direction := Vector2.RIGHT.rotated(TAU * index / 28.0 + elapsed * 0.32)
		var side := Vector2(-direction.y, direction.x)
		var inner := center + direction * 68.0
		var far := center + direction * (305.0 + 21.0 * sin(elapsed * 3.2 + index))
		var ray := PackedVector2Array([inner - side * 11.0, inner + side * 11.0, far + side * 5.0, far - side * 5.0])
		draw_colored_polygon(ray, Color(1.0, 0.72 + 0.13 * pulse, 0.20, 0.07 * opacity))
	for ring_i in range(3):
		var phase := fposmod(elapsed * 0.75 + float(ring_i) / 3.0, 1.0)
		var radius := lerpf(95.0, 265.0, phase)
		draw_arc(center, radius, 0.0, TAU, 64, Color(1.0, 0.82, 0.29, 0.21 * (1.0 - phase) * opacity), 4.0, true)
	for i in range(64):
		var index := float(i)
		var angle := TAU * index / 64.0 + sin(index * 4.7) * 0.28
		var distance := 60.0 + fposmod(elapsed * (57.0 + float(i % 7) * 10.0) + index * 17.3, 260.0)
		var sparkle := center + Vector2(cos(angle), sin(angle)) * distance
		var twinkle := 0.45 + 0.55 * absf(sin(elapsed * 5.7 + index * 2.3))
		var spark_size := (2.0 + float(i % 4) * 1.4) * twinkle
		var c := Color(1.0, 0.86 + 0.12 * twinkle, 0.38 + 0.4 * twinkle, 0.78 * opacity)
		draw_line(sparkle + Vector2(-spark_size, 0), sparkle + Vector2(spark_size, 0), c, 2.0, true)
		draw_line(sparkle + Vector2(0, -spark_size), sparkle + Vector2(0, spark_size), c, 2.0, true)
	# Beveled dark window and strong gold outline.
	var frame := Rect2(265, 79, 622, 517)
	draw_rect(frame, Color(0.06, 0.07, 0.14, 0.93 * opacity))
	draw_rect(frame, Color(0.99, 0.74, 0.19, 0.94 * opacity), false, 5.0)
	draw_rect(Rect2(278, 92, 596, 489), Color(1.0, 0.91, 0.55, 0.37 * opacity), false, 2.0)
	# A bright circular gilded spotlight behind the featured creature.
	draw_circle(center, 121.0 + pulse * 8.0, Color(1.0, 0.81, 0.22, 0.16 * opacity))
	draw_circle(center, 95.0, Color(1.0, 0.94, 0.47, 0.13 * opacity))
	AURA_FX.draw_back(self, center, 122.0, "gold", elapsed)
	# Showcase the actual gold-recolored portrait, enlarged with a pop-in bounce.
	if creature_texture != null:
		var progress := clampf(elapsed / 0.55, 0.0, 1.0)
		var overshoot := 1.0 + 0.16 * sin(progress * PI * 1.45) * (1.0 - progress)
		var scale_value := (0.64 + 0.36 * (1.0 - pow(1.0 - progress, 3.0))) * overshoot
		var picture_size := 207.0 * scale_value
		var float_offset := sin(elapsed * 3.0) * 3.0
		draw_texture_rect(creature_texture, Rect2(center.x - picture_size * 0.5, center.y - picture_size * 0.5 + float_offset, picture_size, picture_size), false, Color(1.0, 1.0, 1.0, opacity))
	AURA_FX.draw_front(self, center, 122.0, "gold", elapsed)
	# Fast first-frame white/gold flash and tiny fireworks near corners.
	var flash_strength := pow(maxf(0.0, 1.0 - elapsed / 0.38), 2.0)
	draw_rect(frame, Color(1.0, 0.94, 0.63, flash_strength * 0.48))
	for i in range(4):
		var pos := Vector2(316.0 + float(i % 2) * 520.0, 125.0 + floorf(float(i) / 2.0) * 417.0)
		var spark_radius := 7.0 + 3.5 * sin(elapsed * 6.0 + float(i))
		draw_line(pos + Vector2(-spark_radius, 0), pos + Vector2(spark_radius, 0), Color(1.0, 0.92, 0.5, 0.8 * opacity), 2.3, true)
		draw_line(pos + Vector2(0, -spark_radius), pos + Vector2(0, spark_radius), Color(1.0, 0.92, 0.5, 0.8 * opacity), 2.3, true)
