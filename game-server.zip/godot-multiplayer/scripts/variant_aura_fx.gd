extends RefCounted
# Shared procedural aura painter for world creatures and collection portraits.
# Calls are made from CanvasItem._draw(). Every shape is positioned relative
# to the creature so the effect follows movement without requiring particles.

static func draw_back(canvas: CanvasItem, center: Vector2, radius: float, form: String, elapsed: float) -> void:
	if form == "normal":
		return
	if form.contains("shiny"):
		canvas.draw_circle(center, radius * 1.12, Color(0.53, 1.0, 0.92, 0.09))
		canvas.draw_arc(center, radius * (1.03 + 0.025 * sin(elapsed * 2.7)), 0, TAU, 40, Color(0.7, 1.0, 0.91, 0.38), maxf(1.0, radius * 0.035), true)
		if form == "shiny":
			return
		form = "blessed" if form.contains("blessed") else "corrupt"
	var pulse := 0.5 + 0.5 * sin(elapsed * 2.8)
	if form == "blessed":
		# Gentle pearl / gold radiance, with rotating rays of light.
		canvas.draw_circle(center, radius * (1.14 + 0.035 * pulse), Color(0.78, 0.94, 1.0, 0.075))
		canvas.draw_circle(center, radius * 0.96, Color(1.0, 0.92, 0.64, 0.095))
		canvas.draw_circle(center, radius * 0.73, Color(1.0, 1.0, 0.87, 0.09))
		canvas.draw_arc(center, radius * (1.00 + 0.025 * pulse), 0.0, TAU, 40, Color(0.97, 0.97, 0.72, 0.27), maxf(1.4, radius * 0.055), true)
		for i in range(10):
			var angle := TAU * float(i) / 10.0 + sin(elapsed * 0.42) * 0.09
			var ray := Vector2(cos(angle), sin(angle))
			var inner := center + ray * radius * 0.83
			var outer := center + ray * radius * (1.20 + 0.13 * sin(elapsed * 2.4 + float(i)))
			canvas.draw_line(inner, outer, Color(1.0, 0.94, 0.67, 0.24 + pulse * 0.14), maxf(1.0, radius * 0.045), true)
	elif form == "gold":
		canvas.draw_circle(center, radius * (1.18 + 0.05 * pulse), Color(1.0, 0.84, 0.22, 0.10))
		canvas.draw_circle(center, radius * 0.98, Color(1.0, 0.93, 0.58, 0.12))
		canvas.draw_circle(center, radius * 0.76, Color(1.0, 0.98, 0.82, 0.08))
		canvas.draw_arc(center, radius * (1.05 + 0.03 * pulse), 0.0, TAU, 44, Color(1.0, 0.90, 0.38, 0.34), maxf(1.6, radius * 0.06), true)
		for i in range(12):
			var angle := TAU * float(i) / 12.0 + elapsed * 0.32
			var ray := Vector2(cos(angle), sin(angle))
			var inner := center + ray * radius * 0.78
			var outer := center + ray * radius * (1.14 + 0.12 * sin(elapsed * 2.1 + float(i)))
			canvas.draw_line(inner, outer, Color(1.0, 0.85, 0.24, 0.34 + pulse * 0.15), maxf(1.0, radius * 0.05), true)
	elif form == "ghost":
		# Cool translucent mist and shifting rings, blue rather than Corrupt purple.
		var rise := 0.5 + 0.5 * sin(elapsed * 1.75)
		canvas.draw_circle(center, radius * (1.19 + 0.07 * rise), Color(0.13, 0.56, 1.0, 0.075))
		canvas.draw_circle(center, radius * (1.04 + 0.035 * pulse), Color(0.35, 0.86, 1.0, 0.11))
		canvas.draw_circle(center, radius * 0.83, Color(0.52, 0.94, 1.0, 0.08))
		canvas.draw_arc(center, radius * (1.04 + 0.04 * pulse), 0.0, TAU, 40, Color(0.56, 0.91, 1.0, 0.36), maxf(1.3, radius * 0.045), true)
		canvas.draw_arc(center, radius * (1.22 + 0.05 * rise), 0.1, PI * 1.74, 36, Color(0.25, 0.72, 1.0, 0.19), maxf(1.1, radius * 0.025), true)
		for i in range(11):
			var theta := TAU * float(i) / 11.0 + elapsed * 0.22
			var direction := Vector2(cos(theta), sin(theta))
			var mist_pos := center + direction * radius * (0.9 + 0.23 * sin(elapsed * 1.7 + float(i)))
			mist_pos.y -= radius * (0.06 + 0.18 * (0.5 + 0.5 * sin(elapsed * 2.2 + float(i))))
			canvas.draw_circle(mist_pos, maxf(1.8, radius * 0.09), Color(0.42, 0.81, 1.0, 0.07 + 0.035 * rise))
	else:
		# Layered violet shadow and climbing demonic flame tongues.
		canvas.draw_circle(center, radius * (1.13 + pulse * 0.06), Color(0.33, 0.05, 0.66, 0.09))
		canvas.draw_circle(center, radius * 0.95, Color(0.52, 0.12, 0.88, 0.11))
		canvas.draw_circle(center, radius * 0.70, Color(0.64, 0.20, 0.98, 0.07))
		canvas.draw_arc(center, radius * (1.06 + pulse * 0.03), 0, TAU, 40, Color(0.63, 0.19, 0.92, 0.28), maxf(1.2, radius * 0.045), true)
		for i in range(11):
			var seed := float(i)
			var angle := TAU * seed / 11.0
			var direction := Vector2(cos(angle), sin(angle))
			var tangent := Vector2(-direction.y, direction.x)
			var wiggle := sin(elapsed * 3.0 + seed * 2.31)
			var anchor := center + direction * radius * 0.74
			var tip := center + direction * radius * (1.17 + 0.17 * wiggle) + Vector2(0, -radius * (0.10 + 0.11 * (0.5 + 0.5 * wiggle)))
			var width := radius * 0.16
			var flame := PackedVector2Array([anchor - tangent * width, tip, anchor + tangent * width, center + direction * radius * 0.58])
			canvas.draw_colored_polygon(flame, Color(0.46 + pulse * 0.10, 0.08, 0.78, 0.17 + 0.10 * (0.5 + 0.5 * wiggle)))

static func draw_front(canvas: CanvasItem, center: Vector2, radius: float, form: String, elapsed: float) -> void:
	if form == "normal":
		return
	if form.contains("shiny"):
		for s in range(7):
			var angle := elapsed * 0.6 + float(s) * TAU / 7.0
			var pos := center + Vector2(cos(angle), sin(angle)) * radius * 1.04
			canvas.draw_circle(pos, maxf(1.0, radius * 0.043), Color(0.72, 1.0, 0.95, 0.7))
		if form == "shiny":
			return
		form = "blessed" if form.contains("blessed") else "corrupt"
	for i in range(9):
		var index := float(i)
		var angle := TAU * (index / 9.0 + 0.028 * sin(elapsed * 0.8 + index))
		var reach := radius * (0.97 + 0.21 * sin(elapsed * 1.55 + index * 2.1))
		var position := center + Vector2(cos(angle), sin(angle)) * reach
		position.y -= radius * 0.12 * sin(elapsed * 1.8 + index * 2.9)
		if form == "blessed":
			var color := Color(1.0, 0.97, 0.72, 0.65 + 0.30 * (0.5 + 0.5 * sin(elapsed * 4.0 + index)))
			var sparkle_size := maxf(1.25, radius * (0.042 + 0.022 * sin(elapsed * 2.5 + index)))
			canvas.draw_line(position + Vector2(-sparkle_size * 2.1, 0), position + Vector2(sparkle_size * 2.1, 0), color, maxf(1.0, radius * 0.023), true)
			canvas.draw_line(position + Vector2(0, -sparkle_size * 2.1), position + Vector2(0, sparkle_size * 2.1), color, maxf(1.0, radius * 0.023), true)
			canvas.draw_circle(position, sparkle_size * 0.65, Color(1.0, 1.0, 0.92, 0.86))
		elif form == "gold":
			var ember := Color(1.0, 0.90, 0.42, 0.56 + 0.24 * (0.5 + 0.5 * sin(elapsed * 4.6 + index)))
			var coin_size := maxf(1.4, radius * (0.050 + 0.018 * sin(elapsed * 2.0 + index)))
			canvas.draw_circle(position, coin_size, ember)
			canvas.draw_circle(position, coin_size * 0.42, Color(1.0, 0.98, 0.78, 0.95))
			canvas.draw_arc(position, coin_size * 1.75, -PI * 0.3, PI * 1.2, 16, Color(1.0, 0.94, 0.62, 0.52), maxf(1.0, radius * 0.018), true)
		elif form == "ghost":
			# Wisps lift upward from the body, fading as they rise.
			var wisp := maxf(1.2, radius * (0.038 + 0.019 * sin(elapsed * 2.6 + index)))
			var blue := Color(0.55, 0.95, 1.0, 0.42 + 0.19 * (0.5 + 0.5 * sin(elapsed * 3.2 + index)))
			canvas.draw_circle(position, wisp, blue)
			canvas.draw_circle(position + Vector2(0, radius * 0.13), wisp * 0.46, Color(0.29, 0.72, 1.0, 0.36))
		else:
			# Rising purple embers/smoky droplets around the silhouette.
			var smoke_color := Color(0.77, 0.30, 1.0, 0.45 + 0.25 * sin(elapsed * 2.0 + index) * sin(elapsed * 2.0 + index))
			canvas.draw_circle(position, maxf(1.2, radius * (0.045 + 0.028 * (0.5 + 0.5 * sin(elapsed * 3.0 + index)))), smoke_color)
			canvas.draw_circle(position + Vector2(0, radius * 0.085), maxf(0.9, radius * 0.018), Color(0.91, 0.55, 1.0, 0.7))
