extends Control
# Rare death-only unlock: a tombstone emerges from the ground, cracks with
# spectral light, and the newly acquired creature's spirit rises out of it.
# Supplied tombstone artwork with the blue/translucent Ghost portrait.
signal reveal_finished

const AURA_FX = preload("res://scripts/variant_aura_fx.gd")
const TOMBSTONE_ART: Texture2D = preload("res://art/ghost_tombstone.png")
const TOMBSTONE_REGION := Rect2(197, 61, 918, 1085)
const TOMBSTONE_HEIGHT := 211.0 * 1.5

var ghost_portrait: Texture2D
var ghost_name := ""
var first_unlock := true
var elapsed := 0.0
var complete := false
var title_label: Label
var sub_label: Label
var name_label: Label
var status_label: Label
var continue_button: Button

func setup(portrait: Texture2D, display_name: String, is_new: bool) -> void:
	ghost_portrait = portrait
	ghost_name = display_name
	first_unlock = is_new

func _ready() -> void:
	position = Vector2.ZERO
	size = Vector2(1152, 648)
	mouse_filter = Control.MOUSE_FILTER_STOP
	texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	set_process(true)
	title_label = _add_label("☾   THE VEIL HAS OPENED   ☾", Rect2(175, 61, 802, 62), 36, Color("a5ecff"))
	sub_label = _add_label("FROM THE GRAVE, A NEW SPIRIT RISES", Rect2(235, 122, 682, 30), 18, Color("d7f6ff"))
	name_label = _add_label("GHOST " + ghost_name.to_upper(), Rect2(248, 492, 656, 45), 30, Color("d6f8ff"))
	status_label = _add_label("GHOST FORM PERMANENTLY UNLOCKED!" if first_unlock else "THE GHOST ANSWERS YOUR CALL AGAIN", Rect2(256, 533, 640, 30), 16, Color("9af7df"))
	continue_button = Button.new()
	continue_button.text = "RETURN TO DEATH REPORT"
	continue_button.position = Vector2(423, 575)
	continue_button.size = Vector2(306, 49)
	continue_button.focus_mode = Control.FOCUS_NONE
	continue_button.add_theme_font_size_override("font_size", 17)
	continue_button.add_theme_color_override("font_color", Color("0b253d"))
	for mode in ["normal", "hover", "pressed", "disabled"]:
		var style := StyleBoxFlat.new()
		style.bg_color = Color("bbf7ff") if mode == "hover" else Color("548eaf") if mode == "pressed" else Color("89d6ed")
		style.border_color = Color("e9ffff")
		style.set_border_width_all(3)
		style.set_corner_radius_all(6)
		continue_button.add_theme_stylebox_override(mode, style)
	continue_button.disabled = true
	continue_button.pressed.connect(try_finish)
	add_child(continue_button)

func _add_label(value: String, bounds: Rect2, font_size: int, tint: Color) -> Label:
	var label := Label.new()
	label.text = value
	label.position = bounds.position
	label.size = bounds.size
	label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	label.add_theme_font_size_override("font_size", font_size)
	label.add_theme_color_override("font_color", tint)
	label.add_theme_color_override("font_outline_color", Color("0b1e35"))
	label.add_theme_constant_override("outline_size", 4)
	add_child(label)
	return label

func _process(delta: float) -> void:
	elapsed += delta
	var text_appear := clampf((elapsed - 1.50) * 1.45, 0.0, 1.0)
	title_label.modulate.a = text_appear
	sub_label.modulate.a = text_appear
	name_label.modulate.a = clampf((elapsed - 2.1) * 1.5, 0.0, 1.0)
	status_label.modulate.a = clampf((elapsed - 2.6) * 1.6, 0.0, 1.0)
	continue_button.modulate.a = clampf((elapsed - 3.0) * 1.8, 0.0, 1.0)
	continue_button.disabled = elapsed < 3.0
	queue_redraw()

func try_finish() -> void:
	if elapsed < 2.8 or complete:
		return
	complete = true
	set_process(false)
	reveal_finished.emit()

func _draw() -> void:
	# Dark veil rises first; pale-blue lantern light ripples through the ground.
	draw_rect(Rect2(Vector2.ZERO, size), Color(0.012, 0.026, 0.065, 0.95))
	var center := Vector2(576.0, 378.0)
	var pulse := 0.5 + 0.5 * sin(elapsed * 3.0)
	draw_circle(center + Vector2(0, 48), 225.0 + 25.0 * pulse, Color(0.04, 0.29, 0.44, 0.065))
	draw_circle(center + Vector2(0, 55), 150.0 + 21.0 * pulse, Color(0.15, 0.51, 0.7, 0.075))
	for k in range(3):
		var age := fposmod(elapsed * 0.52 + float(k) / 3.0, 1.0)
		var r := 80.0 + age * 260.0
		draw_arc(center + Vector2(0, 67), r, 0.18, PI - 0.18, 44, Color(0.44, 0.89, 1.0, (1.0 - age) * 0.24), 2.0)

	# Reveal the supplied stone upward from its base without stretching pixel art.
	# Crop to visible artwork so the PNG's transparent margins do not shrink it.
	var stone_progress := clampf(elapsed / 0.95, 0.0, 1.0)
	stone_progress = 1.0 - pow(1.0 - stone_progress, 3.0)
	var stone_height := TOMBSTONE_HEIGHT
	var stone_width := stone_height * TOMBSTONE_REGION.size.x / TOMBSTONE_REGION.size.y
	var revealed_height := stone_height * stone_progress
	if revealed_height > 0.0:
		var source := Rect2(TOMBSTONE_REGION.position + Vector2(0, TOMBSTONE_REGION.size.y * (1.0 - stone_progress)),
			Vector2(TOMBSTONE_REGION.size.x, TOMBSTONE_REGION.size.y * stone_progress))
		var destination := Rect2(576.0 - stone_width * 0.5, 544.0 - revealed_height, stone_width, revealed_height)
		draw_texture_rect_region(TOMBSTONE_ART, destination, source)

	# Spirits render in front of the enlarged stone so their skin stays visible.
	# The creature rises from inside the gravestone and floats in its own aura.
	var ghost_progress := clampf((elapsed - 0.94) / 2.0, 0.0, 1.0)
	ghost_progress = 1.0 - pow(1.0 - ghost_progress, 3.0)
	if elapsed > 0.94 and ghost_portrait != null:
		var float_bob := sin(elapsed * 2.15) * 5.0 * ghost_progress
		var ghost_center := Vector2(576.0, 426.0 - ghost_progress * 208.0 + float_bob)
		var ghost_alpha := clampf((elapsed - 1.08) * 1.8, 0.0, 1.0)
		AURA_FX.draw_back(self, ghost_center, 113.0, "ghost", elapsed)
		draw_texture_rect(ghost_portrait, Rect2(ghost_center - Vector2(119.0,119.0), Vector2(238.0, 238.0)), false, Color(1.0, 1.0, 1.0, ghost_alpha))
		AURA_FX.draw_front(self, ghost_center, 112.0, "ghost", elapsed)

	# Shards and soul embers erupt as the Ghost clears the gravestone.
	if elapsed > 1.0:
		for i in range(23):
			var seed := float(i)
			var t := elapsed - 1.0
			var angle := seed * 2.39996
			var travel := 35.0 + (65.0 + float(i % 5) * 24.0) * (0.5 + 0.5 * sin(t * 0.75 + seed))
			var pos := center + Vector2(cos(angle) * travel, sin(angle) * travel * 0.78 - 25.0 - 12.0 * t)
			var alpha := clampf((elapsed - 1.0) * 1.3, 0.0, 1.0)
			draw_circle(pos, 2.8 + float(i % 3), Color(0.49, 0.90, 1.0, alpha * (0.3 + 0.35 * pulse)))
