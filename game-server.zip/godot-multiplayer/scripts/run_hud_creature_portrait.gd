extends Control
# A compact in-run creature portrait. Draws the complete visible creature inside
# the existing HUD viewport rather than allowing native-size artwork to clip.
# Every form uses its own painted portrait; this does not resize the HUD itself.

var _creature_texture: Texture2D = null
var _visible_source: Rect2 = Rect2()

var creature_texture: Texture2D:
	get:
		return _creature_texture
	set(value):
		if _creature_texture == value:
			return
		_creature_texture = value
		_measure_visible_art()
		queue_redraw()

func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	clip_contents = true

func _measure_visible_art() -> void:
	_visible_source = Rect2()
	if _creature_texture == null:
		return
	var image: Image = _creature_texture.get_image()
	if image == null or image.is_empty():
		_visible_source = Rect2(Vector2.ZERO, _creature_texture.get_size())
		return

	var w: int = image.get_width()
	var h: int = image.get_height()
	var left: int = w
	var top: int = h
	var right: int = -1
	var bottom: int = -1
	# Use alpha rather than RGB: some translucent Ghost and Gold PNGs
	# retain non-black color channels even in fully transparent pixels.
	for y in range(h):
		for x in range(w):
			if image.get_pixel(x, y).a > 0.025:
				left = mini(left, x)
				top = mini(top, y)
				right = maxi(right, x)
				bottom = maxi(bottom, y)

	if right < left or bottom < top:
		_visible_source = Rect2(Vector2.ZERO, Vector2(w, h))
		return
	# Leave breathing room around ears, wings, particles and tails.
	var pad: int = maxi(2, int(ceil(float(maxi(right - left + 1, bottom - top + 1)) * 0.045)))
	left = maxi(0, left - pad)
	top = maxi(0, top - pad)
	right = mini(w - 1, right + pad)
	bottom = mini(h - 1, bottom + pad)
	_visible_source = Rect2(float(left), float(top), float(right - left + 1), float(bottom - top + 1))

func _draw() -> void:
	if _creature_texture == null or _visible_source.size.x <= 0.0 or _visible_source.size.y <= 0.0:
		return
	# Always fit the entire alpha bounding box inside the framed portrait.
	# Two extra pixels on all sides avoid touching the UI's frame border.
	var interior := Rect2(Vector2(2.0, 2.0), Vector2(maxf(1.0, size.x - 4.0), maxf(1.0, size.y - 4.0)))
	var fit: float = minf(interior.size.x / _visible_source.size.x, interior.size.y / _visible_source.size.y)
	var painted_size: Vector2 = _visible_source.size * fit
	var dst := Rect2(interior.position + (interior.size - painted_size) * 0.5, painted_size)
	draw_texture_rect_region(_creature_texture, dst, _visible_source, Color.WHITE, false, true)
