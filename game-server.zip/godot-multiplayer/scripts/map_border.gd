extends Node2D

const TREE_ART: Texture2D = preload("res://art/border_tree.png")
const PLANT_ART: Texture2D = preload("res://art/border_plants.png")
var items: Array[Dictionary] = []
var walls: Array[StaticBody2D] = []
var tree_texture: AtlasTexture
var plant_texture: AtlasTexture

func setup(world: Vector2) -> void:
	texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	tree_texture = AtlasTexture.new()
	tree_texture.atlas = TREE_ART
	tree_texture.region = Rect2(217, 47, 994, 1062)
	plant_texture = AtlasTexture.new()
	plant_texture.atlas = PLANT_ART
	plant_texture.region = Rect2(108, 180, 1346, 683)
	var tree_height := 280.0
	var tree_width := tree_height * tree_texture.region.size.x / tree_texture.region.size.y
	var tree_count := ceili(world.x / (tree_width * 0.64))
	for index in range(tree_count + 1):
		var x := float(index) * world.x / float(tree_count)
		items.append({"edge": "top", "rect": Rect2(x - tree_width * 0.5, 240.0 - tree_height, tree_width, tree_height)})
		items.append({"edge": "bottom", "rect": Rect2(x - tree_width * 0.5, world.y - 170.0, tree_width, tree_height)})
	var plant_width := 260.0
	var plant_height := plant_width * plant_texture.region.size.y / plant_texture.region.size.x
	var plant_count := ceili(world.y / (plant_height * 0.64))
	for index in range(plant_count + 1):
		var y := float(index) * world.y / float(plant_count) - plant_height * 0.5
		items.append({"edge": "left", "rect": Rect2(-110.0, y, plant_width, plant_height)})
		items.append({"edge": "right", "rect": Rect2(world.x - 150.0, y, plant_width, plant_height)})
	# Continuous collision closes gaps between individual foliage silhouettes.
	_add_wall("Top", Rect2(0, 0, world.x, 220.0))
	_add_wall("Bottom", Rect2(0, world.y - 140.0, world.x, 140.0))
	_add_wall("Left", Rect2(0, 0, 140.0, world.y))
	_add_wall("Right", Rect2(world.x - 140.0, 0, 140.0, world.y))

func _add_wall(edge: String, bounds: Rect2) -> void:
	var body := StaticBody2D.new()
	body.name = edge + "Border"
	body.position = bounds.get_center()
	body.collision_layer = 2
	body.collision_mask = 0
	var shape := RectangleShape2D.new()
	shape.size = bounds.size
	var collision := CollisionShape2D.new()
	collision.shape = shape
	body.add_child(collision)
	add_child(body)
	walls.append(body)

func draw_border(canvas: Node2D, view: Rect2, foreground: bool) -> void:
	for item in items:
		var edge: String = item["edge"]
		if (edge == "bottom") != foreground:
			continue
		var bounds: Rect2 = item["rect"]
		if view.intersects(bounds):
			var texture: Texture2D = tree_texture if edge in ["top", "bottom"] else plant_texture
			canvas.draw_texture_rect(texture, bounds, false)
