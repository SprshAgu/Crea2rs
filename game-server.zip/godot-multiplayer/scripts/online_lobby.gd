extends CanvasLayer
# V31 online foundation: optional Firebase Identity Toolkit login + WebSocket co-op lobby.
# V32: host simulates shared enemies; peers request hits, host replicates enemy state.
# Prototype only: loot, health and permanent rewards are not server-secured.
const PORT := 8917
const MAX_PLAYERS := 4
const FIREBASE_CONFIG := "res://online/firebase_config.json"
var game
var network: WebSocketMultiplayerPeer
var players: Dictionary = {}
var peer_send_clock := 0.0
var coop_active := false
# Co-op extraction vote: host owns the decision and keeps simulating if it leaves.
var extraction_requester := 0
var extraction_waiting: Dictionary = {}
var extraction_answers: Dictionary = {}
var extraction_dialog: ConfirmationDialog
var local_extracted := false
# Host-initiated extraction is mandatory after five seconds.
var host_extraction_seconds := 0.0
var host_extraction_running := false
var host_extraction_banner: PanelContainer
var host_extraction_label: Label
var host_lost_dialog: AcceptDialog
var handling_host_loss := false
const HOST_DISCONNECT_LOOT_PROTECTION_SECONDS := 20.0 * 60.0
var world_sync_clock := 0.0
var loot_sync_clock := 0.0
var last_hit_ms: Dictionary = {}
var online_name := "Guest"
var account_uid := ""
var id_token := ""
var firebase_key := ""
var firebase_project := ""
var request: HTTPRequest
var pending_auth := ""
var pending_email := ""
var overlay: Control
var status: Label
var members: Label
var email_edit: LineEdit
var password_edit: LineEdit
var name_edit: LineEdit
var address_edit: LineEdit
var account_label: Label
var host_button: Button
var join_button: Button
var start_button: Button
var leave_button: Button
var connection_help: AcceptDialog
var host_address_label: Label
# V41 browser room-code service. A public server runs headless Godot rooms.
var room_http: HTTPRequest
var room_code_edit: LineEdit
var room_code_label: Label
var room_code := ""
var room_owner_token := ""
var room_owner_peer_id := 0
var dedicated_room := false
var dedicated_port := PORT
var dedicated_token := ""
var room_api_base := ""
var room_http_action := ""


func _ready() -> void:
	layer = 30
	var cfg := FileAccess.get_file_as_string(FIREBASE_CONFIG)
	var parsed: Variant = JSON.parse_string(cfg)
	if parsed is Dictionary:
		firebase_key = str(parsed.get("api_key", ""))
		firebase_project = str(parsed.get("project_id", ""))
	request = HTTPRequest.new()
	add_child(request)
	request.request_completed.connect(_on_auth_result)
	_make_ui()
	room_http = HTTPRequest.new()
	add_child(room_http)
	room_http.request_completed.connect(_room_http_result)
	room_api_base = _get_room_api_base()
	for arg in OS.get_cmdline_user_args():
		if arg == "--room-server": dedicated_room = true
		if arg.begins_with("--port="): dedicated_port = int(arg.trim_prefix("--port="))
		if arg.begins_with("--token="): dedicated_token = arg.trim_prefix("--token=")
	if dedicated_room:
		call_deferred("_start_dedicated_room")
	connection_help = AcceptDialog.new()
	connection_help.title = "PLAY ONLINE WITH FRIENDS"
	connection_help.dialog_text = """INTERNET ROOMS: Create a 4-digit room and share the code with a friend. They enter it under JOIN CODE. Both players need access to the hosted multiplayer service.

SOLO PLAY: Close this online menu and start a normal dungeon run. No room, account, or server required.

SERVER SETUP: Configure online/rooms_config.json with your publicly hosted Railway server address before exporting the Web build. See V42_DEPLOY_GUIDE.md."""
	connection_help.ok_button_text = "GOT IT"
	add_child(connection_help)
	extraction_dialog = ConfirmationDialog.new()
	extraction_dialog.title = "CO-OP EXTRACTION"
	extraction_dialog.dialog_text = "Your teammate wants to extract. Leave together?"
	extraction_dialog.ok_button_text = "YES - EXTRACT"
	extraction_dialog.cancel_button_text = "NO - STAY"
	extraction_dialog.confirmed.connect(_vote_yes)
	extraction_dialog.canceled.connect(_vote_no)
	add_child(extraction_dialog)
	_make_host_extraction_banner()
	host_lost_dialog = AcceptDialog.new()
	host_lost_dialog.title = "CO-OP CONNECTION LOST"
	host_lost_dialog.dialog_text = "The host disconnected. Your co-op run has ended.\nUnextracted run loot was not banked."
	host_lost_dialog.ok_button_text = "OK"
	add_child(host_lost_dialog)
	multiplayer.peer_connected.connect(_peer_connected)
	multiplayer.peer_disconnected.connect(_peer_disconnected)
	multiplayer.connected_to_server.connect(_joined)
	multiplayer.connection_failed.connect(_connection_failed)
	multiplayer.server_disconnected.connect(_server_disconnected)

# Visual-only alert: ignores mouse input so players can keep fighting/moving.
func _make_host_extraction_banner() -> void:
	host_extraction_banner = PanelContainer.new()
	host_extraction_banner.set_anchors_preset(Control.PRESET_CENTER_TOP)
	host_extraction_banner.position = Vector2(-205, 151)
	host_extraction_banner.custom_minimum_size = Vector2(410, 64)
	host_extraction_banner.mouse_filter = Control.MOUSE_FILTER_IGNORE
	host_extraction_banner.z_index = 20
	add_child(host_extraction_banner)
	host_extraction_label = Label.new()
	host_extraction_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	host_extraction_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	host_extraction_label.add_theme_font_size_override("font_size", 17)
	host_extraction_label.add_theme_color_override("font_color", Color(1.0, 0.87, 0.53))
	host_extraction_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	host_extraction_banner.add_child(host_extraction_label)
	host_extraction_banner.hide()

func _clear_host_extraction() -> void:
	host_extraction_running = false
	host_extraction_seconds = 0.0
	if is_instance_valid(host_extraction_banner):
		host_extraction_banner.hide()

# Sent by the host to everyone, including clients who are on an upgrade screen.
@rpc("authority", "call_local", "reliable")
func _begin_host_extraction_countdown() -> void:
	if not coop_active or local_extracted:
		return
	if is_instance_valid(extraction_dialog):
		extraction_dialog.hide()
	host_extraction_running = true
	host_extraction_seconds = 5.0
	_update_host_extraction_banner()

func _update_host_extraction_banner() -> void:
	if not is_instance_valid(host_extraction_banner):
		return
	# The host already chose to extract. Show the nonblocking warning on joiners.
	if (multiplayer.is_server() and not dedicated_room) or (room_owner_token != "" and room_owner_peer_id == multiplayer.get_unique_id()) or not host_extraction_running or local_extracted:
		host_extraction_banner.hide()
		return
	host_extraction_label.text = "HOST IS EXTRACTING\nEveryone leaves in %d..." % maxi(1, ceili(host_extraction_seconds))
	host_extraction_banner.show()

func _panel_button(parent: Control, caption: String, rect: Rect2, action: Callable) -> Button:
	var b := Button.new()
	b.text = caption
	b.position = rect.position
	b.size = rect.size
	b.add_theme_font_size_override("font_size", 15)
	parent.add_child(b)
	b.pressed.connect(action)
	return b

func _field(parent: Control, placeholder: String, position: Vector2, width: float, secret := false) -> LineEdit:
	var e := LineEdit.new()
	e.placeholder_text = placeholder
	e.position = position
	e.size = Vector2(width, 37)
	e.secret = secret
	parent.add_child(e)
	return e

func _make_ui() -> void:
	overlay = Control.new()
	overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	overlay.mouse_filter = Control.MOUSE_FILTER_STOP
	add_child(overlay)
	var dim := ColorRect.new()
	dim.color = Color(0.025, 0.035, 0.08, 0.90)
	dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	overlay.add_child(dim)
	var p := PanelContainer.new()
	p.set_anchors_and_offsets_preset(Control.PRESET_CENTER)
	p.position = Vector2(-320, -290)
	p.size = Vector2(640, 580)
	overlay.add_child(p)
	var content := Control.new()
	content.custom_minimum_size = Vector2(620, 560)
	p.add_child(content)
	var headline := Label.new()
	headline.text = "CREA2RS  •  INTERNET CO-OP"
	headline.position = Vector2(16, 10)
	headline.add_theme_font_size_override("font_size", 26)
	content.add_child(headline)
	account_label = Label.new()
	account_label.position = Vector2(18, 49)
	account_label.text = "Guest mode (progress stays on this device)"
	account_label.size = Vector2(580, 26)
	content.add_child(account_label)
	name_edit = _field(content, "Display name", Vector2(18, 83), 183)
	email_edit = _field(content, "Email address", Vector2(213, 83), 190)
	password_edit = _field(content, "Password (6+ chars)", Vector2(414, 83), 186, true)
	_panel_button(content, "CREATE ACCOUNT", Rect2(18, 131, 183, 38), _register)
	_panel_button(content, "SIGN IN", Rect2(213, 131, 183, 38), _sign_in)
	_panel_button(content, "GUEST / SIGN OUT", Rect2(414, 131, 186, 38), _guest)
	var help := Label.new()
	help.text = "Firebase sign-in requires online/firebase_config.json configuration."
	help.position = Vector2(18, 174)
	help.size = Vector2(595, 26)
	help.add_theme_font_size_override("font_size", 12)
	content.add_child(help)
	var separator := HSeparator.new()
	separator.position = Vector2(18, 209)
	separator.size = Vector2(581, 6)
	content.add_child(separator)
	room_code_edit = _field(content, "4-digit room code", Vector2(18, 228), 181)
	room_code_edit.max_length = 4
	room_code_edit.text_changed.connect(func(value: String):
		var digits := ""
		for ch in value:
			if ch >= "0" and ch <= "9": digits += ch
		if digits != value: room_code_edit.text = digits
	)
	room_code_label = Label.new()
	room_code_label.position = Vector2(216, 228)
	room_code_label.size = Vector2(390, 38)
	room_code_label.text = "Create a room to get a 4-digit code"
	room_code_label.add_theme_font_size_override("font_size", 16)
	content.add_child(room_code_label)
	host_button = _panel_button(content, "CREATE ROOM", Rect2(18, 274, 181, 42), _create_room)
	join_button = _panel_button(content, "JOIN CODE", Rect2(218, 274, 181, 42), _join_room)
	leave_button = _panel_button(content, "DISCONNECT", Rect2(418, 274, 181, 42), _disconnect)
	var internet_note := Label.new()
	internet_note.position = Vector2(18, 321)
	internet_note.size = Vector2(581, 31)
	internet_note.text = "Online rooms only • Friends join with 4 digits • Solo play stays available"
	internet_note.add_theme_font_size_override("font_size", 13)
	content.add_child(internet_note)
	start_button = _panel_button(content, "START CO-OP RUN", Rect2(18, 357, 581, 39), _launch)
	members = Label.new()
	members.position = Vector2(18, 401)
	members.size = Vector2(581, 52)
	members.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	content.add_child(members)
	status = Label.new()
	status.position = Vector2(18, 467)
	status.size = Vector2(582, 47)
	status.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	content.add_child(status)
	_panel_button(content, "CLOSE / BACK TO GAME", Rect2(18, 518, 582, 37), close)
	overlay.hide()
	_refresh()

func open() -> void:
	overlay.show()
	_refresh()

func close() -> void:
	overlay.hide()

func _set_status(s: String) -> void:
	status.text = s

func _refresh() -> void:
	if not is_instance_valid(overlay):
		return
	account_label.text = "Signed in: %s" % online_name if not account_uid.is_empty() else "Guest: %s (local save only)" % online_name
	var connected := multiplayer.has_multiplayer_peer()
	host_button.disabled = connected
	join_button.disabled = connected
	leave_button.disabled = not connected
	start_button.disabled = not (connected and (multiplayer.is_server() or (room_owner_token != "" and room_owner_peer_id == multiplayer.get_unique_id())))
	if is_instance_valid(room_code_label) and room_code != "": room_code_label.text = "ROOM CODE: %s" % room_code
	var names: Array[String] = []
	for id in players:
		names.append("%s (#%d)" % [str(players[id].get("name", "Guest")), int(id)])
	members.text = "PARTY (%d/%d): %s" % [players.size(), MAX_PLAYERS, ", ".join(names)]

func _register() -> void:
	_auth("signUp")

func _sign_in() -> void:
	_auth("signInWithPassword")

func _auth(op: String) -> void:
	if firebase_key.is_empty():
		_set_status("Configure your Firebase API key first. See ONLINE_SETUP.md")
		return
	var email := email_edit.text.strip_edges()
	if not email.contains("@") or password_edit.text.length() < 6:
		_set_status("Enter a valid email and a password of at least 6 characters.")
		return
	pending_email = email
	pending_auth = op
	var endpoint := "https://identitytoolkit.googleapis.com/v1/accounts:%s?key=%s" % [op, firebase_key]
	var payload := JSON.stringify({"email": email, "password": password_edit.text, "returnSecureToken": true})
	var err := request.request(endpoint, ["Content-Type: application/json"], HTTPClient.METHOD_POST, payload)
	if err != OK:
		_set_status("Could not start authentication: %s" % error_string(err))
	else:
		_set_status("Contacting Firebase...")

func _on_auth_result(_result: int, response_code: int, _headers: PackedStringArray, body: PackedByteArray) -> void:
	var parsed: Variant = JSON.parse_string(body.get_string_from_utf8())
	if not (parsed is Dictionary):
		_set_status("Authentication response was invalid.")
		return
	if response_code != 200:
		_set_status("Sign-in error: %s" % str(parsed.get("error", {}).get("message", "HTTP %d" % response_code)))
		return
	account_uid = str(parsed.get("localId", ""))
	id_token = str(parsed.get("idToken", ""))
	password_edit.clear()
	online_name = name_edit.text.strip_edges()
	if online_name.is_empty():
		online_name = pending_email.get_slice("@", 0)
	_set_status("Account ready. Your existing offline save is preserved. Cloud saves not enabled in V31.")
	_refresh()

func _guest() -> void:
	account_uid = ""
	id_token = ""
	online_name = "Guest" if name_edit.text.strip_edges().is_empty() else name_edit.text.strip_edges()
	password_edit.clear()
	_set_status("Guest mode; your V30 local collection remains unchanged.")
	_refresh()

func _get_lan_ipv4() -> String:
	for addr in IP.get_local_addresses():
		if addr.contains(":") or addr.begins_with("127.") or addr.begins_with("169.254."):
			continue
		if addr.begins_with("192.168.") or addr.begins_with("10.") or addr.begins_with("172."):
			return addr
	return ""

func _copy_lan_address() -> void:
	var lan := _get_lan_ipv4()
	if lan.is_empty():
		_set_status("No LAN IPv4 address found. Check your computer's network settings.")
		return
	var url := "ws://%s:%d" % [lan, PORT]
	DisplayServer.clipboard_set(url)
	_set_status("Copied %s. This works on the same network only, not across the internet." % url)

func _show_connection_help() -> void:
	connection_help.popup_centered(Vector2i(760, 570))

# Accept convenient IP:port input while preserving explicit WSS URLs.
func _normalize_join_address(raw: String) -> String:
	var address := raw.strip_edges()
	if address.is_empty() or address.contains(" ") or address.contains("\n"):
		return ""
	if address.begins_with("ws://") or address.begins_with("wss://"):
		return address
	if address.contains("://") or address.contains("/") or address.contains("?") or address.contains("#"):
		return ""
	# IPv4 or hostname, optionally with an explicit port.
	if address.count(":") > 1:
		return ""
	if not address.contains(":"):
		address += ":%d" % PORT
	else:
		var port_text := address.get_slice(":", 1)
		if not port_text.is_valid_int() or int(port_text) < 1 or int(port_text) > 65535:
			return ""
	return "ws://" + address

func _get_room_api_base() -> String:
	# The browser is static on Netlify while rooms run separately on Railway.
	# Set api_base in res://online/rooms_config.json before exporting Godot Web.
	var cfg: Variant = JSON.parse_string(FileAccess.get_file_as_string("res://online/rooms_config.json"))
	if cfg is Dictionary:
		var configured := str(cfg.get("api_base", "")).strip_edges().trim_suffix("/")
		if configured.begins_with("https://") or configured.begins_with("http://"):
			return configured
	if OS.has_feature("web"):
		var origin: Variant = JavaScriptBridge.eval("window.location.origin", true)
		if origin is String and origin.begins_with("http"):
			return origin
	return "http://127.0.0.1:3000"

func _create_room() -> void:
	if multiplayer.has_multiplayer_peer(): return
	room_http_action = "create"
	var err := room_http.request(room_api_base + "/api/rooms", ["Content-Type: application/json"], HTTPClient.METHOD_POST, "{}")
	_set_status("Creating online room..." if err == OK else "Room service unavailable: %s" % error_string(err))

func _join_room() -> void:
	if multiplayer.has_multiplayer_peer(): return
	var code := room_code_edit.text.strip_edges()
	if code.length() != 4 or not code.is_valid_int():
		_set_status("Enter all four digits of your friend's code.")
		return
	room_http_action = "join"
	var err := room_http.request(room_api_base + "/api/rooms/" + code)
	_set_status("Looking up room %s..." % code if err == OK else "Room service unavailable: %s" % error_string(err))

func _room_http_result(_result: int, response_code: int, _headers: PackedStringArray, body: PackedByteArray) -> void:
	var payload: Variant = JSON.parse_string(body.get_string_from_utf8())
	if response_code != 200 and response_code != 201:
		_set_status(str(payload.get("error", "Room server unavailable")) if payload is Dictionary else "Room service HTTP %d" % response_code)
		return
	if not (payload is Dictionary) or not payload.has("websocket_url"):
		_set_status("Room server returned invalid data.")
		return
	room_code = str(payload.get("code", room_code_edit.text))
	if room_http_action == "create":
		room_owner_token = str(payload.get("owner_token", ""))
	else:
		room_owner_token = ""
	room_code_label.text = "ROOM CODE: %s" % room_code
	_join_url(str(payload["websocket_url"]))

func _start_dedicated_room() -> void:
	var peer := WebSocketMultiplayerPeer.new()
	var err := peer.create_server(dedicated_port, "127.0.0.1")
	if err != OK:
		push_error("Room server failed to bind: %s" % error_string(err))
		get_tree().quit(1)
		return
	network = peer
	multiplayer.multiplayer_peer = network
	players.clear() # The dedicated simulation is not a dungeon participant.
	print("ROOM SERVER READY port=", dedicated_port)

func _join_url(uri: String) -> void:
	var peer := WebSocketMultiplayerPeer.new()
	var err := peer.create_client(uri)
	if err != OK:
		_set_status("Unable to open room: %s" % error_string(err))
		return
	network = peer
	multiplayer.multiplayer_peer = network
	_set_status("Connecting to room %s..." % room_code)
	_refresh()

func _host() -> void:
	handling_host_loss = false
	if multiplayer.has_multiplayer_peer():
		return
	var peer := WebSocketMultiplayerPeer.new()
	var err := peer.create_server(PORT, "0.0.0.0")
	if err != OK:
		_set_status("Host failed: %s. Hosting needs desktop Godot and an open TCP port." % error_string(err))
		return
	network = peer
	multiplayer.multiplayer_peer = network
	players = {1: _my_info()}
	var lan := _get_lan_ipv4()
	_set_status("Hosting TCP %d. LAN: ws://%s:%d. Internet friends need your PUBLIC IP and port forwarding; see HOW TO PLAY ONLINE." % [PORT, lan if not lan.is_empty() else "HOST_LAN_IP", PORT])
	_refresh()

func _join() -> void:
	handling_host_loss = false
	if multiplayer.has_multiplayer_peer():
		return
	var uri := _normalize_join_address(address_edit.text)
	if uri.is_empty():
		_set_status("Enter an IP, IP:port, ws:// or wss:// address.")
		return
	_join_url(uri)

func _my_info() -> Dictionary:
	var display := name_edit.text.strip_edges()
	if not display.is_empty():
		online_name = display.left(24)
	return {"name": online_name.left(24), "p": game.player, "creature": game.selected_creature, "form": game.selected_variant}

func _joined() -> void:
	players[multiplayer.get_unique_id()] = _my_info()
	rpc_id(1, "register_player", online_name.left(24), game.selected_creature, game.selected_variant, room_owner_token)
	_set_status("Connected to lobby. Host controls launch.")
	_refresh()

func _peer_connected(_id: int) -> void:
	_refresh()

func _peer_disconnected(id: int) -> void:
	players.erase(id)
	extraction_waiting.erase(id)
	if extraction_requester == id:
		_cancel_extraction_vote()
	elif multiplayer.is_server() and extraction_requester != 0:
		_resolve_extraction_vote()
	if multiplayer.is_server():
		_sync_roster.rpc(players)
		if dedicated_room and id == room_owner_peer_id and room_owner_peer_id != 0:
			# Preserve the V39 unexpected-host-loss behavior for the whole party.
			get_tree().call_deferred("quit")
	_refresh()

func _connection_failed() -> void:
	_disconnect()
	_set_status("Online room connection failed. Check that the room server is running and try again.")

func _server_disconnected() -> void:
	# Godot emits this on joining clients when the host closes, crashes,
	# or the WebSocket transport fails. Never leave the local run active.
	if handling_host_loss:
		return
	handling_host_loss = true
	call_deferred("_handle_unexpected_host_loss")

func _handle_unexpected_host_loss() -> void:
	# Use this client's actual survival timer. Paused/upgrade time is not
	# counted by the game, which makes the rule consistent with the HUD.
	var interrupted_run: bool = coop_active and not local_extracted and game.state in ["PLAY", "UPGRADE", "PAUSED"]
	var survived_seconds := float(game.time_alive) if interrupted_run else 0.0
	var protected_loot: bool = interrupted_run and survived_seconds >= HOST_DISCONNECT_LOOT_PROTECTION_SECONDS
	_disconnect()
	if protected_loot:
		# The regular extraction path handles chips, gold, materials, captured
		# variants and evolution XP, persists the collection, and displays a
		# results report. It must happen only once for this interrupted run.
		game._extract_run()
		_set_status("Host disconnected after 20 minutes. Your run loot was saved.")
		host_lost_dialog.dialog_text = "The host disconnected, ending the co-op run.\nYou survived at least 20 minutes, so your collected loot was saved!\nYour extraction results are available behind this message."
	elif interrupted_run:
		# No extraction occurred before the safety threshold. Clear carried
		# rewards and return home, but never erase permanently banked progress.
		game.pending_chips = 0
		game.pending_gold = 0
		game.carried_materials.clear()
		game.pending_variants.clear()
		game.variant_reveal_queue.clear()
		game._show_menu()
		_set_status("Host disconnected before 20 minutes. Unextracted loot was lost.")
		host_lost_dialog.dialog_text = "The host disconnected, ending the co-op run.\nYou survived less than 20 minutes. Unextracted loot was lost.\nYour previously saved collection is safe."
	else:
		if game.state in ["PLAY", "UPGRADE", "PAUSED"]:
			game._show_menu()
		_set_status("Host connection lost. Returned to the main menu.")
		host_lost_dialog.dialog_text = "The host disconnected.\nYour saved collection is safe."
	if is_instance_valid(host_lost_dialog):
		host_lost_dialog.popup_centered(Vector2i(550, 195))
	handling_host_loss = false

func _disconnect() -> void:
	coop_active = false
	local_extracted = false
	_cancel_extraction_vote()
	_clear_host_extraction()
	multiplayer.multiplayer_peer = null
	network = null
	players.clear()
	room_code = ""
	room_owner_token = ""
	room_owner_peer_id = 0
	_set_status("Disconnected from party.")
	_refresh()

@rpc("any_peer", "reliable")
func register_player(display: String, creature: String, form: String, token: String = "") -> void:
	if not multiplayer.is_server():
		return
	var id := multiplayer.get_remote_sender_id()
	if players.size() >= MAX_PLAYERS:
		multiplayer.multiplayer_peer.disconnect_peer(id)
		return
	players[id] = {"name": display.left(24), "p": game.EXTRACTION_POINT, "creature": creature, "form": form}
	if dedicated_room and room_owner_peer_id == 0 and not dedicated_token.is_empty() and token == dedicated_token:
		room_owner_peer_id = id
	_sync_roster.rpc(players)
	if dedicated_room: _sync_room_owner.rpc(room_owner_peer_id)
	_refresh()

@rpc("authority", "call_local", "reliable")
func _sync_roster(roster: Dictionary) -> void:
	players = roster
	_refresh()

@rpc("authority", "reliable")
func _sync_room_owner(owner_id: int) -> void:
	room_owner_peer_id = owner_id
	_refresh()

func _launch() -> void:
	if not multiplayer.has_multiplayer_peer() or coop_active:
		return
	if dedicated_room: return
	if multiplayer.is_server():
		var seed_value := randi_range(1, 2147483646)
		_begin_run.rpc(seed_value)
	else:
		if room_owner_token.is_empty() or room_owner_peer_id != multiplayer.get_unique_id(): return
		_request_room_launch.rpc_id(1)
	close()

@rpc("any_peer", "reliable")
func _request_room_launch() -> void:
	if not dedicated_room or coop_active: return
	if multiplayer.get_remote_sender_id() != room_owner_peer_id: return
	_begin_run.rpc(randi_range(1, 2147483646))

@rpc("authority", "call_local", "reliable")
func _begin_run(seed_value: int) -> void:
	if game.state == "PLAY":
		return
	# The headless room simulates enemies using the default starter creature.
	if dedicated_room:
		game.selected_creature = "koikoi"
		game.selected_variant = "normal"
		game.unlocked["koikoi"] = true
	game._start_run()
	if game.state != "PLAY":
		_set_status("Pick an unlocked creature before starting a party run.")
		return
	game._generate_world(seed_value)
	coop_active = true
	local_extracted = false
	extraction_requester = 0
	extraction_waiting.clear()
	extraction_answers.clear()
	_clear_host_extraction()
	for peer_id in players:
		var data: Dictionary = players[peer_id]
		data["extracted"] = false
		players[peer_id] = data
	world_sync_clock = 0.0
	loot_sync_clock = 0.0
	close()

# The requester stays in the dungeon until every other active player votes.
# All YES = everybody extracts; any NO = only the requester extracts.
func request_extraction() -> void:
	if not coop_active or local_extracted or extraction_requester != 0 or host_extraction_running:
		return
	if multiplayer.is_server():
		_start_extraction_vote(multiplayer.get_unique_id())
	else:
		_request_extraction_on_host.rpc_id(1)

@rpc("any_peer", "reliable")
func _request_extraction_on_host() -> void:
	if multiplayer.is_server():
		_start_extraction_vote(multiplayer.get_remote_sender_id())

func _start_extraction_vote(requester: int) -> void:
	if not multiplayer.is_server() or extraction_requester != 0 or host_extraction_running or not coop_active or not _is_active(requester):
		return
	if requester == 1 or (dedicated_room and requester == room_owner_peer_id):
		# The host controls the dungeon. Its extraction ends the entire party run;
		# clients do not vote and can continue moving for the five-second warning.
		extraction_requester = requester
		_begin_host_extraction_countdown.rpc()
		return
	extraction_requester = requester
	extraction_waiting.clear()
	extraction_answers.clear()
	for raw_id in players:
		var peer_id := int(raw_id)
		if peer_id != requester and _is_active(peer_id):
			extraction_waiting[peer_id] = true
	if extraction_waiting.is_empty():
		_finish_extraction([requester])
		return
	for peer_id in extraction_waiting:
		if int(peer_id) == 1:
			_show_extraction_question(requester)
		else:
			_show_extraction_question.rpc_id(int(peer_id), requester)
	if requester != 1:
		_extraction_pending.rpc_id(requester)
	else:
		game.event_message = "Waiting for teammate's extraction vote..."
		game.event_timer = 4.0

@rpc("authority", "reliable")
func _extraction_pending() -> void:
	game.event_message = "Waiting for teammate's extraction vote..."
	game.event_timer = 4.0

@rpc("authority", "reliable")
func _show_extraction_question(requester: int) -> void:
	if local_extracted or game.state not in ["PLAY", "UPGRADE", "PAUSED"]:
		return
	extraction_requester = requester
	extraction_dialog.dialog_text = "A teammate wants to extract.\n\nYES: You both extract and bank rewards.\nNO: They extract alone; you keep playing."
	extraction_dialog.popup_centered(Vector2i(490, 210))

func _vote_yes() -> void:
	_send_extraction_vote(true)

func _vote_no() -> void:
	_send_extraction_vote(false)

func _send_extraction_vote(yes: bool) -> void:
	if multiplayer.is_server():
		_record_extraction_vote(1, yes)
	else:
		_answer_extraction_on_host.rpc_id(1, yes)
	extraction_requester = 0

@rpc("any_peer", "reliable")
func _answer_extraction_on_host(yes: bool) -> void:
	if multiplayer.is_server():
		_record_extraction_vote(multiplayer.get_remote_sender_id(), yes)

func _record_extraction_vote(peer_id: int, yes: bool) -> void:
	if extraction_requester == 0 or not extraction_waiting.has(peer_id):
		return
	extraction_answers[peer_id] = yes
	_resolve_extraction_vote()

func _resolve_extraction_vote() -> void:
	if not multiplayer.is_server() or extraction_requester == 0:
		return
	for peer_id in extraction_waiting:
		if _is_active(int(peer_id)) and not extraction_answers.has(peer_id):
			return
	var extract_ids: Array = [extraction_requester]
	var everyone_yes := true
	for peer_id in extraction_waiting:
		if _is_active(int(peer_id)) and not bool(extraction_answers.get(peer_id, false)):
			everyone_yes = false
	if everyone_yes:
		for peer_id in extraction_waiting:
			if _is_active(int(peer_id)):
				extract_ids.append(int(peer_id))
	_finish_extraction(extract_ids)

func _finish_extraction(extract_ids: Array) -> void:
	if not multiplayer.is_server():
		return
	for peer_id in extract_ids:
		if players.has(peer_id):
			var data: Dictionary = players[peer_id]
			data["extracted"] = true
			players[peer_id] = data
	_cancel_extraction_vote()
	# Reliable messages, sent before any player leaves the run.
	_complete_extraction.rpc(extract_ids)
	_complete_extraction(extract_ids)
	_sync_roster.rpc(players)
	_refresh()
	if _active_count() == 0:
		coop_active = false

@rpc("authority", "reliable")
func _complete_extraction(extract_ids: Array) -> void:
	if extraction_dialog.visible:
		extraction_dialog.hide()
	_clear_host_extraction()
	extraction_requester = 0
	for peer_id in extract_ids:
		if players.has(peer_id):
			var data: Dictionary = players[peer_id]
			data["extracted"] = true
			players[peer_id] = data
	if multiplayer.get_unique_id() in extract_ids and not local_extracted:
		local_extracted = true
		game._extract_run()
	if _active_count() == 0:
		coop_active = false

func _cancel_extraction_vote() -> void:
	extraction_requester = 0
	extraction_waiting.clear()
	extraction_answers.clear()
	if is_instance_valid(extraction_dialog):
		extraction_dialog.hide()

func _is_active(id: int) -> bool:
	return players.has(id) and not bool(players[id].get("extracted", false))

func remaining_player_position() -> Vector2:
	for peer_id in players:
		if _is_active(int(peer_id)):
			return players[peer_id].get("p", game.EXTRACTION_POINT)
	return game.EXTRACTION_POINT

func _active_count() -> int:
	var count := 0
	for peer_id in players:
		if _is_active(int(peer_id)):
			count += 1
	return count

@rpc("any_peer", "unreliable_ordered")
func _receive_position(pos: Vector2, creature: String, form: String, trail: Array) -> void:
	var id := multiplayer.get_remote_sender_id()
	if not _is_active(id):
		return
	var data: Dictionary = players[id]
	data["p"] = pos
	data["creature"] = creature
	data["form"] = form
	data["trail"] = trail
	players[id] = data
	if multiplayer.is_server():
		_position_from_host.rpc(id, pos, creature, form, trail)

@rpc("authority", "unreliable_ordered")
func _position_from_host(id: int, pos: Vector2, creature: String, form: String, trail: Array) -> void:
	if id == multiplayer.get_unique_id() or not _is_active(id):
		return
	var data: Dictionary = players[id]
	data["p"] = pos
	data["creature"] = creature
	data["form"] = form
	data["trail"] = trail
	players[id] = data

func closest_target(origin: Vector2) -> Vector2:
	var result: Vector2 = game.player
	var distance := INF if dedicated_room or local_extracted else result.distance_squared_to(origin)
	for id in players:
		if int(id) == multiplayer.get_unique_id() or not _is_active(int(id)):
			continue
		var position: Vector2 = players[id].get("p", game.player)
		if position.distance_squared_to(origin) < distance:
			result = position
			distance = position.distance_squared_to(origin)
	return result

func request_hit(enemy_uid: int, requested_damage: float) -> void:
	if not coop_active or not multiplayer.has_multiplayer_peer() or multiplayer.is_server():
		return
	if enemy_uid < 0 or requested_damage <= 0.0:
		return
	_hit_on_host.rpc_id(1, enemy_uid, requested_damage)

@rpc("any_peer", "reliable")
func _hit_on_host(enemy_uid: int, requested_damage: float) -> void:
	if not multiplayer.is_server() or not coop_active or game.state != "PLAY":
		return
	var sender := multiplayer.get_remote_sender_id()
	if not _is_active(sender) or requested_damage <= 0.0 or requested_damage > 350.0:
		return
	var attacker: Vector2 = players[sender].get("p", game.player)
	for i in range(game.enemies.size()):
		var foe: Dictionary = game.enemies[i]
		if int(foe.get("uid", -1)) != enemy_uid:
			continue
		if attacker.distance_to(Vector2(foe["p"])) > 650.0:
			return
		# Basic request throttling. Actual production combat needs server-owned abilities.
		var now := Time.get_ticks_msec()
		var key := "%d:%d" % [sender, enemy_uid]
		if now - int(last_hit_ms.get(key, -100000)) < 85:
			return
		last_hit_ms[key] = now
		game._damage_enemy(i, requested_damage)
		return

func announce_enemy_defeat(enemy_uid: int, creature: String, variant: String, where: Vector2) -> void:
	if coop_active and multiplayer.is_server():
		_enemy_defeated.rpc(enemy_uid, creature, variant, where)

@rpc("authority", "reliable")
func _enemy_defeated(enemy_uid: int, creature: String, variant: String, where: Vector2) -> void:
	if coop_active and game.state == "PLAY":
		game._coop_receive_defeat(enemy_uid, creature, variant, where)

@rpc("authority", "unreliable_ordered")
func _world_snapshot(foes: Array, bullets: Array, server_time: float, server_wave: int, chips: Array, xp_orbs: Array, gold_orbs: Array, materials: Array) -> void:
	if not coop_active or game.state != "PLAY" or multiplayer.is_server():
		return
	# Copy the authoritative enemy state. Keep client shot / HP handling local.
	game.enemies.clear()
	for item in foes:
		if item is Dictionary:
			game.enemies.append(item)
	game.enemy_bullets.clear()
	for item in bullets:
		if item is Dictionary:
			game.enemy_bullets.append(item)
	game.time_alive = server_time
	game.wave = server_wave
	# Send drops with the existing reliable-in-practice enemy snapshot path.
	# The previous separate pickup RPC did not populate client worlds reliably.
	game.chip_drops.assign(chips)
	game.xp_drops.assign(xp_orbs)
	game.gold_drops.assign(gold_orbs)
	game.material_drops.assign(materials)

# Loot is one shared set of world objects. Only the host can remove a drop.
# Each pickup is credited only to the player who actually collected it.
@rpc("authority", "reliable")
func _loot_snapshot(chips: Array, xp_orbs: Array, gold_orbs: Array, materials: Array) -> void:
	if not coop_active or multiplayer.is_server() or game.state != "PLAY":
		return
	game.chip_drops.clear()
	for drop in chips:
		if drop is Dictionary:
			game.chip_drops.append(drop)
	game.xp_drops.clear()
	for drop in xp_orbs:
		if drop is Dictionary:
			game.xp_drops.append(drop)
	game.gold_drops.clear()
	for drop in gold_orbs:
		if drop is Dictionary:
			game.gold_drops.append(drop)
	game.material_drops.clear()
	for drop in materials:
		if drop is Dictionary:
			game.material_drops.append(drop)

@rpc("authority", "reliable")
func _award_loot(kind: String, amount: int, material_id: String) -> void:
	if not coop_active or multiplayer.is_server() or game.state != "PLAY":
		return
	match kind:
		"chip":
			game.pending_chips += 1
		"xp":
			game._apply_earned_xp(amount)
		"gold":
			game._collect_run_gold(amount)
		"material":
			if material_id in ["grove_fiber", "crystal_shards", "ember_fragments"]:
				game.carried_materials[material_id] = int(game.carried_materials.get(material_id, 0)) + 1

# XP is awarded to the entire co-op team when either player claims an XP orb.
# This is run-only XP; permanent/account progression still needs secure backing.
func award_team_xp(amount: int) -> void:
	if amount <= 0 or not coop_active or not multiplayer.is_server():
		return
	if not local_extracted:
		game._apply_earned_xp(amount)
	_team_xp.rpc(amount)

@rpc("authority", "reliable")
func _team_xp(amount: int) -> void:
	if coop_active and not local_extracted and not multiplayer.is_server() and game.state in ["PLAY", "UPGRADE"] and amount > 0:
		game._apply_earned_xp(amount)

func _collect_remote_loot() -> void:
	if not multiplayer.is_server() or not coop_active or game.state != "PLAY":
		return
	for id in players:
		var peer_id := int(id)
		if peer_id == multiplayer.get_unique_id() or not _is_active(peer_id):
			continue
		var pos: Vector2 = players[id].get("p", game.EXTRACTION_POINT)
		# This is a host-side approximation until the full authoritative
		# character / equipment simulation is implemented.
		var radius: float = game.PICKUP_RADIUS
		for i in range(game.chip_drops.size() - 1, -1, -1):
			if pos.distance_to(Vector2(game.chip_drops[i]["p"])) < radius:
				game.chip_drops.remove_at(i)
				_award_loot.rpc_id(peer_id, "chip", 1, "")
		for i in range(game.xp_drops.size() - 1, -1, -1):
			if pos.distance_to(Vector2(game.xp_drops[i]["p"])) < radius:
				var amount: int = int(game.xp_drops[i].get("amount", 0))
				game.xp_drops.remove_at(i)
				award_team_xp(amount)
		for i in range(game.gold_drops.size() - 1, -1, -1):
			if pos.distance_to(Vector2(game.gold_drops[i]["p"])) < radius:
				var amount: int = int(game.gold_drops[i].get("amount", 0))
				game.gold_drops.remove_at(i)
				_award_loot.rpc_id(peer_id, "gold", amount, "")
		for i in range(game.material_drops.size() - 1, -1, -1):
			if pos.distance_to(Vector2(game.material_drops[i]["p"])) < radius:
				var material_id: String = str(game.material_drops[i].get("id", ""))
				game.material_drops.remove_at(i)
				_award_loot.rpc_id(peer_id, "material", 1, material_id)

func _process(delta: float) -> void:
	if not multiplayer.has_multiplayer_peer():
		return
	if host_extraction_running:
		host_extraction_seconds = maxf(0.0, host_extraction_seconds - delta)
		_update_host_extraction_banner()
		if multiplayer.is_server() and host_extraction_seconds <= 0.0:
			var all_active: Array = []
			for peer_id in players:
				if _is_active(int(peer_id)):
					all_active.append(int(peer_id))
			_clear_host_extraction()
			if not all_active.is_empty():
				_finish_extraction(all_active)

	# An extracting host must stay connected and keep the world alive for survivors.
	if coop_active and multiplayer.is_server() and local_extracted and game.state == "MENU" and _active_count() > 0:
		game._update_run(delta)
	if game.state != "PLAY" and not (coop_active and multiplayer.is_server() and local_extracted and _active_count() > 0):
		return
	if coop_active and multiplayer.is_server():
		world_sync_clock += delta
		if world_sync_clock >= 0.10:
			world_sync_clock = 0.0
			_world_snapshot.rpc(game.enemies, game.enemy_bullets, game.time_alive, game.wave,
				game.chip_drops, game.xp_drops, game.gold_drops, game.material_drops)
		_collect_remote_loot()

	peer_send_clock += delta
	if peer_send_clock < 0.08:
		return
	peer_send_clock = 0.0
	var my_id := multiplayer.get_unique_id()
	if dedicated_room: return
	if local_extracted:
		return
	var data := _my_info()
	data["extracted"] = false
	players[my_id] = data
	# Compact visual-only trail data, sent alongside the existing player position.
	var trail: Array = []
	for mark in game.footprints.slice(maxi(0, game.footprints.size() - 35)):
		trail.append({"p": mark["p"], "facing": mark["facing"], "time": mark["time"], "stage": mark["stage"], "left": mark["left"]})
	if multiplayer.is_server():
		_position_from_host.rpc(my_id, game.player, game.selected_creature, game.selected_variant, trail)
	else:
		_receive_position.rpc_id(1, game.player, game.selected_creature, game.selected_variant, trail)

func draw_teammates(canvas: Node2D) -> void:
	if not multiplayer.has_multiplayer_peer():
		return
	for id in players:
		if id == multiplayer.get_unique_id() or not _is_active(int(id)):
			continue
		var data: Dictionary = players[id]
		var creature := str(data.get("creature", "koikoi"))
		var form := str(data.get("form", "normal"))
		if not game.CREATURES.has(creature):
			continue
		var p: Vector2 = data.get("p", game.EXTRACTION_POINT)
		# Draw remote footsteps using exactly the same local trail renderer.
		canvas._draw_footprint_marks(data.get("trail", []))
		canvas.draw_circle(p, 31.0, Color(0.28, 0.88, 1.0, 0.14))
		canvas._draw_shadow(p, 28, 9)
		var center := p + Vector2(0, -39)
		game.AURA_FX.draw_back(canvas, center, 54.0, form, game.time_alive)
		canvas._draw_creature(game._form_world_texture(creature, form), p, 95.0, game._form_color(form))
		game.AURA_FX.draw_front(canvas, center, 54.0, form, game.time_alive)
		var font: Font = ThemeDB.fallback_font
		canvas.draw_string(font, p + Vector2(-34, -112), str(data.get("name", "Friend")), HORIZONTAL_ALIGNMENT_CENTER, 68, 15, Color("83f0ff"))
