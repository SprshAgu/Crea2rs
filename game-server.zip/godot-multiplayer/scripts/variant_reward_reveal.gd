extends Control
# Reusable, variant-specific reward cut-in for slot jackpots, dungeon captures
# and hatchery hatches. The parent game decides which results merit a reveal.
signal reveal_finished

const AURA_FX = preload("res://scripts/variant_aura_fx.gd")

var creature_texture: Texture2D
var creature_name := ""
var form := "normal"
var source := "slots"
var first_unlock := false
var pull_index := 0
var batch_size := 0
var queued_after := 0
var elapsed := 0.0
var duration := 3.0
var finished := false
var primary := Color("be8cff")
var secondary := Color("f1aaff")
var headline := "VARIANT FOUND!"
var subline := "A new creature form appeared!"

func setup(portrait: Texture2D, display_name: String, variant_form: String, is_new: bool, origin: String, following: int = 0, pull: int = 0, total_pulls: int = 0) -> void:
	creature_texture = portrait
	creature_name = display_name
	form = variant_form
	first_unlock = is_new
	source = origin
	queued_after = following
	pull_index = pull
	batch_size = total_pulls
	duration = 2.3 if origin == "wild" else 3.5 if form.contains("shiny") else 3.0
	if origin == "wild":
		duration = 2.6 if form.contains("shiny") else 2.25
	if form == "corrupt":
		primary = Color("ac4aff")
		secondary = Color("f35ac8")
		headline = "CORRUPTION UNLEASHED!"
		subline = "The shadows twist around this creature"
	elif form == "blessed":
		primary = Color("ffefaf")
		secondary = Color("a3faff")
		headline = "BLESSED DISCOVERY!"
		subline = "A radiant form shines through"
	elif form == "ghost":
		primary = Color("76deff")
		secondary = Color("697fff")
		headline = "SPECTRAL AWAKENING!"
		subline = "A ghostly spirit has manifested"
	elif form == "gold":
		primary = Color("ffdd61")
		secondary = Color("ff9b37")
		headline = "GOLDEN MIRACLE!"
		subline = "The Midas power glitters"
	elif form == "shiny":
		primary = Color("75fff1")
		secondary = Color("f58dff")
		headline = "SHINY DISCOVERY!"
		subline = "An extraordinary color has appeared"
	elif form == "shiny+blessed":
		primary = Color("91faff")
		secondary = Color("ffe98e")
		headline = "SHINY ◆ BLESSED!"
		subline = "A radiant, iridescent miracle"
	elif form == "shiny+corrupt":
		primary = Color("83fff0")
		secondary = Color("c65aff")
		headline = "SHINY ◆ CORRUPT!"
		subline = "Prismatic sparks meet dark magic"

func _ready() -> void:
	position = Vector2.ZERO
	size = Vector2(1152, 648)
	mouse_filter = Control.MOUSE_FILTER_STOP
	texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	set_process(true)
	_add_label(headline, Rect2(282, 106, 590, 59), 34, primary)
	_add_label(subline, Rect2(282, 166, 590, 25), 16, secondary)
	_add_label(creature_name.to_upper(), Rect2(305, 412, 542, 44), 30, Color.WHITE)
	_add_label(form.replace("+", " ◆ ").to_upper() + " FORM", Rect2(302, 451, 548, 27), 19, primary)
	var notice := "FIRST DISCOVERY  •  NEW FORM UNLOCKED!" if first_unlock else "RARE FORM FOUND AGAIN!"
	if source == "wild":
		notice = "CAUGHT IN RUN  •  EXTRACT TO KEEP!" if first_unlock else "CAUGHT AGAIN  •  EXTRACT TO KEEP!"
	elif source == "hatchery":
		notice = "HATCHED!  •  NEW FORM ADDED!" if first_unlock else "HATCHED!  •  ALREADY IN COLLECTION"
	_add_label(notice, Rect2(300, 481, 552, 28), 14, Color("baffde") if first_unlock else secondary)
	var continue_button := Button.new()
	continue_button.text = "NEXT REVEAL  (%d LEFT)" % queued_after if queued_after > 0 else "CONTINUE"
	continue_button.position = Vector2(474, 523)
	continue_button.size = Vector2(204, 43)
	continue_button.focus_mode = Control.FOCUS_NONE
	continue_button.add_theme_font_size_override("font_size", 17)
	continue_button.add_theme_color_override("font_color", Color("11162b"))
	for mode in ["normal", "hover", "pressed"]:
		var style := StyleBoxFlat.new()
		style.bg_color = secondary if mode == "hover" else primary.darkened(0.2) if mode == "pressed" else primary
		style.border_color = Color.WHITE
		style.set_border_width_all(2)
		style.set_corner_radius_all(5)
		continue_button.add_theme_stylebox_override(mode, style)
	continue_button.pressed.connect(_finish_reveal)
	add_child(continue_button)
	if source == "slots" and batch_size > 0:
		_add_label("SLOT PULL %d / %d" % [pull_index, batch_size], Rect2(370, 573, 412, 24), 13, secondary)
	elif source == "hatchery":
		_add_label("HATCHERY  •  EGG HATCHED", Rect2(370, 573, 412, 24), 13, secondary)
	else:
		_add_label("DUNGEON CAPTURE  •  RUN PAUSED", Rect2(370, 573, 412, 24), 13, secondary)

func _add_label(value: String, bounds: Rect2, font_size: int, tint: Color) -> void:
	var label := Label.new()
	label.text = value
	label.position = bounds.position
	label.size = bounds.size
	label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	label.add_theme_font_size_override("font_size", font_size)
	label.add_theme_color_override("font_color", tint)
	label.add_theme_color_override("font_outline_color", Color("0b0c1c"))
	label.add_theme_constant_override("outline_size", 3)
	add_child(label)

func _process(delta: float) -> void:
	elapsed += delta
	queue_redraw()
	if elapsed >= duration:
		_finish_reveal()

func _finish_reveal() -> void:
	if finished:
		return
	finished = true
	set_process(false)
	reveal_finished.emit()

func _draw() -> void:
	var alpha := clampf(elapsed / 0.22, 0.0, 1.0) * clampf((duration - elapsed) / 0.24, 0.0, 1.0)
	var center := Vector2(576, 303)
	var is_shiny := form.contains("shiny")
	var pulse := 0.5 + 0.5 * sin(elapsed * (8.0 if is_shiny else 5.0))
	# Blackened gameplay/arcade background and layered color-matched spotlight.
	draw_rect(Rect2(Vector2.ZERO, size), Color(0.008, 0.013, 0.041, 0.90 * alpha))
	# Draw frame on the same canvas, behind the spotlight and creature sprite.
	# A child Panel here would cover up the actual creature animation.
	draw_rect(Rect2(257, 85, 638, 477), Color(0.035, 0.055, 0.13, 0.96 * alpha))
	draw_rect(Rect2(257, 85, 638, 477), Color(primary.r, primary.g, primary.b, 0.91 * alpha), false, 4.0)
	draw_rect(Rect2(267, 95, 618, 457), Color(secondary.r, secondary.g, secondary.b, 0.26 * alpha), false, 2.0)
	draw_circle(center, 184.0 + 10.0 * pulse, Color(primary.r, primary.g, primary.b, 0.09 * alpha))
	draw_circle(center, 122.0 + 7.0 * pulse, Color(secondary.r, secondary.g, secondary.b, 0.11 * alpha))
	# Variant-coded beams: shadow tendrils, holy rays, drifting soul-wisps,
	# golden rays, or overlapping rainbow sparkles for Shiny forms.
	var beam_count := 28 if is_shiny else 20 if form == "gold" else 14
	for i in range(beam_count):
		var a := TAU * float(i) / float(beam_count) + elapsed * (0.38 if form == "corrupt" else -0.26)
		var direction := Vector2(cos(a), sin(a))
		var side := Vector2(-direction.y, direction.x)
		var ray_start := center + direction * 75.0
		var ray_end := center + direction * (265.0 + sin(elapsed * 3.0 + float(i) * 2.3) * 24.0)
		var ray_tint := secondary if is_shiny and i % 2 == 0 else primary
		var polygon := PackedVector2Array([ray_start - side * 5.0, ray_start + side * 5.0, ray_end + side * 1.4, ray_end - side * 1.4])
		draw_colored_polygon(polygon, Color(ray_tint.r, ray_tint.g, ray_tint.b, (0.10 if form == "corrupt" else 0.08) * alpha))
	for ring in range(3):
		var phase := fposmod(elapsed * 0.76 + float(ring) / 3.0, 1.0)
		var tint := primary if ring % 2 == 0 else secondary
		draw_arc(center, lerpf(100.0, 256.0, phase), 0, TAU, 60, Color(tint.r, tint.g, tint.b, 0.48 * (1.0 - phase) * alpha), 3.5, true)
	for i in range(44):
		var seed := float(i)
		var angle := seed * 2.399 + elapsed * (0.7 if is_shiny else 0.26)
		var distance := 65.0 + fposmod(seed * 38.0 + elapsed * (46.0 + float(i % 5) * 13.0), 236.0)
		var p := center + Vector2(cos(angle), sin(angle)) * distance
		var spark_tint := secondary if i % 3 == 0 else primary
		var spark := 2.3 + 2.2 * absf(sin(elapsed * 5.0 + seed))
		if form == "corrupt":
			p.y -= fposmod(elapsed * 41.0 + seed * 2.0, 35.0)
			draw_circle(p, spark * 0.8, Color(spark_tint.r, spark_tint.g, spark_tint.b, 0.62 * alpha))
		elif form == "ghost":
			p.y -= fposmod(elapsed * 28.0 + seed * 3.0, 50.0)
			draw_circle(p, spark * 1.25, Color(spark_tint.r, spark_tint.g, spark_tint.b, 0.38 * alpha))
		else:
			var sparkle_color := Color(spark_tint.r, spark_tint.g, spark_tint.b, 0.70 * alpha)
			draw_line(p - Vector2(spark, 0), p + Vector2(spark, 0), sparkle_color, 2.0, true)
			draw_line(p - Vector2(0, spark), p + Vector2(0, spark), sparkle_color, 2.0, true)
	AURA_FX.draw_back(self, center, 121.0, form, elapsed)
	if creature_texture != null:
		var progress := clampf(elapsed / 0.58, 0.0, 1.0)
		var bounce := 1.0 + 0.15 * sin(progress * PI * 1.35) * (1.0 - progress)
		var sprite_size := (137.0 + 81.0 * (1.0 - pow(1.0 - progress, 3.0))) * bounce
		# Match the creature collection tint for standard Blessed/Corrupt forms.
		# Custom Shiny, Gold and Ghost pixels retain their original palettes.
		var art_tint := Color(1.0, 1.0, 1.0, alpha)
		if form == "corrupt":
			art_tint = Color(0.38, 0.32, 0.52, alpha)
		elif form == "blessed":
			art_tint = Color(1.0, 0.96, 0.78, alpha)
		draw_texture_rect(creature_texture, Rect2(center.x - sprite_size * 0.5, center.y - sprite_size * 0.5 + sin(elapsed * 3.8) * 3.0, sprite_size, sprite_size), false, art_tint)
	AURA_FX.draw_front(self, center, 121.0, form, elapsed)
	# Brilliant burst at entry; Gold, Shiny and Blessed are brighter, Ghost cooler.
	var flash := pow(maxf(0.0, 1.0 - elapsed / 0.37), 2.0)
	var brightness := 0.47 if is_shiny or form in ["gold", "blessed"] else 0.31
	draw_rect(Rect2(270, 96, 612, 453), Color(primary.r, primary.g, primary.b, flash * brightness))
