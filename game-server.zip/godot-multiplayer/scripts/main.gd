extends Node2D

const AURA_FX = preload("res://scripts/variant_aura_fx.gd")
const VARIANT_PORTRAIT = preload("res://scripts/variant_portrait.gd")
const RUN_HUD_PORTRAIT = preload("res://scripts/run_hud_creature_portrait.gd")
const GOLD_REVEAL = preload("res://scripts/gold_jackpot_reveal.gd")
const VARIANT_REVEAL = preload("res://scripts/variant_reward_reveal.gd")
const GHOST_REVEAL = preload("res://scripts/ghost_tombstone_reveal.gd")
const HATCHERY_NEST = preload("res://scripts/hatchery_nest.gd")

# Crea2rs Dungeons: creature collection, extraction runs, and triple-reel slots.
# To add a creature, add its PNG to art/ and an entry in CREATURES.
const TEX_KOIKOI: Texture2D = preload("res://art/koikoi.png")
const TEX_KUJIRA: Texture2D = preload("res://art/kujira.png")
const TEX_ABADOM: Texture2D = preload("res://art/abadom.png")
const TEX_AKHEL: Texture2D = preload("res://art/akhel.png")
const TEX_ALGEN: Texture2D = preload("res://art/algen.png")
const TEX_APALA: Texture2D = preload("res://art/apala.png")
const TEX_AUREHAWK: Texture2D = preload("res://art/aurehawk.png")
const TEX_AZATIE: Texture2D = preload("res://art/azatie.png")
const TEX_BIGROOT: Texture2D = preload("res://art/bigroot.png")
const TEX_BONIA: Texture2D = preload("res://art/bonia.png")
const TEX_CANTHOS: Texture2D = preload("res://art/canthos.png")
const TEX_CARAPEX: Texture2D = preload("res://art/carapex.png")
const TEX_CORALITH: Texture2D = preload("res://art/coralith.png")
const TEX_DRACOSOAR: Texture2D = preload("res://art/dracosoar.png")
const TEX_DRIBBLE: Texture2D = preload("res://art/dribble.png")
const TEX_DWELLER: Texture2D = preload("res://art/dweller.png")
const TEX_ECHO: Texture2D = preload("res://art/echo.png")
const TEX_ELIOS: Texture2D = preload("res://art/elios.png")
const TEX_FLIC: Texture2D = preload("res://art/flic.png")
const TEX_GLAU: Texture2D = preload("res://art/glau.png")
const UI_KOIKOI: Texture2D = preload("res://art/portraits/koikoi.png")
const UI_KUJIRA: Texture2D = preload("res://art/portraits/kujira.png")
const UI_ABADOM: Texture2D = preload("res://art/portraits/abadom.png")
const UI_AKHEL: Texture2D = preload("res://art/portraits/akhel.png")
const UI_ALGEN: Texture2D = preload("res://art/portraits/algen.png")
const UI_APALA: Texture2D = preload("res://art/portraits/apala.png")
const UI_AUREHAWK: Texture2D = preload("res://art/portraits/aurehawk.png")
const UI_AZATIE: Texture2D = preload("res://art/portraits/azatie.png")
const UI_BIGROOT: Texture2D = preload("res://art/portraits/bigroot.png")
const UI_BONIA: Texture2D = preload("res://art/portraits/bonia.png")
const UI_CANTHOS: Texture2D = preload("res://art/portraits/canthos.png")
const UI_CARAPEX: Texture2D = preload("res://art/portraits/carapex.png")
const UI_CORALITH: Texture2D = preload("res://art/portraits/coralith.png")
const UI_DRACOSOAR: Texture2D = preload("res://art/portraits/dracosoar.png")
const UI_DRIBBLE: Texture2D = preload("res://art/portraits/dribble.png")
const UI_DWELLER: Texture2D = preload("res://art/portraits/dweller.png")
const UI_ECHO: Texture2D = preload("res://art/portraits/echo.png")
const UI_ELIOS: Texture2D = preload("res://art/portraits/elios.png")
const UI_FLIC: Texture2D = preload("res://art/portraits/flic.png")
const UI_GLAU: Texture2D = preload("res://art/portraits/glau.png")
const TEX_GLIDRAGON: Texture2D = preload("res://art/glidragon.png")
const TEX_GLIDRAPTOR: Texture2D = preload("res://art/glidraptor.png")
const TEX_GLIM: Texture2D = preload("res://art/glim.png")
const TEX_GORZARA: Texture2D = preload("res://art/gorzara.png")
const TEX_GRAVURN: Texture2D = preload("res://art/gravurn.png")
const TEX_GRINBLE: Texture2D = preload("res://art/grinble.png")
const TEX_IRIM: Texture2D = preload("res://art/irim.png")
const TEX_KANO: Texture2D = preload("res://art/kano.png")
const TEX_KETU: Texture2D = preload("res://art/ketu.png")
const TEX_KITPIN: Texture2D = preload("res://art/kitpin.png")
const TEX_LUMI: Texture2D = preload("res://art/lumi.png")
const TEX_MIDOSENKA: Texture2D = preload("res://art/midosenka.png")
const TEX_MINTH: Texture2D = preload("res://art/minth.png")
const TEX_NINN: Texture2D = preload("res://art/ninn.png")
const TEX_NOBU: Texture2D = preload("res://art/nobu.png")
const TEX_NONI: Texture2D = preload("res://art/noni.png")
const TEX_ONARU: Texture2D = preload("res://art/onaru.png")
const TEX_PEWKA: Texture2D = preload("res://art/pewka.png")
const TEX_PINGVIN: Texture2D = preload("res://art/pingvin.png")
const TEX_PROWLITH: Texture2D = preload("res://art/prowlith.png")
const TEX_RAHUA: Texture2D = preload("res://art/rahua.png")
const TEX_REAPWING: Texture2D = preload("res://art/reapwing.png")
const TEX_SATSU: Texture2D = preload("res://art/satsu.png")
const TEX_SERAPHLORA: Texture2D = preload("res://art/seraphlora.png")
const TEX_SILENTMANDER: Texture2D = preload("res://art/silentmander.png")
const TEX_SPROUT: Texture2D = preload("res://art/sprout.png")
const TEX_STELLROAR: Texture2D = preload("res://art/stellroar.png")
const TEX_TENROH: Texture2D = preload("res://art/tenroh.png")
const TEX_TIDERAY: Texture2D = preload("res://art/tideray.png")
const TEX_ULFA: Texture2D = preload("res://art/ulfa.png")
const TEX_UNTITLED_ARTWORK: Texture2D = preload("res://art/untitled_artwork.png")
const TEX_VIROWL: Texture2D = preload("res://art/virowl.png")
const UI_GLIDRAGON: Texture2D = preload("res://art/portraits/glidragon.png")
const UI_GLIDRAPTOR: Texture2D = preload("res://art/portraits/glidraptor.png")
const UI_GLIM: Texture2D = preload("res://art/portraits/glim.png")
const UI_GORZARA: Texture2D = preload("res://art/portraits/gorzara.png")
const UI_GRAVURN: Texture2D = preload("res://art/portraits/gravurn.png")
const UI_GRINBLE: Texture2D = preload("res://art/portraits/grinble.png")
const UI_IRIM: Texture2D = preload("res://art/portraits/irim.png")
const UI_KANO: Texture2D = preload("res://art/portraits/kano.png")
const UI_KETU: Texture2D = preload("res://art/portraits/ketu.png")
const UI_KITPIN: Texture2D = preload("res://art/portraits/kitpin.png")
const UI_LUMI: Texture2D = preload("res://art/portraits/lumi.png")
const UI_MIDOSENKA: Texture2D = preload("res://art/portraits/midosenka.png")
const UI_MINTH: Texture2D = preload("res://art/portraits/minth.png")
const UI_NINN: Texture2D = preload("res://art/portraits/ninn.png")
const UI_NOBU: Texture2D = preload("res://art/portraits/nobu.png")
const UI_NONI: Texture2D = preload("res://art/portraits/noni.png")
const UI_ONARU: Texture2D = preload("res://art/portraits/onaru.png")
const UI_PEWKA: Texture2D = preload("res://art/portraits/pewka.png")
const UI_PINGVIN: Texture2D = preload("res://art/portraits/pingvin.png")
const UI_PROWLITH: Texture2D = preload("res://art/portraits/prowlith.png")
const UI_RAHUA: Texture2D = preload("res://art/portraits/rahua.png")
const UI_REAPWING: Texture2D = preload("res://art/portraits/reapwing.png")
const UI_SATSU: Texture2D = preload("res://art/portraits/satsu.png")
const UI_SERAPHLORA: Texture2D = preload("res://art/portraits/seraphlora.png")
const UI_SILENTMANDER: Texture2D = preload("res://art/portraits/silentmander.png")
const UI_SPROUT: Texture2D = preload("res://art/portraits/sprout.png")
const UI_STELLROAR: Texture2D = preload("res://art/portraits/stellroar.png")
const UI_TENROH: Texture2D = preload("res://art/portraits/tenroh.png")
const UI_TIDERAY: Texture2D = preload("res://art/portraits/tideray.png")
const UI_ULFA: Texture2D = preload("res://art/portraits/ulfa.png")
const UI_UNTITLED_ARTWORK: Texture2D = preload("res://art/portraits/untitled_artwork.png")
const UI_VIROWL: Texture2D = preload("res://art/portraits/virowl.png")
const CREATURES := {
	"koikoi": {"name": "Koikoi", "texture": TEX_KOIKOI, "portrait": UI_KOIKOI, "weight": 18},
	"kujira": {"name": "Kujira", "texture": TEX_KUJIRA, "portrait": UI_KUJIRA, "weight": 3},
	"abadom": {"name": "Abadom", "texture": TEX_ABADOM, "portrait": UI_ABADOM, "weight": 4},
	"akhel": {"name": "Akhel", "texture": TEX_AKHEL, "portrait": UI_AKHEL, "weight": 10},
	"algen": {"name": "Algen", "texture": TEX_ALGEN, "portrait": UI_ALGEN, "weight": 14},
	"apala": {"name": "Apala", "texture": TEX_APALA, "portrait": UI_APALA, "weight": 5},
	"aurehawk": {"name": "Aurehawk", "texture": TEX_AUREHAWK, "portrait": UI_AUREHAWK, "weight": 5},
	"azatie": {"name": "Azatie", "texture": TEX_AZATIE, "portrait": UI_AZATIE, "weight": 2},
	"bigroot": {"name": "Bigroot", "texture": TEX_BIGROOT, "portrait": UI_BIGROOT, "weight": 5},
	"bonia": {"name": "Bonia", "texture": TEX_BONIA, "portrait": UI_BONIA, "weight": 14},
	"canthos": {"name": "Canthos", "texture": TEX_CANTHOS, "portrait": UI_CANTHOS, "weight": 12},
	"carapex": {"name": "Carapex", "texture": TEX_CARAPEX, "portrait": UI_CARAPEX, "weight": 10},
	"coralith": {"name": "Coralith", "texture": TEX_CORALITH, "portrait": UI_CORALITH, "weight": 5},
	"dracosoar": {"name": "Dracosoar", "texture": TEX_DRACOSOAR, "portrait": UI_DRACOSOAR, "weight": 2},
	"dribble": {"name": "Dribble", "texture": TEX_DRIBBLE, "portrait": UI_DRIBBLE, "weight": 14},
	"dweller": {"name": "Dweller", "texture": TEX_DWELLER, "portrait": UI_DWELLER, "weight": 5},
	"echo": {"name": "Echo", "texture": TEX_ECHO, "portrait": UI_ECHO, "weight": 16},
	"elios": {"name": "Elios", "texture": TEX_ELIOS, "portrait": UI_ELIOS, "weight": 13},
	"flic": {"name": "Flic", "texture": TEX_FLIC, "portrait": UI_FLIC, "weight": 16},
	"glau": {"name": "Glau", "texture": TEX_GLAU, "portrait": UI_GLAU, "weight": 13},
	"glidragon": {"name": "Glidragon", "texture": TEX_GLIDRAGON, "portrait": UI_GLIDRAGON, "weight": 12},
	"glidraptor": {"name": "Glidraptor", "texture": TEX_GLIDRAPTOR, "portrait": UI_GLIDRAPTOR, "weight": 5},
	"glim": {"name": "Glim", "texture": TEX_GLIM, "portrait": UI_GLIM, "weight": 16},
	"gorzara": {"name": "Gorzara", "texture": TEX_GORZARA, "portrait": UI_GORZARA, "weight": 2},
	"gravurn": {"name": "Gravurn", "texture": TEX_GRAVURN, "portrait": UI_GRAVURN, "weight": 2},
	"grinble": {"name": "Grinble", "texture": TEX_GRINBLE, "portrait": UI_GRINBLE, "weight": 14},
	"irim": {"name": "Irim", "texture": TEX_IRIM, "portrait": UI_IRIM, "weight": 12},
	"kano": {"name": "Kano", "texture": TEX_KANO, "portrait": UI_KANO, "weight": 2},
	"ketu": {"name": "Ketu", "texture": TEX_KETU, "portrait": UI_KETU, "weight": 13},
	"kitpin": {"name": "Kitpin", "texture": TEX_KITPIN, "portrait": UI_KITPIN, "weight": 14},
	"lumi": {"name": "Lumi", "texture": TEX_LUMI, "portrait": UI_LUMI, "weight": 14},
	"midosenka": {"name": "Midosenka", "texture": TEX_MIDOSENKA, "portrait": UI_MIDOSENKA, "weight": 5},
	"minth": {"name": "Minth", "texture": TEX_MINTH, "portrait": UI_MINTH, "weight": 12},
	"ninn": {"name": "Ninn", "texture": TEX_NINN, "portrait": UI_NINN, "weight": 12},
	"nobu": {"name": "Nobu", "texture": TEX_NOBU, "portrait": UI_NOBU, "weight": 11},
	"noni": {"name": "Noni", "texture": TEX_NONI, "portrait": UI_NONI, "weight": 16},
	"onaru": {"name": "Onaru", "texture": TEX_ONARU, "portrait": UI_ONARU, "weight": 16},
	"pewka": {"name": "Pewka", "texture": TEX_PEWKA, "portrait": UI_PEWKA, "weight": 14},
	"pingvin": {"name": "Pingvin", "texture": TEX_PINGVIN, "portrait": UI_PINGVIN, "weight": 13},
	"prowlith": {"name": "Prowlith", "texture": TEX_PROWLITH, "portrait": UI_PROWLITH, "weight": 14},
	"rahua": {"name": "Rahua", "texture": TEX_RAHUA, "portrait": UI_RAHUA, "weight": 5},
	"reapwing": {"name": "Reapwing", "texture": TEX_REAPWING, "portrait": UI_REAPWING, "weight": 11},
	"satsu": {"name": "Satsu", "texture": TEX_SATSU, "portrait": UI_SATSU, "weight": 14},
	"seraphlora": {"name": "Seraphlora", "texture": TEX_SERAPHLORA, "portrait": UI_SERAPHLORA, "weight": 5},
	"silentmander": {"name": "Silentmander", "texture": TEX_SILENTMANDER, "portrait": UI_SILENTMANDER, "weight": 13},
	"sprout": {"name": "Sprout", "texture": TEX_SPROUT, "portrait": UI_SPROUT, "weight": 18},
	"stellroar": {"name": "Stellroar", "texture": TEX_STELLROAR, "portrait": UI_STELLROAR, "weight": 5},
	"tenroh": {"name": "Tenroh", "texture": TEX_TENROH, "portrait": UI_TENROH, "weight": 2},
	"tideray": {"name": "Tideray", "texture": TEX_TIDERAY, "portrait": UI_TIDERAY, "weight": 14},
	"ulfa": {"name": "Ulfa", "texture": TEX_ULFA, "portrait": UI_ULFA, "weight": 14},
	"untitled_artwork": {"name": "Unnamed", "texture": TEX_UNTITLED_ARTWORK, "portrait": UI_UNTITLED_ARTWORK, "weight": 10},
	"virowl": {"name": "Virowl", "texture": TEX_VIROWL, "portrait": UI_VIROWL, "weight": 14}
}

# Gold form art uses real metallic recolors for every species, not a flat tint.
const GOLD_TEXTURES := {
	"abadom": preload("res://art/gold/abadom.png"),
	"akhel": preload("res://art/gold/akhel.png"),
	"algen": preload("res://art/gold/algen.png"),
	"apala": preload("res://art/gold/apala.png"),
	"aurehawk": preload("res://art/gold/aurehawk.png"),
	"azatie": preload("res://art/gold/azatie.png"),
	"bigroot": preload("res://art/gold/bigroot.png"),
	"bonia": preload("res://art/gold/bonia.png"),
	"canthos": preload("res://art/gold/canthos.png"),
	"carapex": preload("res://art/gold/carapex.png"),
	"coralith": preload("res://art/gold/coralith.png"),
	"dracosoar": preload("res://art/gold/dracosoar.png"),
	"dribble": preload("res://art/gold/dribble.png"),
	"dweller": preload("res://art/gold/dweller.png"),
	"echo": preload("res://art/gold/echo.png"),
	"elios": preload("res://art/gold/elios.png"),
	"flic": preload("res://art/gold/flic.png"),
	"glau": preload("res://art/gold/glau.png"),
	"glidragon": preload("res://art/gold/glidragon.png"),
	"glidraptor": preload("res://art/gold/glidraptor.png"),
	"glim": preload("res://art/gold/glim.png"),
	"gorzara": preload("res://art/gold/gorzara.png"),
	"gravurn": preload("res://art/gold/gravurn.png"),
	"grinble": preload("res://art/gold/grinble.png"),
	"irim": preload("res://art/gold/irim.png"),
	"kano": preload("res://art/gold/kano.png"),
	"ketu": preload("res://art/gold/ketu.png"),
	"kitpin": preload("res://art/gold/kitpin.png"),
	"koikoi": preload("res://art/gold/koikoi.png"),
	"kujira": preload("res://art/gold/kujira.png"),
	"lumi": preload("res://art/gold/lumi.png"),
	"midosenka": preload("res://art/gold/midosenka.png"),
	"minth": preload("res://art/gold/minth.png"),
	"ninn": preload("res://art/gold/ninn.png"),
	"nobu": preload("res://art/gold/nobu.png"),
	"noni": preload("res://art/gold/noni.png"),
	"onaru": preload("res://art/gold/onaru.png"),
	"pewka": preload("res://art/gold/pewka.png"),
	"pingvin": preload("res://art/gold/pingvin.png"),
	"prowlith": preload("res://art/gold/prowlith.png"),
	"rahua": preload("res://art/gold/rahua.png"),
	"reapwing": preload("res://art/gold/reapwing.png"),
	"satsu": preload("res://art/gold/satsu.png"),
	"seraphlora": preload("res://art/gold/seraphlora.png"),
	"silentmander": preload("res://art/gold/silentmander.png"),
	"sprout": preload("res://art/gold/sprout.png"),
	"stellroar": preload("res://art/gold/stellroar.png"),
	"tenroh": preload("res://art/gold/tenroh.png"),
	"tideray": preload("res://art/gold/tideray.png"),
	"ulfa": preload("res://art/gold/ulfa.png"),
	"untitled_artwork": preload("res://art/gold/untitled_artwork.png"),
	"virowl": preload("res://art/gold/virowl.png")
}
const GOLD_PORTRAITS := {
	"abadom": preload("res://art/portraits_gold/abadom.png"),
	"akhel": preload("res://art/portraits_gold/akhel.png"),
	"algen": preload("res://art/portraits_gold/algen.png"),
	"apala": preload("res://art/portraits_gold/apala.png"),
	"aurehawk": preload("res://art/portraits_gold/aurehawk.png"),
	"azatie": preload("res://art/portraits_gold/azatie.png"),
	"bigroot": preload("res://art/portraits_gold/bigroot.png"),
	"bonia": preload("res://art/portraits_gold/bonia.png"),
	"canthos": preload("res://art/portraits_gold/canthos.png"),
	"carapex": preload("res://art/portraits_gold/carapex.png"),
	"coralith": preload("res://art/portraits_gold/coralith.png"),
	"dracosoar": preload("res://art/portraits_gold/dracosoar.png"),
	"dribble": preload("res://art/portraits_gold/dribble.png"),
	"dweller": preload("res://art/portraits_gold/dweller.png"),
	"echo": preload("res://art/portraits_gold/echo.png"),
	"elios": preload("res://art/portraits_gold/elios.png"),
	"flic": preload("res://art/portraits_gold/flic.png"),
	"glau": preload("res://art/portraits_gold/glau.png"),
	"glidragon": preload("res://art/portraits_gold/glidragon.png"),
	"glidraptor": preload("res://art/portraits_gold/glidraptor.png"),
	"glim": preload("res://art/portraits_gold/glim.png"),
	"gorzara": preload("res://art/portraits_gold/gorzara.png"),
	"gravurn": preload("res://art/portraits_gold/gravurn.png"),
	"grinble": preload("res://art/portraits_gold/grinble.png"),
	"irim": preload("res://art/portraits_gold/irim.png"),
	"kano": preload("res://art/portraits_gold/kano.png"),
	"ketu": preload("res://art/portraits_gold/ketu.png"),
	"kitpin": preload("res://art/portraits_gold/kitpin.png"),
	"koikoi": preload("res://art/portraits_gold/koikoi.png"),
	"kujira": preload("res://art/portraits_gold/kujira.png"),
	"lumi": preload("res://art/portraits_gold/lumi.png"),
	"midosenka": preload("res://art/portraits_gold/midosenka.png"),
	"minth": preload("res://art/portraits_gold/minth.png"),
	"ninn": preload("res://art/portraits_gold/ninn.png"),
	"nobu": preload("res://art/portraits_gold/nobu.png"),
	"noni": preload("res://art/portraits_gold/noni.png"),
	"onaru": preload("res://art/portraits_gold/onaru.png"),
	"pewka": preload("res://art/portraits_gold/pewka.png"),
	"pingvin": preload("res://art/portraits_gold/pingvin.png"),
	"prowlith": preload("res://art/portraits_gold/prowlith.png"),
	"rahua": preload("res://art/portraits_gold/rahua.png"),
	"reapwing": preload("res://art/portraits_gold/reapwing.png"),
	"satsu": preload("res://art/portraits_gold/satsu.png"),
	"seraphlora": preload("res://art/portraits_gold/seraphlora.png"),
	"silentmander": preload("res://art/portraits_gold/silentmander.png"),
	"sprout": preload("res://art/portraits_gold/sprout.png"),
	"stellroar": preload("res://art/portraits_gold/stellroar.png"),
	"tenroh": preload("res://art/portraits_gold/tenroh.png"),
	"tideray": preload("res://art/portraits_gold/tideray.png"),
	"ulfa": preload("res://art/portraits_gold/ulfa.png"),
	"untitled_artwork": preload("res://art/portraits_gold/untitled_artwork.png"),
	"virowl": preload("res://art/portraits_gold/virowl.png")
}

const GHOST_TEXTURES := {
	"abadom": preload("res://art/ghost/abadom.png"),
	"akhel": preload("res://art/ghost/akhel.png"),
	"algen": preload("res://art/ghost/algen.png"),
	"apala": preload("res://art/ghost/apala.png"),
	"aurehawk": preload("res://art/ghost/aurehawk.png"),
	"azatie": preload("res://art/ghost/azatie.png"),
	"bigroot": preload("res://art/ghost/bigroot.png"),
	"bonia": preload("res://art/ghost/bonia.png"),
	"canthos": preload("res://art/ghost/canthos.png"),
	"carapex": preload("res://art/ghost/carapex.png"),
	"coralith": preload("res://art/ghost/coralith.png"),
	"dracosoar": preload("res://art/ghost/dracosoar.png"),
	"dribble": preload("res://art/ghost/dribble.png"),
	"dweller": preload("res://art/ghost/dweller.png"),
	"echo": preload("res://art/ghost/echo.png"),
	"elios": preload("res://art/ghost/elios.png"),
	"flic": preload("res://art/ghost/flic.png"),
	"glau": preload("res://art/ghost/glau.png"),
	"glidragon": preload("res://art/ghost/glidragon.png"),
	"glidraptor": preload("res://art/ghost/glidraptor.png"),
	"glim": preload("res://art/ghost/glim.png"),
	"gorzara": preload("res://art/ghost/gorzara.png"),
	"gravurn": preload("res://art/ghost/gravurn.png"),
	"grinble": preload("res://art/ghost/grinble.png"),
	"irim": preload("res://art/ghost/irim.png"),
	"kano": preload("res://art/ghost/kano.png"),
	"ketu": preload("res://art/ghost/ketu.png"),
	"kitpin": preload("res://art/ghost/kitpin.png"),
	"koikoi": preload("res://art/ghost/koikoi.png"),
	"kujira": preload("res://art/ghost/kujira.png"),
	"lumi": preload("res://art/ghost/lumi.png"),
	"midosenka": preload("res://art/ghost/midosenka.png"),
	"minth": preload("res://art/ghost/minth.png"),
	"ninn": preload("res://art/ghost/ninn.png"),
	"nobu": preload("res://art/ghost/nobu.png"),
	"noni": preload("res://art/ghost/noni.png"),
	"onaru": preload("res://art/ghost/onaru.png"),
	"pewka": preload("res://art/ghost/pewka.png"),
	"pingvin": preload("res://art/ghost/pingvin.png"),
	"prowlith": preload("res://art/ghost/prowlith.png"),
	"rahua": preload("res://art/ghost/rahua.png"),
	"reapwing": preload("res://art/ghost/reapwing.png"),
	"satsu": preload("res://art/ghost/satsu.png"),
	"seraphlora": preload("res://art/ghost/seraphlora.png"),
	"silentmander": preload("res://art/ghost/silentmander.png"),
	"sprout": preload("res://art/ghost/sprout.png"),
	"stellroar": preload("res://art/ghost/stellroar.png"),
	"tenroh": preload("res://art/ghost/tenroh.png"),
	"tideray": preload("res://art/ghost/tideray.png"),
	"ulfa": preload("res://art/ghost/ulfa.png"),
	"untitled_artwork": preload("res://art/ghost/untitled_artwork.png"),
	"virowl": preload("res://art/ghost/virowl.png")
}
const GHOST_PORTRAITS := {
	"abadom": preload("res://art/portraits_ghost/abadom.png"),
	"akhel": preload("res://art/portraits_ghost/akhel.png"),
	"algen": preload("res://art/portraits_ghost/algen.png"),
	"apala": preload("res://art/portraits_ghost/apala.png"),
	"aurehawk": preload("res://art/portraits_ghost/aurehawk.png"),
	"azatie": preload("res://art/portraits_ghost/azatie.png"),
	"bigroot": preload("res://art/portraits_ghost/bigroot.png"),
	"bonia": preload("res://art/portraits_ghost/bonia.png"),
	"canthos": preload("res://art/portraits_ghost/canthos.png"),
	"carapex": preload("res://art/portraits_ghost/carapex.png"),
	"coralith": preload("res://art/portraits_ghost/coralith.png"),
	"dracosoar": preload("res://art/portraits_ghost/dracosoar.png"),
	"dribble": preload("res://art/portraits_ghost/dribble.png"),
	"dweller": preload("res://art/portraits_ghost/dweller.png"),
	"echo": preload("res://art/portraits_ghost/echo.png"),
	"elios": preload("res://art/portraits_ghost/elios.png"),
	"flic": preload("res://art/portraits_ghost/flic.png"),
	"glau": preload("res://art/portraits_ghost/glau.png"),
	"glidragon": preload("res://art/portraits_ghost/glidragon.png"),
	"glidraptor": preload("res://art/portraits_ghost/glidraptor.png"),
	"glim": preload("res://art/portraits_ghost/glim.png"),
	"gorzara": preload("res://art/portraits_ghost/gorzara.png"),
	"gravurn": preload("res://art/portraits_ghost/gravurn.png"),
	"grinble": preload("res://art/portraits_ghost/grinble.png"),
	"irim": preload("res://art/portraits_ghost/irim.png"),
	"kano": preload("res://art/portraits_ghost/kano.png"),
	"ketu": preload("res://art/portraits_ghost/ketu.png"),
	"kitpin": preload("res://art/portraits_ghost/kitpin.png"),
	"koikoi": preload("res://art/portraits_ghost/koikoi.png"),
	"kujira": preload("res://art/portraits_ghost/kujira.png"),
	"lumi": preload("res://art/portraits_ghost/lumi.png"),
	"midosenka": preload("res://art/portraits_ghost/midosenka.png"),
	"minth": preload("res://art/portraits_ghost/minth.png"),
	"ninn": preload("res://art/portraits_ghost/ninn.png"),
	"nobu": preload("res://art/portraits_ghost/nobu.png"),
	"noni": preload("res://art/portraits_ghost/noni.png"),
	"onaru": preload("res://art/portraits_ghost/onaru.png"),
	"pewka": preload("res://art/portraits_ghost/pewka.png"),
	"pingvin": preload("res://art/portraits_ghost/pingvin.png"),
	"prowlith": preload("res://art/portraits_ghost/prowlith.png"),
	"rahua": preload("res://art/portraits_ghost/rahua.png"),
	"reapwing": preload("res://art/portraits_ghost/reapwing.png"),
	"satsu": preload("res://art/portraits_ghost/satsu.png"),
	"seraphlora": preload("res://art/portraits_ghost/seraphlora.png"),
	"silentmander": preload("res://art/portraits_ghost/silentmander.png"),
	"sprout": preload("res://art/portraits_ghost/sprout.png"),
	"stellroar": preload("res://art/portraits_ghost/stellroar.png"),
	"tenroh": preload("res://art/portraits_ghost/tenroh.png"),
	"tideray": preload("res://art/portraits_ghost/tideray.png"),
	"ulfa": preload("res://art/portraits_ghost/ulfa.png"),
	"untitled_artwork": preload("res://art/portraits_ghost/untitled_artwork.png"),
	"virowl": preload("res://art/portraits_ghost/virowl.png")
}

const WORLD := Vector2(2400, 1800) * 2.23606797749979 # sqrt(5): exactly five times the area.
const WORLD_GENERATOR = preload("res://scripts/world_generator.gd")
const MAP_BORDER = preload("res://scripts/map_border.gd")
var map_border: Node2D
var world_seed := -1
var world_roads: Array = []
var world_patches: Array = []
var world_grass: Array = []
var terrain_noise := FastNoiseLite.new()
var visible_world := Rect2()
const TREE_ART: Texture2D = preload("res://art/obstacle_trees.png")
const BOULDER_ART: Texture2D = preload("res://art/obstacle_boulders.png")
const BOULDER_FRACTION := 0.2
const TREE_SIZE_MULTIPLIER := 1.5
var tree_texture: AtlasTexture
var boulder_texture: AtlasTexture
var tree_bodies: Array[StaticBody2D] = []
var player_body: CharacterBody2D
const SHINY_TEXTURES := {
	"abadom": preload("res://art/shiny/abadom.png"),
	"akhel": preload("res://art/shiny/akhel.png"),
	"algen": preload("res://art/shiny/algen.png"),
	"apala": preload("res://art/shiny/apala.png"),
	"aurehawk": preload("res://art/shiny/aurehawk.png"),
	"azatie": preload("res://art/shiny/azatie.png"),
	"bigroot": preload("res://art/shiny/bigroot.png"),
	"bonia": preload("res://art/shiny/bonia.png"),
	"canthos": preload("res://art/shiny/canthos.png"),
	"carapex": preload("res://art/shiny/carapex.png"),
	"coralith": preload("res://art/shiny/coralith.png"),
	"dracosoar": preload("res://art/shiny/dracosoar.png"),
	"dribble": preload("res://art/shiny/dribble.png"),
	"dweller": preload("res://art/shiny/dweller.png"),
	"echo": preload("res://art/shiny/echo.png"),
	"elios": preload("res://art/shiny/elios.png"),
	"flic": preload("res://art/shiny/flic.png"),
	"glau": preload("res://art/shiny/glau.png"),
	"glidragon": preload("res://art/shiny/glidragon.png"),
	"glidraptor": preload("res://art/shiny/glidraptor.png"),
	"glim": preload("res://art/shiny/glim.png"),
	"gorzara": preload("res://art/shiny/gorzara.png"),
	"gravurn": preload("res://art/shiny/gravurn.png"),
	"grinble": preload("res://art/shiny/grinble.png"),
	"irim": preload("res://art/shiny/irim.png"),
	"kano": preload("res://art/shiny/kano.png"),
	"ketu": preload("res://art/shiny/ketu.png"),
	"kitpin": preload("res://art/shiny/kitpin.png"),
	"koikoi": preload("res://art/shiny/koikoi.png"),
	"kujira": preload("res://art/shiny/kujira.png"),
	"lumi": preload("res://art/shiny/lumi.png"),
	"midosenka": preload("res://art/shiny/midosenka.png"),
	"minth": preload("res://art/shiny/minth.png"),
	"ninn": preload("res://art/shiny/ninn.png"),
	"nobu": preload("res://art/shiny/nobu.png"),
	"noni": preload("res://art/shiny/noni.png"),
	"onaru": preload("res://art/shiny/onaru.png"),
	"pewka": preload("res://art/shiny/pewka.png"),
	"pingvin": preload("res://art/shiny/pingvin.png"),
	"prowlith": preload("res://art/shiny/prowlith.png"),
	"rahua": preload("res://art/shiny/rahua.png"),
	"reapwing": preload("res://art/shiny/reapwing.png"),
	"satsu": preload("res://art/shiny/satsu.png"),
	"seraphlora": preload("res://art/shiny/seraphlora.png"),
	"silentmander": preload("res://art/shiny/silentmander.png"),
	"sprout": preload("res://art/shiny/sprout.png"),
	"stellroar": preload("res://art/shiny/stellroar.png"),
	"tenroh": preload("res://art/shiny/tenroh.png"),
	"tideray": preload("res://art/shiny/tideray.png"),
	"ulfa": preload("res://art/shiny/ulfa.png"),
	"untitled_artwork": preload("res://art/shiny/untitled_artwork.png"),
	"virowl": preload("res://art/shiny/virowl.png")
}
const SHINY_PORTRAITS := {
	"abadom": preload("res://art/portraits_shiny/abadom.png"),
	"akhel": preload("res://art/portraits_shiny/akhel.png"),
	"algen": preload("res://art/portraits_shiny/algen.png"),
	"apala": preload("res://art/portraits_shiny/apala.png"),
	"aurehawk": preload("res://art/portraits_shiny/aurehawk.png"),
	"azatie": preload("res://art/portraits_shiny/azatie.png"),
	"bigroot": preload("res://art/portraits_shiny/bigroot.png"),
	"bonia": preload("res://art/portraits_shiny/bonia.png"),
	"canthos": preload("res://art/portraits_shiny/canthos.png"),
	"carapex": preload("res://art/portraits_shiny/carapex.png"),
	"coralith": preload("res://art/portraits_shiny/coralith.png"),
	"dracosoar": preload("res://art/portraits_shiny/dracosoar.png"),
	"dribble": preload("res://art/portraits_shiny/dribble.png"),
	"dweller": preload("res://art/portraits_shiny/dweller.png"),
	"echo": preload("res://art/portraits_shiny/echo.png"),
	"elios": preload("res://art/portraits_shiny/elios.png"),
	"flic": preload("res://art/portraits_shiny/flic.png"),
	"glau": preload("res://art/portraits_shiny/glau.png"),
	"glidragon": preload("res://art/portraits_shiny/glidragon.png"),
	"glidraptor": preload("res://art/portraits_shiny/glidraptor.png"),
	"glim": preload("res://art/portraits_shiny/glim.png"),
	"gorzara": preload("res://art/portraits_shiny/gorzara.png"),
	"gravurn": preload("res://art/portraits_shiny/gravurn.png"),
	"grinble": preload("res://art/portraits_shiny/grinble.png"),
	"irim": preload("res://art/portraits_shiny/irim.png"),
	"kano": preload("res://art/portraits_shiny/kano.png"),
	"ketu": preload("res://art/portraits_shiny/ketu.png"),
	"kitpin": preload("res://art/portraits_shiny/kitpin.png"),
	"koikoi": preload("res://art/portraits_shiny/koikoi.png"),
	"kujira": preload("res://art/portraits_shiny/kujira.png"),
	"lumi": preload("res://art/portraits_shiny/lumi.png"),
	"midosenka": preload("res://art/portraits_shiny/midosenka.png"),
	"minth": preload("res://art/portraits_shiny/minth.png"),
	"ninn": preload("res://art/portraits_shiny/ninn.png"),
	"nobu": preload("res://art/portraits_shiny/nobu.png"),
	"noni": preload("res://art/portraits_shiny/noni.png"),
	"onaru": preload("res://art/portraits_shiny/onaru.png"),
	"pewka": preload("res://art/portraits_shiny/pewka.png"),
	"pingvin": preload("res://art/portraits_shiny/pingvin.png"),
	"prowlith": preload("res://art/portraits_shiny/prowlith.png"),
	"rahua": preload("res://art/portraits_shiny/rahua.png"),
	"reapwing": preload("res://art/portraits_shiny/reapwing.png"),
	"satsu": preload("res://art/portraits_shiny/satsu.png"),
	"seraphlora": preload("res://art/portraits_shiny/seraphlora.png"),
	"silentmander": preload("res://art/portraits_shiny/silentmander.png"),
	"sprout": preload("res://art/portraits_shiny/sprout.png"),
	"stellroar": preload("res://art/portraits_shiny/stellroar.png"),
	"tenroh": preload("res://art/portraits_shiny/tenroh.png"),
	"tideray": preload("res://art/portraits_shiny/tideray.png"),
	"ulfa": preload("res://art/portraits_shiny/ulfa.png"),
	"untitled_artwork": preload("res://art/portraits_shiny/untitled_artwork.png"),
	"virowl": preload("res://art/portraits_shiny/virowl.png")
}

const SAVE_PATH := "user://forgotten_grove_collection.json"
const SPIN_COST := 1
# 65% base triple-match rate; all other pulls still award gold.
const TRIPLE_CHANCE := 0.65
# Chance per paid pull, independent of base triple chance. Special pulls force a triple.
# Guarantees can raise the actual frequency when players go on dry streaks.
const SLOT_BLESSED_CHANCE := 0.01
const SLOT_CORRUPT_CHANCE := 0.01
const SLOT_GOLD_CHANCE := 0.001
const SLOT_VARIANT_PITY := 100
const SLOT_GOLD_PITY := 1000
const NEW_CREATURE_BIAS := 0.75
const OWNABLE_FORMS := ["normal", "corrupt", "blessed", "gold", "ghost", "shiny", "shiny+blessed", "shiny+corrupt"]
const HATCHERY_SLOT_COUNT := 4
const HATCHERY_UNLOCK_COST := [0, 4000, 8000, 16000]
const HATCHERY_BREED_SECONDS := 60.0
const HATCHERY_EGG_SECONDS := 540.0
const HATCHERY_FORMS := ["normal", "shiny", "blessed", "corrupt", "gold", "ghost", "shiny+blessed", "shiny+corrupt"]
# Shiny is exclusive to the hatchery; other traits inherit only from the parents.
# The rare stacked shiny/blessed and shiny/corrupt chance is 0.75% when relevant.
const HATCHERY_SHINY_CHANCE := 0.05
const HATCHERY_GHOST_INHERIT := 0.0001
const HATCHERY_GOLD_INHERIT := 0.001
const HATCHERY_BLESSED_INHERIT := 0.05
const HATCHERY_CORRUPT_INHERIT := 0.05
const HATCHERY_STACK_CHANCE := 0.0075
# Actual combat death only; leaving a run and extraction never qualify.
const GHOST_DEATH_CHANCE := 10000

# V15: Permanent progression belongs to the actual owned species + form.
# At a typical 10-minute extraction (~400 earned combat XP), only 10% is
# banked, so three successful runs earn roughly the first 120 EVO XP.
const EVO_COSTS := [120, 220, 360, 550, 800]
const TRAIL_LIFETIME := 2.0
const TRAIL_RADIUS := 17.0
const TRAIL_INTERVAL := 0.12
const TRAIL_STEP_DISTANCE := 19.0
const TRAIL_HIT_COOLDOWN := 0.55
const TRAIL_STATUS_DURATION := 3.1 # 2 ticks, at 1.5s and 3s
const TRAIL_DOT_INTERVAL := 1.5
const TRAIL_TITLES := ["NO TRAIL", "GREEN SLIME", "FLAME", "ICE", "PURPLE POISON", "RGB PRISM"]
const TRAIL_DESCRIPTIONS := [
    "No footsteps equipped",
    "Green slime • 0.75% of your creature's attack",
    "Fire • 1% attack + 0.25% burn / 1.5s",
    "Ice • 1.5% attack + 25% movement slow",
    "Poison • 1.5% attack + 0.25% poison / 1.5s",
    "RGB • 2% attack + 25% movement slow"
]
const GOLD_NO_MATCH := 10
const GOLD_DUPLICATE := 35
const CHIP_DROP_CHANCE := 0.10
const PICKUP_RADIUS := 38.0
const EXTRACTION_POINT := WORLD * 0.5
const EXTRACTION_UNLOCK_SECONDS := 45.0
const EXTRACTION_RADIUS := 95.0
# Run-only rarity: 0.50% Corrupt and 0.25% Blessed per enemy spawn.
# Together 0.75%, eight times rarer than V15's combined 6% rate.
# Variant enemies are ONLY Corrupt/Blessed; Gold forms never spawn in dungeon runs.
const CORRUPT_CHANCE := 0.005
const BLESSED_CHANCE := 0.0025

# Three real run materials are picked up in the world and banked on extraction.
# Existing chips, XP gems, creature forms, and evolution progress keep their rules.
const MATERIAL_IDS := ["grove_fiber", "crystal_shards", "ember_fragments"]
const MATERIAL_NAMES := {
    "grove_fiber": "Grove Fiber",
    "crystal_shards": "Crystal Shards",
    "ember_fragments": "Ember Fragments"
}
const MATERIAL_DROP_CHANCE := 0.22

# Readable bullet-hell enemy attacks. The warning is always locked to a position
# or direction when it begins: foes cannot re-aim at the end of a telegraph.
const WAVE_SECONDS := 28.0
const ATTACK_PATH_LENGTH := 720.0
const MAX_ATTACK_WARNINGS := 6
const MAX_ENEMY_PROJECTILES := 90
const BLAST_VISUAL_TIME := 0.38
# Ghost creatures evade 5% of incoming hits, whether contact or projectile.
const GHOST_EVASION_CHANCE := 0.05
const DAMAGE_NUMBER_LIFETIME := 0.86
const DAMAGE_NUMBER_LIMIT := 80

# All move ranks, temporary stats, and XP reset when a run ends.
const UPGRADE_POOL := ["heal", "shield", "dash", "nova", "power", "rapid", "vitality", "multishot"]
const UPGRADE_NAMES := {
	"heal": "LIFE BLOOM", "shield": "AEGIS WARD", "dash": "PHANTOM DASH", "nova": "METEOR NOVA",
	"power": "MIGHT", "rapid": "RAPID FIRE", "vitality": "IRON HEART", "multishot": "TWIN FANG"
}
const MAX_RANKS := {"heal": 5, "shield": 5, "dash": 5, "nova": 5, "power": 6, "rapid": 6, "vitality": 5, "multishot": 3}
# Permanent gold-purchased upgrades. Stored by species ID; all variants share them.
# The game has physical (contact and charges) and special (projectiles and blasts)
# damage. Each upgrade has a real effect, not just a menu counter.
const PERMANENT_UPGRADE_ORDER := [
	"hp", "phys_atk", "sp_atk", "phys_def", "sp_def", "stride", "reflexes",
	"reach", "regrowth", "magnet", "wisdom", "fortune", "repertoire"
]
const PERMANENT_UPGRADES := {
	"hp": {"name": "HP", "icon": "♥", "max": 10, "base_cost": 30, "detail": "+12 maximum HP per rank  •  max +120 HP"},
	"phys_atk": {"name": "Phys. Attack", "icon": "⚔", "max": 5, "base_cost": 45, "detail": "+4% basic attack damage  •  max +20%"},
	"sp_atk": {"name": "Sp. Attack", "icon": "✦", "max": 5, "base_cost": 45, "detail": "+4% Meteor Nova damage  •  max +20%"},
	"phys_def": {"name": "Phys. Defense", "icon": "◆", "max": 5, "base_cost": 45, "detail": "-4% contact / charge damage  •  max -20%"},
	"sp_def": {"name": "Sp. Defense", "icon": "◈", "max": 5, "base_cost": 45, "detail": "-4% projectile / blast damage  •  max -20%"},
	"stride": {"name": "Stride", "icon": "➤", "max": 5, "base_cost": 45, "detail": "+2.5% movement speed  •  max +12.5%"},
	"reflexes": {"name": "Reflexes", "icon": "◷", "max": 5, "base_cost": 55, "detail": "-3% ability cooldowns  •  max -15%"},
	"reach": {"name": "Long Reach", "icon": "➳", "max": 5, "base_cost": 45, "detail": "+5% projectile size / +4% range per rank"},
	"regrowth": {"name": "Regrowth", "icon": "✿", "max": 5, "base_cost": 50, "detail": "+0.2 HP / second  •  max +1 HP / second"},
	"magnet": {"name": "Magnet", "icon": "⊂", "max": 5, "base_cost": 40, "detail": "+5% chip / XP pickup radius per rank"},
	"wisdom": {"name": "Wisdom", "icon": "✧", "max": 5, "base_cost": 45, "detail": "+3% experience earned  •  max +15%"},
	"fortune": {"name": "Fortune", "icon": "●", "max": 5, "base_cost": 40, "detail": "+5% gold from slot rewards  •  max +25%"},
	"repertoire": {"name": "Repertoire", "icon": "▣", "max": 1, "base_cost": 225, "detail": "Choose an extra active move at the start of each run"}
}

const CREATURE_SIGNATURES := {
	"koikoi": {"name": "Hunter Fang", "style": "basic", "bonus": {"rapid": 1}, "desc": "Fast precise fang bolts. Starts each run with Rapid Fire I."},
	"kujira": {"name": "Tidal Wake", "style": "wave", "bonus": {"heal": 1}, "desc": "Wide cresting waves that pierce targets. Starts each run with Life Bloom I."},
	"abadom": {"name": "Demon Gloves", "style": "blast", "bonus": {"power": 1}, "desc": "Heavy cursed blasts that hit extra hard. Starts each run with Might I."},
	"akhel": {"name": "Frost Shard", "style": "pierce", "bonus": {"shield": 1}, "desc": "Piercing ice lances that punch through foes. Starts each run with Aegis Ward I."},
	"algen": {"name": "Mire Spore", "style": "seed", "bonus": {"vitality": 1}, "desc": "Lobs bursting spores with a small splash. Starts each run with Iron Heart I."},
	"apala": {"name": "Moonfeather", "style": "feather", "bonus": {"dash": 2}, "desc": "Swift crescent feathers with agile movement. Starts each run with Phantom Dash II."},
	"aurehawk": {"name": "Sun Talon", "style": "pierce", "bonus": {"rapid": 1}, "desc": "Swift piercing sun talons. Starts each run with Rapid Fire I."},
	"azatie": {"name": "Umbral Wing", "style": "shadow", "bonus": {"multishot": 1}, "desc": "Shadow feathers fan outward and pierce. Starts each run with Twin Fang I."},
	"bigroot": {"name": "Lantern Seed", "style": "seed", "bonus": {"vitality": 1}, "desc": "Glowing seeds burst in sturdy volleys. Starts each run with Iron Heart I."},
	"bonia": {"name": "Thorn Rush", "style": "prism", "bonus": {"multishot": 1}, "desc": "A clustered rush of thorny shards. Starts each run with Twin Fang I."},
	"canthos": {"name": "Infernal Claw", "style": "blast", "bonus": {"power": 1}, "desc": "Explosive infernal slashes with splash damage. Starts each run with Might I."},
	"carapex": {"name": "Shell Burst", "style": "shell", "bonus": {"shield": 1}, "desc": "A close-range shell shotgun blast. Starts each run with Aegis Ward I."},
	"coralith": {"name": "Coral Lance", "style": "pierce", "bonus": {"nova": 1}, "desc": "Coral spears skewer lines of enemies. Starts each run with Meteor Nova I."},
	"dracosoar": {"name": "Sky Tyrant", "style": "double", "bonus": {"dash": 2}, "desc": "Twin aerial bolts with strong mobility. Starts each run with Phantom Dash II."},
	"dribble": {"name": "Bubble Pop", "style": "bubble", "bonus": {"heal": 1}, "desc": "Bouncy bubbles that pop in a splash. Starts each run with Life Bloom I."},
	"dweller": {"name": "Gloom Ray", "style": "shadow", "bonus": {"shield": 1}, "desc": "Dark rays pierce and linger. Starts each run with Aegis Ward I."},
	"echo": {"name": "Sonic Note", "style": "feather", "bonus": {"rapid": 1}, "desc": "Resonant notes fly in quick volleys. Starts each run with Rapid Fire I."},
	"elios": {"name": "Sunburst", "style": "double", "bonus": {"heal": 1}, "desc": "Twin holy motes launch in bright pairs. Starts each run with Life Bloom I."},
	"flic": {"name": "Ember Dart", "style": "basic", "bonus": {"rapid": 2}, "desc": "Very fast ember darts for aggressive builds. Starts each run with Rapid Fire II."},
	"glau": {"name": "Prism Bloom", "style": "prism", "bonus": {"multishot": 1}, "desc": "Crystalline prism shards spread beautifully. Starts each run with Twin Fang I."},
	"glidragon": {"name": "Sky Claw", "style": "double", "bonus": {"dash": 1}, "desc": "Twin dragon bolts favor quick aerial movement. Starts with Phantom Dash I."},
	"glidraptor": {"name": "Raptor Lance", "style": "pierce", "bonus": {"rapid": 1}, "desc": "Piercing raptor strikes cut through a line of foes. Starts with Rapid Fire I."},
	"glim": {"name": "Wisp Spark", "style": "shadow", "bonus": {"rapid": 1}, "desc": "Quick spectral sparks flicker through enemies. Starts with Rapid Fire I."},
	"gorzara": {"name": "Volcanic Roar", "style": "blast", "bonus": {"power": 1}, "desc": "Explosive magma shots detonate on impact. Starts with Might I."},
	"gravurn": {"name": "Gravefire", "style": "shadow", "bonus": {"shield": 1}, "desc": "Cursed bolts pierce enemies behind their target. Starts with Aegis Ward I."},
	"grinble": {"name": "Phantom Claw", "style": "shadow", "bonus": {"dash": 1}, "desc": "Ghostly claws fan out across the battlefield. Starts with Phantom Dash I."},
	"irim": {"name": "Soul Shiver", "style": "shadow", "bonus": {"rapid": 1}, "desc": "Restless spirit bolts pass through enemy ranks. Starts with Rapid Fire I."},
	"kano": {"name": "Ancient Breath", "style": "wave", "bonus": {"power": 1}, "desc": "An ancient dragon spreads waves of energy. Starts with Might I."},
	"ketu": {"name": "Coal Burst", "style": "blast", "bonus": {"rapid": 1}, "desc": "Volcanic embers explode in a small radius. Starts with Rapid Fire I."},
	"kitpin": {"name": "Hex Needle", "style": "prism", "bonus": {"multishot": 1}, "desc": "Needle-like magic flies in a tight spread. Starts with Twin Fang I."},
	"lumi": {"name": "Candleflare", "style": "blast", "bonus": {"heal": 1}, "desc": "Living candlelight burns bright and restores hope. Starts with Life Bloom I."},
	"midosenka": {"name": "Verdant Blades", "style": "prism", "bonus": {"multishot": 1}, "desc": "Emerald blades fan out in sharp volleys. Starts with Twin Fang I."},
	"minth": {"name": "Night Pulse", "style": "shadow", "bonus": {"dash": 1}, "desc": "A dark familiar sends out piercing energy. Starts with Phantom Dash I."},
	"ninn": {"name": "Swift Slice", "style": "feather", "bonus": {"rapid": 1}, "desc": "Nimble slashes release rapid cutting waves. Starts with Rapid Fire I."},
	"nobu": {"name": "Sprout Seed", "style": "seed", "bonus": {"vitality": 1}, "desc": "Forest seeds scatter and burst against foes. Starts with Iron Heart I."},
	"noni": {"name": "Dusk Spark", "style": "basic", "bonus": {"rapid": 1}, "desc": "Fast sparks reward steady movement and aim. Starts with Rapid Fire I."},
	"onaru": {"name": "Panda Palm", "style": "shell", "bonus": {"shield": 1}, "desc": "A close-range palm flurry spreads several shots. Starts with Aegis Ward I."},
	"pewka": {"name": "Moonwhisk", "style": "feather", "bonus": {"dash": 1}, "desc": "Airy crescent cuts launch in swift pairs. Starts with Phantom Dash I."},
	"pingvin": {"name": "Ice Peck", "style": "pierce", "bonus": {"shield": 1}, "desc": "Icy beak-shaped shards pierce their targets. Starts with Aegis Ward I."},
	"prowlith": {"name": "Jungle Pounce", "style": "double", "bonus": {"dash": 1}, "desc": "Two quick strikes reward aggressive movement. Starts with Phantom Dash I."},
	"rahua": {"name": "Spirit Bloom", "style": "seed", "bonus": {"nova": 1}, "desc": "Mystic blossoms burst into magical fragments. Starts with Meteor Nova I."},
	"reapwing": {"name": "Reaper Wing", "style": "feather", "bonus": {"rapid": 1}, "desc": "Spectral feathers sweep across distant foes. Starts with Rapid Fire I."},
	"satsu": {"name": "Silent Blade", "style": "pierce", "bonus": {"dash": 1}, "desc": "A silent slash cuts through armored targets. Starts with Phantom Dash I."},
	"seraphlora": {"name": "Sacred Petals", "style": "prism", "bonus": {"heal": 1}, "desc": "Shining petal blades fan out in a holy arc. Starts with Life Bloom I."},
	"silentmander": {"name": "Shade Spit", "style": "shadow", "bonus": {"shield": 1}, "desc": "Quiet shadow shots pierce enemy lines. Starts with Aegis Ward I."},
	"sprout": {"name": "Root Burst", "style": "seed", "bonus": {"vitality": 1}, "desc": "A hardy forest sprout lobs bursting seeds. Starts with Iron Heart I."},
	"stellroar": {"name": "Star Howl", "style": "wave", "bonus": {"power": 1}, "desc": "Celestial howls scatter piercing star waves. Starts with Might I."},
	"tenroh": {"name": "Thunder Fang", "style": "pierce", "bonus": {"rapid": 1}, "desc": "Legendary piercing thunder bolts fly quickly. Starts with Rapid Fire I."},
	"tideray": {"name": "Tidal Splash", "style": "bubble", "bonus": {"heal": 1}, "desc": "Water bubbles burst around their targets. Starts with Life Bloom I."},
	"ulfa": {"name": "Moon Fang", "style": "double", "bonus": {"dash": 1}, "desc": "Two lupine energy fangs strike in tandem. Starts with Phantom Dash I."},
	"untitled_artwork": {"name": "Unknown Spark", "style": "basic", "bonus": {"rapid": 1}, "desc": "A mysterious creature with a nimble basic shot. Starts with Rapid Fire I."},
	"virowl": {"name": "Owl Spore", "style": "seed", "bonus": {"rapid": 1}, "desc": "Spore-like feathers pop in little bursts. Starts with Rapid Fire I."}
}

var player := EXTRACTION_POINT
var last_move := Vector2.RIGHT
# Horizontal mirroring uses the last horizontal input, while the run pose
# adds tiny squash/bob/sway without needing new frames for all 52 species.
var player_facing_left := false
var player_is_moving := false
var run_stride_phase := 0.0
var run_pose_strength := 0.0
var enemy_bullets: Array[Dictionary] = []
var impact_effects: Array[Dictionary] = []
# World-space, short-lived combat labels; cleared on each new run.
var floating_damage_numbers: Array[Dictionary] = []
var next_enemy_uid := 0
var projectile_grace := 0.0
var move_ranks: Dictionary = {}
var max_hp := 100.0
var shield_hp := 0.0
var shield_time := 0.0
var dash_time := 0.0
var dash_direction := Vector2.RIGHT
var dash_invulnerability := 0.0
var heal_cooldown := 0.0
var shield_cooldown := 0.0
var dash_cooldown := 0.0
var nova_cooldown := 0.0
var nova_flash_time := 0.0
var nova_flash_origin := Vector2.ZERO
var level_choices: Array[String] = []
var upgrade_overlay: Control
# In-run interface. Everything below is UI-only and resets on each run.
var ability_bar: Control
var ability_labels: Dictionary = {}
var ability_cooldown_fills: Dictionary = {}
var xp_fill: ColorRect
var xp_text: Label
var run_name_text: Label
var run_form_text: Label
var run_signature_text: Label
var hp_fill: ColorRect
var hp_text: Label
var shield_text: Label
var run_wave_text: Label
var run_kills_text: Label
var run_chips_text: Label
var run_materials_text: Label
var run_time_text: Label
var run_extraction_title: Label
var run_extraction_detail: Label
var run_extraction_fill: ColorRect
var run_event_card: Panel
var hp_display_ratio := 1.0
var enemies: Array[Dictionary] = []
var shots: Array[Dictionary] = []
var chip_drops: Array[Dictionary] = []
var gold_drops: Array[Dictionary] = []
var xp_drops: Array[Dictionary] = []
var material_drops: Array[Dictionary] = []
var carried_materials: Dictionary = {}
var banked_materials: Dictionary = {}
var last_run_summary: Dictionary = {}
var run_damage_dealt := 0.0
var run_damage_taken := 0.0
var run_variants_seen := 0
var xp_remainder := 0.0
var starting_bonus_choice := false
var pending_chips := 0
var pending_gold := 0
var pending_variants: Dictionary = {}
var variant_collection: Dictionary = {}
var selected_variant := "normal"
var slot_pulls_since_special := 0
var slot_pulls_since_gold := 0
var run_midas_gold := 0
var midas_fraction := 0.0
var event_message := ""
var event_timer := 0.0
var props: Array[Dictionary] = []
var time_alive := 0.0
var spawn_clock := 0.0
var attack_clock := 0.0
var hp := 100.0
var kills := 0
var level := 1
var xp := 0
var wave := 1
var state := "MENU"
var rng := RandomNumberGenerator.new()
var terrain_rng := RandomNumberGenerator.new()

# These are permanent and saved across runs.
var hatchery_slots: Array[Dictionary] = []
var hatchery_unlocked := 1
var hatchery_last_wall_time := 0.0
var hatchery_save_clock := 0.0
var dev_hatch_form := "shiny"
var dev_hatch_form_option: OptionButton
var hatchery_message := "Breed unlocked creatures to discover Shiny offspring."
var hatchery_status_labels: Dictionary = {}
var poker_chips := 0
var gold := 0
var permanent_upgrades: Dictionary = {}
var evolution_progress: Dictionary = {}
var evolution_overlay: Control
var run_xp_earned := 0
var footprints: Array[Dictionary] = []
var trail_clock := 0.0
var last_trail_position := Vector2.ZERO
var footstep_alternate := false
var shop_rows: Dictionary = {}
var shop_gold_label: Label
var unlocked: Dictionary = {"koikoi": true}
var selected_creature := "koikoi"
var spin_timer := 0.0
var spin_duration := 1.4
var spin_preview_clock := 0.0
var is_spinning := false
var spins_remaining := 0
var spin_batch_size := 0
var batch_new_normals := 0
var current_spin: Dictionary = {}
var spin_results: Array[Dictionary] = []
# Unified FIFO: preserve every qualifying slot, wild, and hatchery celebration.
# Slot duplicate Gold/Shiny (and Ghost) still reveal; ordinary repeats do not.
var variant_reveal_queue: Array[Dictionary] = []
var variant_reveal_overlay: Control
var gold_reveal_overlay: Control
# The tombstone cut-in is delayed until the loss report has been visible.
var ghost_reveal_overlay: Control
var ghost_reveal_pending := ""
var ghost_reveal_new := false
var ghost_reveal_delay := 0.0
var ghost_report_buttons: Array[Button] = []
var reel_ids: Array[String] = ["koikoi", "koikoi", "koikoi"]
var slot_reels: Array[TextureRect] = []
var slot_status: Label
var menu_message := "Defeat enemies, pick up poker chips, and extract to bank them."

var hud: CanvasLayer
var game_info: Label
var menu_root: Control
var menu_page := "home"
var collection_query := ""
var collection_form := "all"
var collection_ownership := "all"
var inspected_id := "koikoi"
var inspected_form := "normal"
var collection_grid: GridContainer
var detail_panel: Panel
var collection_count_label: Label
var spin_label: Label
var player_camera: Camera2D
# V17: FOV is a world-camera setting. Larger percentages show more of the map.
const FOV_MIN := 80
const FOV_MAX := 150
var fov_percent := 100
var fov_value_label: Label
var fov_slider: HSlider
var pause_overlay: Control
var pause_tab := "main"
var run_portrait: Control

# V18: Optional local testing console. F2 and in-game DEV buttons open it.
# Commands change the current local save; closing the panel resumes play.
var dev_console_overlay: Control
var dev_console_input: LineEdit
var dev_console_output: Label
var dev_console_status: Label
var dev_console_log: Array[String] = []
var dev_reset_confirmation: Control
var reset_reload_pending := false
const ONLINE_LOBBY = preload("res://scripts/online_lobby.gd")
var online_lobby

func _ready() -> void:
	texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	rng.randomize()
	terrain_rng.randomize()
	_hatchery_init()
	_load_collection()
	_hatchery_advance()
	_generate_world()
	map_border = MAP_BORDER.new()
	map_border.name = "MapBorder"
	map_border.setup(WORLD)
	add_child(map_border)
	player_camera = Camera2D.new()
	player_camera.position = player
	player_camera.position_smoothing_enabled = true
	player_camera.position_smoothing_speed = 6.0
	player_camera.limit_left = 0
	player_camera.limit_top = 0
	player_camera.limit_right = ceili(WORLD.x)
	player_camera.limit_bottom = ceili(WORLD.y)
	add_child(player_camera)
	player_camera.make_current()
	_apply_fov()
	_build_ui()
	_show_menu()
	online_lobby = ONLINE_LOBBY.new()
	online_lobby.game = self
	online_lobby.name = "OnlineLobby"
	add_child(online_lobby)

func _generate_world(seed_override: int = -1) -> void:
	var next_seed := seed_override
	if next_seed < 0:
		next_seed = terrain_rng.randi()
		while next_seed == world_seed:
			next_seed = terrain_rng.randi()
	world_seed = next_seed
	for body in tree_bodies:
		body.free()
	tree_bodies.clear()
	var layout: Dictionary = WORLD_GENERATOR.generate(WORLD, world_seed)
	props.assign(layout["props"])
	world_roads = layout["roads"]
	world_patches = layout["patches"]
	world_grass = layout["grass"]
	terrain_noise.seed = world_seed
	terrain_noise.frequency = 0.0015
	_setup_tree_obstacles()
	queue_redraw()

func _build_ui() -> void:
	hud = CanvasLayer.new()
	add_child(hud)
	menu_root = Control.new()
	menu_root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	hud.add_child(menu_root)
	_build_run_hud()

# Keep the supplied transparent artwork intact; ignore its empty outer canvas.
func _setup_tree_obstacles() -> void:
	tree_texture = AtlasTexture.new()
	tree_texture.atlas = TREE_ART
	# Bounds of visible pixels (alpha >= 0.5); faint PNG noise extends beyond them.
	tree_texture.region = Rect2(129, 199, 1282, 623)
	boulder_texture = AtlasTexture.new()
	boulder_texture.atlas = BOULDER_ART
	boulder_texture.region = Rect2(154, 329, 1067, 606)
	# Clear the spawn before choosing the replacement fraction.
	for prop in props:
		if int(prop["kind"]) == 0 and Vector2(prop["p"]).distance_to(EXTRACTION_POINT) < 180.0:
			prop["kind"] = 2
	_select_boulder_replacements()
	for prop in props:
		if int(prop["kind"]) not in [0, 4]:
			continue
		var p: Vector2 = prop["p"]
		var is_boulder := int(prop["kind"]) == 4
		var size := _obstacle_size(prop)
		var body := StaticBody2D.new()
		body.name = ("ObstacleBoulder%d" if is_boulder else "ObstacleTree%d") % tree_bodies.size()
		body.set_meta("kind", int(prop["kind"]))
		body.position = p
		body.collision_layer = 2
		body.collision_mask = 0
		var shape := CapsuleShape2D.new()
		shape.radius = size.y * (0.3 if is_boulder else 0.16)
		shape.height = size.x * (0.8 if is_boulder else 0.72)
		var collision := CollisionShape2D.new()
		collision.shape = shape
		collision.rotation = PI * 0.5
		collision.position.y = -shape.radius
		body.add_child(collision)
		add_child(body)
		tree_bodies.append(body)
	if is_instance_valid(player_body):
		player_body.position = EXTRACTION_POINT
		return
	player_body = CharacterBody2D.new()
	player_body.name = "PlayerTreeCollision"
	player_body.collision_layer = 0
	player_body.collision_mask = 2
	var feet := CircleShape2D.new()
	feet.radius = 14.0
	var collision := CollisionShape2D.new()
	collision.shape = feet
	player_body.add_child(collision)
	player_body.position = player
	add_child(player_body)

# One replacement near each evenly spaced map-sector center, using existing
# tree positions, maintaining distribution as the procedural layout changes.
func _select_boulder_replacements() -> void:
	var candidates: Array[Dictionary] = []
	for prop in props:
		if int(prop["kind"]) == 0:
			candidates.append(prop)
	var count := roundi(float(candidates.size()) * BOULDER_FRACTION)
	if count == 0:
		return
	var columns := ceili(sqrt(float(count)))
	var rows := ceili(float(count) / float(columns))
	for index in range(count):
		var row := int(index / columns)
		var row_count := mini(columns, count - row * columns)
		var target := Vector2((float(index % columns) + 0.5) * WORLD.x / float(row_count),
			(float(row) + 0.5) * WORLD.y / float(rows))
		var nearest := 0
		var best_distance := INF
		for candidate_index in range(candidates.size()):
			var distance := Vector2(candidates[candidate_index]["p"]).distance_squared_to(target)
			if distance < best_distance:
				nearest = candidate_index
				best_distance = distance
		candidates[nearest]["kind"] = 4
		candidates.remove_at(nearest)

func _tree_size(original_scale: float) -> Vector2:
	# Previous trees were 63 pixels tall. Scale visible art, not PNG padding.
	var height := 63.0 * original_scale * TREE_SIZE_MULTIPLIER
	return Vector2(height * tree_texture.region.size.x / tree_texture.region.size.y, height)

func _obstacle_size(prop: Dictionary) -> Vector2:
	var size := _tree_size(float(prop["size"]))
	if int(prop["kind"]) == 4:
		size.x = size.y * boulder_texture.region.size.x / boulder_texture.region.size.y
	return size

func _draw_obstacle_tree(prop: Dictionary) -> void:
	var p: Vector2 = prop["p"]
	var size := _obstacle_size(prop)
	var texture: Texture2D = boulder_texture if int(prop["kind"]) == 4 else tree_texture
	_draw_shadow(p, size.x * 0.43, size.y * 0.14)
	draw_texture_rect(texture, Rect2(p - Vector2(size.x * 0.5, size.y), size), false)

func _move_player_around_trees(origin: Vector2, motion: Vector2) -> Vector2:
	player_body.position = origin
	var remaining := motion
	for slide in range(4):
		if remaining.length_squared() < 0.0001:
			break
		var hit := player_body.move_and_collide(remaining)
		if hit == null:
			break
		remaining = hit.get_remainder().slide(hit.get_normal())
	return player_body.position

# Menu coordinates use the project's 1152 x 648 design resolution.
# All controls are real Godot UI nodes; the background is decorative only.
func _panel(parent: Control, bounds: Rect2, background: Color, outline: Color, edge: int = 3) -> Panel:
	var panel := Panel.new()
	panel.position = bounds.position
	panel.size = bounds.size
	var style := StyleBoxFlat.new()
	style.bg_color = background
	style.border_color = outline
	style.set_border_width_all(edge)
	style.set_corner_radius_all(3)
	style.shadow_color = Color(0.01, 0.03, 0.09, 0.72)
	style.shadow_size = 3
	style.shadow_offset = Vector2(2, 3)
	panel.add_theme_stylebox_override("panel", style)
	parent.add_child(panel)
	return panel

func _text(parent: Control, value: String, bounds: Rect2, size: int = 20, color: Color = Color.WHITE, align: HorizontalAlignment = HORIZONTAL_ALIGNMENT_LEFT) -> Label:
	var lbl := Label.new()
	lbl.text = value
	lbl.position = bounds.position
	lbl.size = bounds.size
	lbl.horizontal_alignment = align
	lbl.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	lbl.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	lbl.add_theme_font_size_override("font_size", size)
	lbl.add_theme_color_override("font_color", color)
	lbl.add_theme_color_override("font_outline_color", Color("0a1027"))
	lbl.add_theme_constant_override("outline_size", 2)
	parent.add_child(lbl)
	return lbl

func _button(parent: Control, value: String, bounds: Rect2, kind: String = "blue") -> Button:
	var btn := Button.new()
	btn.text = value
	btn.position = bounds.position
	btn.size = bounds.size
	btn.focus_mode = Control.FOCUS_NONE
	btn.add_theme_font_size_override("font_size", 18)
	btn.add_theme_color_override("font_color", Color("f7fbff") if kind != "gold" else Color("2e2010"))
	btn.add_theme_color_override("font_hover_color", Color.WHITE if kind != "gold" else Color("302109"))
	btn.add_theme_color_override("font_disabled_color", Color("8d9ab3"))
	btn.add_theme_color_override("font_outline_color", Color("101634") if kind != "gold" else Color("ffeb99"))
	btn.add_theme_constant_override("outline_size", 1)
	var base := Color("3158ca")
	var edge := Color("0b193f")
	if kind == "gold":
		base = Color("ffd452")
		edge = Color("70431a")
	elif kind == "green":
		base = Color("218a71")
		edge = Color("07352e")
	elif kind == "violet":
		base = Color("8b4ec6")
		edge = Color("30154b")
	elif kind == "dark":
		base = Color("263966")
		edge = Color("0c183a")
	elif kind == "red":
		base = Color("a32943")
		edge = Color("4e1128")
	for mode in ["normal", "hover", "pressed", "disabled"]:
		var style := StyleBoxFlat.new()
		style.bg_color = base.lightened(0.17) if mode == "hover" else (base.darkened(0.12) if mode == "pressed" else (base.darkened(0.48) if mode == "disabled" else base))
		style.border_color = edge
		style.set_border_width_all(3)
		style.content_margin_left = 6
		style.content_margin_right = 6
		style.content_margin_top = 3
		style.content_margin_bottom = 3
		style.shadow_size = 2
		style.shadow_color = Color("07132b")
		style.shadow_offset = Vector2(2, 3)
		btn.add_theme_stylebox_override(mode, style)
	parent.add_child(btn)
	return btn

func _sprite(parent: Control, texture: Texture2D, bounds: Rect2, tint: Color = Color.WHITE) -> TextureRect:
	var sprite := TextureRect.new()
	sprite.texture = texture
	sprite.position = bounds.position
	sprite.size = bounds.size
	sprite.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	sprite.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	sprite.clip_contents = true
	sprite.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	sprite.modulate = tint
	sprite.mouse_filter = Control.MOUSE_FILTER_IGNORE
	parent.add_child(sprite)
	return sprite

# UI portrait textures are pre-cropped to a padded square to avoid oversized
# source PNGs clipping against GridContainer buttons and preview panels.
func _portrait(parent: Control, creature_id: String, bounds: Rect2, tint: Color = Color.WHITE) -> TextureRect:
	return _sprite(parent, CREATURES[creature_id]["portrait"], bounds, tint)

# Variant portraits glow in the home menu and collection inspector, too.
# Normal forms keep the original optimized static TextureRect.
func _portrait_form(parent: Control, creature_id: String, bounds: Rect2, form: String, owned: bool = true) -> Control:
	var tint := _form_color(form) if owned else Color(0.035, 0.06, 0.10)
	if form == "normal" or not owned:
		return _portrait(parent, creature_id, bounds, tint)
	var portrait: Control = VARIANT_PORTRAIT.new()
	portrait.position = bounds.position
	portrait.size = bounds.size
	portrait.set("creature_texture", _form_portrait_texture(creature_id, form))
	portrait.set("variant_form", form)
	portrait.set("creature_tint", tint)
	portrait.mouse_filter = Control.MOUSE_FILTER_IGNORE
	parent.add_child(portrait)
	return portrait

func _menu_background() -> void:
	var bg := TextureRect.new()
	bg.texture = preload("res://art/camp_background.png")
	bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	bg.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	bg.stretch_mode = TextureRect.STRETCH_SCALE
	bg.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	bg.mouse_filter = Control.MOUSE_FILTER_IGNORE
	menu_root.add_child(bg)
	# Separate dark overlays keep controls readable without hiding the forest.
	var left_shade := ColorRect.new()
	left_shade.color = Color(0.025, 0.035, 0.10, 0.65)
	left_shade.position = Vector2.ZERO
	left_shade.size = Vector2(311, 648)
	left_shade.mouse_filter = Control.MOUSE_FILTER_IGNORE
	menu_root.add_child(left_shade)
	# Portraits have an exact 160x160 pixel art canvas and stay inside their zones.
	# Keep the center clear of left navigation and right-hand creature preview.
	for info in [
		["dracosoar", Vector2(375, 102), 120],
		["aurehawk", Vector2(640, 121), 100],
		["bigroot", Vector2(427, 359), 105],
		["echo", Vector2(738, 286), 90],
		["coralith", Vector2(555, 301), 95],
		["flic", Vector2(717, 450), 78]
	]:
		var creature_id: String = str(info[0])
		var side: float = float(info[2])
		_portrait(menu_root, creature_id, Rect2(info[1], Vector2(side, side)))
func _show_menu() -> void:
	_discard_dev_console()
	state = "MENU"
	game_info.hide()
	ability_bar.hide()
	_dismiss_pause_overlay()
	if is_instance_valid(upgrade_overlay):
		upgrade_overlay.queue_free()
		upgrade_overlay = null
	menu_page = "home"
	menu_root.show()
	_rebuild_menu()

# Keeps the end-of-run report open until the player chooses what to do next.
func _show_run_results() -> void:
	_discard_dev_console()
	state = "MENU"
	game_info.hide()
	ability_bar.hide()
	_dismiss_pause_overlay()
	if is_instance_valid(upgrade_overlay):
		upgrade_overlay.queue_free()
		upgrade_overlay = null
	menu_page = "run_result"
	menu_root.show()
	_rebuild_menu()

func _open_page(page_name: String) -> void:
	if is_spinning:
		return
	menu_page = page_name
	_rebuild_menu()

func _rebuild_menu() -> void:
	for child in menu_root.get_children():
		menu_root.remove_child(child)
		child.queue_free()
	match menu_page:
		"run_result":
			_build_run_result_menu()
		"collection":
			_build_collection_menu()
		"upgrades":
			_build_permanent_upgrades_menu()
		"hatchery":
			_build_hatchery_menu()
		"settings":
			_build_settings_menu()
		"slots":
			_build_slots_menu()
		_:
			_build_home_menu()

func _build_home_menu() -> void:
	_menu_background()
	var logo_texture := AtlasTexture.new()
	logo_texture.atlas = preload("res://art/home_logo.png")
	# Ignore transparent canvas margins, retaining the exact supplied logo art.
	logo_texture.region = Rect2(48, 102, 1440, 823)
	var logo := _sprite(menu_root, logo_texture, Rect2(10, 4, 290, 154))
	logo.size = Vector2(290, 154)
	logo.name = "HomeLogo"
	_text(menu_root, "HUNT  •  COLLECT  •  EXTRACT", Rect2(24, 161, 286, 26), 14, Color("f7f5da"))
	var menu_items := [
		["▶   PLAY", "play", "gold"],
		["✿   CREATURES", "collection", "blue"],
		["◆   SLOT MACHINE", "slots", "blue"],
		["▣   DEX", "collection", "blue"],
		["⬆   UPGRADES", "upgrades", "blue"],
		["🥚   HATCHERY", "hatchery", "green"],
		["⚙   SETTINGS", "settings", "blue"]
	]
	for i in range(menu_items.size()):
		var entry: Array = menu_items[i]
		var button := _button(menu_root, str(entry[0]), Rect2(25, 193 + i * 54, 258, 44), str(entry[2]))
		if str(entry[1]) == "play":
			button.pressed.connect(_start_run)
		else:
			button.pressed.connect(_open_page.bind(str(entry[1])))
	var dev_button := _button(menu_root, "</>  DEV CONSOLE  [F2]", Rect2(854, 89, 282, 39), "dark")
	dev_button.add_theme_font_size_override("font_size", 14)
	dev_button.pressed.connect(_toggle_dev_console)
	var online_button := _button(menu_root, "ONLINE  •  CO-OP / ACCOUNTS", Rect2(854, 129, 282, 35), "green")
	online_button.add_theme_font_size_override("font_size", 13)
	online_button.pressed.connect(func(): online_lobby.open())
	var wallet := _panel(menu_root, Rect2(854, 16, 282, 54), Color("101d47"), Color("4d77c0"))
	_text(wallet, "◆ %d CHIPS    ● %d GOLD" % [poker_chips, gold], Rect2(9, 6, 267, 37), 16, Color("ffdb67"))
	var partner := _panel(menu_root, Rect2(854, 168, 282, 370), Color("101b3bee"), Color("4375cc"))
	var selected_name: String = str(CREATURES[selected_creature]["name"])
	_text(partner, "✿  YOUR CREATURE", Rect2(12, 7, 254, 30), 18, Color("bad2ff"))
	_panel(partner, Rect2(13, 43, 256, 192), Color("08132b"), Color("21386b"), 2)
	_portrait_form(partner, selected_creature, Rect2(81, 69, 120, 120), selected_variant)
	_text(partner, selected_name, Rect2(13, 241, 255, 42), 26, Color("ffe26b"), HORIZONTAL_ALIGNMENT_CENTER)
	_text(partner, selected_variant.to_upper() + " FORM", Rect2(14, 281, 254, 25), 14, Color("d7b5ff"), HORIZONTAL_ALIGNMENT_CENTER)
	var change := _button(partner, "CHOOSE CREATURE", Rect2(24, 316, 233, 42), "violet")
	change.add_theme_font_size_override("font_size", 15)
	change.pressed.connect(_open_page.bind("collection"))
	var footer := _panel(menu_root, Rect2(326, 562, 509, 68), Color("111e42ed"), Color("355a9e"), 2)
	_text(footer, "CREATURES  %d / %d    •    VARIANTS  %d    •    MATERIALS  %d" % [_normal_unlocked_count(), CREATURES.size(), variant_collection.size(), _banked_material_count()], Rect2(14, 3, 479, 27), 14, Color("e5edff"))
	_text(footer, menu_message, Rect2(14, 28, 478, 34), 12, Color("ffdc91"))
# Separate results pages for death, abandonment and successful extraction.
# Data is snapshotted before carried rewards are cleared; nothing shown as
# "secured" is applied to the save unless extraction actually succeeded.
# V17: FOV applies only to the world camera, preserving legible HUD size.
# 100% is exactly the previous game's camera. 150% shows 50% more width/height.
func _apply_fov() -> void:
	if is_instance_valid(player_camera):
		var scale_factor := 100.0 / float(fov_percent)
		player_camera.zoom = Vector2(scale_factor, scale_factor)

func _on_fov_changed(value: float) -> void:
	fov_percent = clampi(int(roundi(value / 5.0)) * 5, FOV_MIN, FOV_MAX)
	_apply_fov()
	if is_instance_valid(fov_value_label):
		fov_value_label.text = "%d%%" % fov_percent
	if is_instance_valid(fov_slider):
		fov_slider.set_value_no_signal(float(fov_percent))
	_save_collection()

func _add_fov_slider(parent: Control, top: float, width: float) -> void:
	_text(parent, "FIELD OF VIEW", Rect2(25, top, width - 160.0, 30), 19, Color("f2e3ae"))
	fov_value_label = _text(parent, "%d%%" % fov_percent, Rect2(width - 106.0, top, 80, 30), 20, Color("8fead8"), HORIZONTAL_ALIGNMENT_RIGHT)
	var slider := HSlider.new()
	slider.position = Vector2(32, top + 46)
	slider.size = Vector2(width - 64.0, 32)
	slider.min_value = float(FOV_MIN)
	slider.max_value = float(FOV_MAX)
	slider.step = 5.0
	slider.value = float(fov_percent)
	fov_slider = slider
	slider.focus_mode = Control.FOCUS_ALL
	slider.add_theme_stylebox_override("slider", _slider_track_style(Color("243a60")))
	slider.add_theme_stylebox_override("grabber_area", _slider_track_style(Color("54bfba")))
	slider.add_theme_stylebox_override("grabber_area_highlight", _slider_track_style(Color("8aeed2")))
	parent.add_child(slider)
	slider.value_changed.connect(_on_fov_changed)
	_text(parent, "80%  •  CLOSER", Rect2(31, top + 82, 175, 22), 12, Color("adbfda"))
	_text(parent, "150%  •  WIDER", Rect2(width - 202.0, top + 82, 175, 22), 12, Color("adbfda"), HORIZONTAL_ALIGNMENT_RIGHT)
	_text(parent, "Changes how much of the map is visible. UI stays the same size.", Rect2(24, top + 116, width - 48.0, 42), 13, Color("d0ddf1"), HORIZONTAL_ALIGNMENT_CENTER)

func _slider_track_style(tint: Color) -> StyleBoxFlat:
	var style := StyleBoxFlat.new()
	style.bg_color = tint
	style.set_corner_radius_all(3)
	style.set_content_margin_all(2)
	return style

func _build_settings_menu() -> void:
	_screen_background("SETTINGS", "Camera and display options  •  Changes save automatically")
	var back := _panel(menu_root, Rect2(296, 135, 560, 380), Color("14264be5"), Color("678cb7"), 3)
	_text(back, "CAMERA SETTINGS", Rect2(18, 19, 524, 44), 27, Color("ffe0a0"), HORIZONTAL_ALIGNMENT_CENTER)
	_add_fov_slider(back, 94.0, 560.0)
	var restore := _button(back, "RESET TO 100%", Rect2(74, 279, 190, 47), "dark")
	restore.pressed.connect(_on_fov_changed.bind(100.0))
	var home := _button(back, "← BACK TO CAMP", Rect2(289, 279, 210, 47), "green")
	home.pressed.connect(_open_page.bind("home"))

func _dismiss_pause_overlay() -> void:
	if is_instance_valid(pause_overlay):
		pause_overlay.queue_free()
		pause_overlay = null

func _toggle_pause() -> void:
	if state == "PLAY":
		state = "PAUSED"
		pause_tab = "main"
		_rebuild_pause_overlay()
	elif state == "PAUSED":
		_resume_run()

func _resume_run() -> void:
	if state != "PAUSED":
		return
	state = "PLAY"
	_dismiss_pause_overlay()
	_update_run_hud(0.0)

func _open_pause_settings() -> void:
	if state != "PAUSED":
		return
	pause_tab = "settings"
	_rebuild_pause_overlay()

func _back_to_pause_menu() -> void:
	if state != "PAUSED":
		return
	pause_tab = "main"
	_rebuild_pause_overlay()

func _rebuild_pause_overlay() -> void:
	_dismiss_pause_overlay()
	if state != "PAUSED":
		return
	pause_overlay = Control.new()
	pause_overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	pause_overlay.mouse_filter = Control.MOUSE_FILTER_STOP
	hud.add_child(pause_overlay)
	var darken := ColorRect.new()
	darken.color = Color(0.025, 0.046, 0.095, 0.62)
	darken.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	darken.mouse_filter = Control.MOUSE_FILTER_STOP
	pause_overlay.add_child(darken)
	var frame := _panel(pause_overlay, Rect2(324, 111, 504, 425), Color("101d3df2"), Color("76a7c3"), 3)
	var close := _button(frame, "✕", Rect2(445, 13, 44, 38), "violet")
	close.pressed.connect(_resume_run)
	if pause_tab == "settings":
		_text(frame, "⚙  SETTINGS", Rect2(30, 24, 432, 45), 29, Color("ffdfa1"), HORIZONTAL_ALIGNMENT_CENTER)
		_text(frame, "FOV adjusts your world view, not your action bar.", Rect2(24, 68, 456, 29), 14, Color("cedcf8"), HORIZONTAL_ALIGNMENT_CENTER)
		_add_fov_slider(frame, 115.0, 504.0)
		var reset := _button(frame, "RESET FOV", Rect2(29, 304, 212, 45), "dark")
		reset.pressed.connect(_on_fov_changed.bind(100.0))
		var back := _button(frame, "← PAUSE MENU", Rect2(263, 304, 212, 45), "violet")
		back.pressed.connect(_back_to_pause_menu)
	else:
		_text(frame, "II   GAME PAUSED", Rect2(23, 23, 459, 50), 30, Color("ffe0a0"), HORIZONTAL_ALIGNMENT_CENTER)
		_text(frame, "Dungeon time, enemies and attacks are frozen.", Rect2(22, 81, 462, 31), 15, Color("cbdfff"), HORIZONTAL_ALIGNMENT_CENTER)
		var resume := _button(frame, "▶  RESUME RUN", Rect2(75, 142, 354, 55), "green")
		resume.pressed.connect(_resume_run)
		var settings_button := _button(frame, "⚙  SETTINGS / FIELD OF VIEW", Rect2(75, 214, 354, 55), "violet")
		settings_button.add_theme_font_size_override("font_size", 17)
		settings_button.pressed.connect(_open_pause_settings)
		var abandon := _button(frame, "LEAVE RUN  •  LOSE UNBANKED LOOT", Rect2(75, 288, 354, 51), "dark")
		abandon.add_theme_font_size_override("font_size", 15)
		abandon.pressed.connect(_end_run.bind(false))
		var dev := _button(frame, "</>  DEV CONSOLE  [F2]", Rect2(75, 347, 354, 38), "dark")
		dev.add_theme_font_size_override("font_size", 14)
		dev.pressed.connect(_toggle_dev_console)
		_text(frame, "ESC to resume  •  Extract to keep loot.", Rect2(27, 388, 451, 25), 12, Color("b7c9e7"), HORIZONTAL_ALIGNMENT_CENTER)

# ESC pauses instead of abandoning the run. The separate Leave Run button is
# intentionally explicit, so closing a menu cannot accidentally lose rewards.
func _input(event: InputEvent) -> void:
	# Ghost and Gold cut-ins have exclusive keyboard control.
	if is_instance_valid(ghost_reveal_overlay):
		if event is InputEventKey and event.pressed and not event.echo:
			if event.keycode in [KEY_ENTER, KEY_KP_ENTER, KEY_SPACE, KEY_ESCAPE]:
				ghost_reveal_overlay.call("try_finish")
			get_viewport().set_input_as_handled()
		return
	# All variant reward cut-ins have exclusive input until dismissed.
	if is_instance_valid(variant_reveal_overlay):
		if event is InputEventKey and event.pressed:
			get_viewport().set_input_as_handled()
		return
	# The full-screen Gold jackpot cut-in takes priority over menu shortcuts.
	if is_instance_valid(gold_reveal_overlay):
		if event is InputEventKey and event.pressed:
			get_viewport().set_input_as_handled()
		return
	if event is InputEventKey and event.pressed and not event.echo:
		# Do not allow F2 to close the console behind an active reset warning.
		if is_instance_valid(dev_reset_confirmation):
			if event.keycode == KEY_ESCAPE:
				_dev_cancel_reset()
			get_viewport().set_input_as_handled()
			return
		if event.keycode == KEY_F2:
			_toggle_dev_console()
			get_viewport().set_input_as_handled()
			return
		if is_instance_valid(dev_console_overlay):
			if event.keycode == KEY_ESCAPE:
				_close_dev_console()
				get_viewport().set_input_as_handled()
			return
		if event.keycode == KEY_ESCAPE and state in ["PLAY", "PAUSED"]:
			_toggle_pause()
			get_viewport().set_input_as_handled()

# The dev console is deliberately local and optional; it never modifies drop
# rates or rewards unless the tester explicitly runs a command.
func _toggle_dev_console() -> void:
	if is_instance_valid(dev_console_overlay):
		_close_dev_console()
	else:
		_open_dev_console()

func _discard_dev_console() -> void:
	if is_instance_valid(dev_console_overlay):
		dev_console_overlay.queue_free()
		dev_console_overlay = null
	dev_console_input = null
	dev_console_output = null
	dev_console_status = null
	dev_reset_confirmation = null

func _close_dev_console() -> void:
	_discard_dev_console()
	if state == "MENU":
		_rebuild_menu()  # Refresh slot prices/wallet/evolution after dev grants.

func _open_dev_console() -> void:
	dev_console_overlay = Control.new()
	dev_console_overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	dev_console_overlay.mouse_filter = Control.MOUSE_FILTER_STOP
	hud.add_child(dev_console_overlay)
	var shade := ColorRect.new()
	shade.color = Color(0.02, 0.04, 0.10, 0.77)
	shade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	shade.mouse_filter = Control.MOUSE_FILTER_STOP
	dev_console_overlay.add_child(shade)
	var panel := _panel(dev_console_overlay, Rect2(172, 31, 808, 593), Color("111d39f6"), Color("68bfc3"), 3)
	_text(panel, "</>  DEVELOPER CONSOLE", Rect2(22, 10, 653, 47), 27, Color("a9f6d2"))
	var close := _button(panel, "✕", Rect2(746, 12, 44, 40), "violet")
	close.pressed.connect(_close_dev_console)
	_text(panel, "TEST TOOLS • CHANGES SAVE LOCALLY • F2 / ESC TO CLOSE", Rect2(24, 52, 754, 25), 12, Color("b6cadf"))
	var top_buttons := [
		["+100 CHIPS", "chips 100"],
		["+1,000 CHIPS", "chips 1000"],
		["MAX EVOLUTION", "evo 5"],
		["+1,000 GOLD", "gold 1000"]
	]
	for i in range(top_buttons.size()):
		var info: Array = top_buttons[i]
		var b := _button(panel, str(info[0]), Rect2(23 + i * 194, 91, 183, 46), "gold" if i == 0 else "green")
		b.add_theme_font_size_override("font_size", 14)
		b.pressed.connect(_dev_run_command.bind(str(info[1])))
	_text(panel, "EQUIP / TEST FOOTSTEPS (AUTO-UNLOCKS THE REQUIRED STAGE)", Rect2(23, 152, 753, 24), 13, Color("d6ebff"))
	for stage in range(6):
		var stage_label: String = str(["NONE", "1 SLIME", "2 FIRE", "3 ICE", "4 POISON", "5 RGB"][stage])
		var step_button := _button(panel, stage_label, Rect2(23 + stage * 130, 182, 119, 43), "violet" if stage > 0 else "dark")
		step_button.add_theme_font_size_override("font_size", 13)
		step_button.pressed.connect(_dev_run_command.bind("trail %d" % stage))
	var spawn_corrupt := _button(panel, "SPAWN CORRUPT", Rect2(23, 240, 235, 39), "violet")
	spawn_corrupt.add_theme_font_size_override("font_size", 14)
	spawn_corrupt.pressed.connect(_dev_run_command.bind("spawn corrupt"))
	var spawn_blessed := _button(panel, "SPAWN BLESSED", Rect2(275, 240, 235, 39), "violet")
	spawn_blessed.add_theme_font_size_override("font_size", 14)
	spawn_blessed.pressed.connect(_dev_run_command.bind("spawn blessed"))
	var help_button := _button(panel, "HELP", Rect2(527, 240, 274, 39), "dark")
	help_button.add_theme_font_size_override("font_size", 14)
	help_button.pressed.connect(_dev_run_command.bind("help"))
	var ghost_test := _button(panel, "☾  INSTANT DEATH + GUARANTEED GHOST REVEAL", Rect2(23, 285, 774, 39), "violet")
	ghost_test.add_theme_font_size_override("font_size", 17)
	ghost_test.tooltip_text = "During a run: immediately die, unlock your active species' Ghost form and play the tombstone reveal after the loss report."
	ghost_test.pressed.connect(_dev_run_command.bind("ghostdeath"))
	_text(panel, "TEST BREEDING • INSTANT TEST EGGS IN ALL OPEN PLOTS", Rect2(23, 331, 759, 18), 12, Color("fff0a7"))
	dev_hatch_form_option = OptionButton.new()
	dev_hatch_form_option.position = Vector2(23, 350)
	dev_hatch_form_option.size = Vector2(565, 40)
	for test_form in HATCHERY_FORMS:
		dev_hatch_form_option.add_item(str(test_form).to_upper())
	dev_hatch_form_option.select(maxi(0, HATCHERY_FORMS.find(dev_hatch_form)))
	dev_hatch_form_option.item_selected.connect(_dev_choose_egg_form)
	panel.add_child(dev_hatch_form_option)
	var egg_button := _button(panel, "FILL EGGS", Rect2(602, 350, 194, 40), "gold")
	egg_button.pressed.connect(_dev_fill_eggs)
	dev_console_status = _text(panel, "", Rect2(23, 400, 576, 24), 13, Color("ffe9b8"))
	var reset_button := _button(panel, "RESET PROGRESS", Rect2(606, 395, 191, 33), "red")
	reset_button.add_theme_font_size_override("font_size", 13)
	reset_button.tooltip_text = "Permanently erase this profile's local save and start from the beginning (confirmation required)."
	reset_button.pressed.connect(_dev_ask_reset)
	_dev_refresh_status()
	dev_console_input = LineEdit.new()
	dev_console_input.position = Vector2(23, 429)
	dev_console_input.size = Vector2(671, 42)
	dev_console_input.placeholder_text = "Type: chips 100  /  trail 2  /  ghostdeath"
	dev_console_input.add_theme_font_size_override("font_size", 16)
	panel.add_child(dev_console_input)
	dev_console_input.text_submitted.connect(_dev_run_command)
	var run_button := _button(panel, "RUN", Rect2(705, 429, 92, 42), "green")
	run_button.pressed.connect(_dev_submit_input)
	var output_back := _panel(panel, Rect2(23, 481, 774, 95), Color("07132a"), Color("405679"), 2)
	dev_console_output = _text(output_back, "", Rect2(12, 5, 751, 84), 13, Color("b9f2d9"))
	dev_console_output.vertical_alignment = VERTICAL_ALIGNMENT_TOP
	dev_console_output.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	if dev_console_log.is_empty():
		_dev_log("Ready: try CHIPS 100 or TRAIL 1-5. Use SPAWN in a run.")
	else:
		_dev_refresh_log()
	dev_console_input.grab_focus()

# Reset lives only in the developer console and always requires confirmation.
# Saving a clean record (rather than deleting the file) also prevents the
# legacy save migration in _load_collection() from restoring old progress.
func _dev_ask_reset() -> void:
	if not is_instance_valid(dev_console_overlay) or is_instance_valid(dev_reset_confirmation):
		return
	dev_reset_confirmation = Control.new()
	dev_reset_confirmation.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	dev_reset_confirmation.mouse_filter = Control.MOUSE_FILTER_STOP
	dev_console_overlay.add_child(dev_reset_confirmation)
	var dim := ColorRect.new()
	dim.color = Color(0.01, 0.015, 0.035, 0.85)
	dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	dim.mouse_filter = Control.MOUSE_FILTER_STOP
	dev_reset_confirmation.add_child(dim)
	var warning := _panel(dev_reset_confirmation, Rect2(254, 174, 644, 300), Color("191d33"), Color("e35b69"), 4)
	_text(warning, "⚠ RESET ALL PROGRESS?", Rect2(22, 18, 600, 39), 25, Color("ff99a0"), HORIZONTAL_ALIGNMENT_CENTER)
	var details := _text(warning,
		"This permanently replaces your LOCAL save with a fresh one.\n\nAll creatures and variants, gold, chips, upgrades, evolution, hatchery eggs/plots, materials and slot pity will be lost. Any active run is abandoned.\n\nYou will start again with only Koikoi.",
		Rect2(35, 63, 574, 145), 16, Color("f2e7e7"), HORIZONTAL_ALIGNMENT_CENTER)
	details.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	var cancel := _button(warning, "CANCEL", Rect2(32, 232, 267, 47), "dark")
	cancel.pressed.connect(_dev_cancel_reset)
	var confirm := _button(warning, "YES, ERASE EVERYTHING", Rect2(313, 232, 298, 47), "red")
	confirm.add_theme_font_size_override("font_size", 16)
	confirm.pressed.connect(_dev_confirm_reset)

func _dev_cancel_reset() -> void:
	if is_instance_valid(dev_reset_confirmation):
		dev_reset_confirmation.queue_free()
	dev_reset_confirmation = null
	if is_instance_valid(dev_console_input):
		dev_console_input.grab_focus()

func _dev_confirm_reset() -> void:
	if not is_instance_valid(dev_reset_confirmation):
		return
	# Every persisted progression field gets its original new-game value.
	var fresh_nests: Array[Dictionary] = []
	for nest_index in range(HATCHERY_SLOT_COUNT):
		fresh_nests.append({"parents": [{"id": "koikoi", "form": "normal"}, {"id": "koikoi", "form": "normal"}],
			"phase": "idle", "remaining": 0.0, "child_id": "", "child_form": "normal"})
	var fresh_save := {
		"version": 11,
		"fov_percent": 100,
		"banked_materials": {},
		"evolution_progress": {},
		"permanent_upgrades": {},
		"gold": 0,
		"poker_chips": 0,
		"unlocked": {"koikoi": true},
		"selected_creature": "koikoi",
		"selected_variant": "normal",
		"variant_collection": {},
		"hatchery_unlocked": 1,
		"hatchery_slots": fresh_nests,
		"hatchery_last_wall_time": Time.get_unix_time_from_system(),
		"slot_pulls_since_special": 0,
		"slot_pulls_since_gold": 0
	}
	if not _write_collection_data(fresh_save):
		_dev_cancel_reset()
		_dev_log("RESET FAILED: local save couldn't be written. Previous progress has not been cleared.")
		return
	# Suppress autosaves until the replacement scene finishes loading.
	reset_reload_pending = true
	# Reload from new defaults to also clear every non-persistent run/UI value.
	get_tree().call_deferred("reload_current_scene")

func _dev_submit_input() -> void:
	if is_instance_valid(dev_console_input):
		_dev_run_command(dev_console_input.text)

func _dev_log(line: String) -> void:
	dev_console_log.append(line)
	while dev_console_log.size() > 5:
		dev_console_log.remove_at(0)
	_dev_refresh_log()

func _dev_refresh_log() -> void:
	if is_instance_valid(dev_console_output):
		dev_console_output.text = "\n".join(PackedStringArray(dev_console_log))

func _dev_refresh_status() -> void:
	if is_instance_valid(dev_console_status):
		dev_console_status.text = "ACTIVE: %s / %s  •  %d CHIPS  •  EVO %d" % [
			str(CREATURES[selected_creature]["name"]), selected_variant.to_upper(), poker_chips,
			int(_evo_record(selected_creature, selected_variant)["stage"])]

func _dev_run_command(raw_command: String) -> void:
	var command := raw_command.strip_edges().to_lower()
	if is_instance_valid(dev_console_input):
		dev_console_input.clear()
	if command.is_empty():
		return
	var args := command.split(" ", false)
	var op := str(args[0])
	var response := "Unknown command. Type HELP."
	match op:
		"help":
			response = "CHIPS 1000 | GOLD 1000 | EVO 0-5 | TRAIL 0-5 | EGGS SHINY/GHOST/GOLD/SHINY+BLESSED | SPAWN | GHOSTDEATH | RESET"
		"reset":
			_dev_ask_reset()
			return
		"eggs":
			var form: String = str(args[1]) if args.size() > 1 else dev_hatch_form
			if form not in HATCHERY_FORMS:
				response = "EGGS NORMAL/SHINY/BLESSED/CORRUPT/GOLD/GHOST/SHINY+BLESSED/SHINY+CORRUPT"
			else:
				response = _dev_inject_eggs(form)
		"ghostdeath":
			if state in ["PLAY", "PAUSED", "UPGRADE"]:
				# Forced death goes through the exact same loss-report and ghost-award path.
				hp = 0.0
				_end_run(true, true)
				return
			response = "Start a run first, then press the Ghost Death test button."
		"chips", "gold":
			if args.size() < 2 or not str(args[1]).is_valid_int():
				response = "Usage: %s 100 (adds that amount to your saved wallet)" % op
			else:
				var amount := clampi(int(args[1]), 0, 1000000)
				if op == "chips":
					poker_chips += amount
					response = "+%d chips  •  Wallet now: %d" % [amount, poker_chips]
				else:
					gold += amount
					response = "+%d gold  •  Total now: %d" % [amount, gold]
				_save_collection()
		"pity":
			if args.size() < 2:
				response = "RARE %d/100  •  GOLD %d/1000 | Use: pity rare / pity gold" % [slot_pulls_since_special, slot_pulls_since_gold]
			elif str(args[1]) == "rare":
				slot_pulls_since_special = SLOT_VARIANT_PITY - 1
				_save_collection()
				response = "Rare pity primed. Your next pull guarantees Blessed or Corrupt."
			elif str(args[1]) == "gold":
				slot_pulls_since_gold = SLOT_GOLD_PITY - 1
				_save_collection()
				response = "Gold pity primed. Your next pull guarantees GOLD."
			else:
				response = "Usage: pity rare | pity gold"
		"evo", "trail":
			if args.size() < 2 or not str(args[1]).is_valid_int() or int(args[1]) < 0 or int(args[1]) > 5:
				response = "Usage: %s 0-5 (current creature and variant)" % op
			else:
				var target := int(args[1])
				var record := _evo_record(selected_creature, selected_variant)
				if op == "evo":
					record["stage"] = target
					record["equipped"] = target
				else:
					record["stage"] = maxi(int(record["stage"]), target)
					record["equipped"] = target
				evolution_progress[_evo_key(selected_creature, selected_variant)] = record
				_save_collection()
				footprints.clear()  # Immediately swap the trail in an active run.
				trail_clock = 0.0
				last_trail_position = player
				response = "%s: Evo %d, equipped %s" % [str(CREATURES[selected_creature]["name"]), int(record["stage"]), TRAIL_TITLES[target]]
		"spawn":
			if args.size() < 2 or str(args[1]) not in ["corrupt", "blessed"]:
				response = "Usage: spawn corrupt | spawn blessed"
			elif state not in ["PLAY", "PAUSED"]:
				response = "Start a run before spawning a rare creature."
			else:
				var form := str(args[1])
				var old_count := enemies.size()
				_spawn_enemy()
				if enemies.size() > old_count:
					var index := enemies.size() - 1
					var enemy: Dictionary = enemies[index]
					if str(enemy.get("variant", "normal")) == "normal":
						run_variants_seen += 1
					enemy["variant"] = form
					enemy["hp"] = float(enemy["hp"]) * 1.2
					enemy["max_hp"] = float(enemy["hp"])
					enemies[index] = enemy
					event_message = "DEV SPAWN: %s %s" % [form.to_upper(), str(CREATURES[str(enemy["id"])]["name"])]
					event_timer = 6.0
					response = "Spawned %s %s near you." % [form, str(CREATURES[str(enemy["id"])]["name"])]
	_dev_log("> " + command + "    " + response)
	_dev_refresh_status()
	if is_instance_valid(dev_console_input):
		dev_console_input.grab_focus()

func _material_color(id: String) -> Color:
	match id:
		"grove_fiber": return Color("8bdb75")
		"crystal_shards": return Color("72d7ef")
		"ember_fragments": return Color("ffc070")
	return Color.WHITE

func _carried_material_count() -> int:
	var total := 0
	for id in MATERIAL_IDS:
		total += int(carried_materials.get(id, 0))
	return total

func _banked_material_count() -> int:
	var total := 0
	for id in MATERIAL_IDS:
		total += int(banked_materials.get(id, 0))
	return total

func _run_report_line(parent: Control, y: float, title: String, value: String, tint: Color = Color("e4efff")) -> void:
	_text(parent, title, Rect2(18, y, 295, 29), 16, Color("bbcdec"))
	_text(parent, value, Rect2(315, y, 183, 29), 17, tint, HORIZONTAL_ALIGNMENT_RIGHT)

func _build_run_result_menu() -> void:
	if last_run_summary.is_empty():
		_build_home_menu()
		return
	var report: Dictionary = last_run_summary
	var successful: bool = bool(report.get("success", false))
	var abandoned: bool = bool(report.get("abandoned", false))
	var accent := Color("79edbf") if successful else Color("ff9e9e")
	var outline := Color("387e6e") if successful else Color("924864")
	_screen_background("EXTRACTION SUCCESS" if successful else ("RUN ABANDONED" if abandoned else "CREATURE DEFEATED"),
		"Supplies permanently banked. Your creature made it home!" if successful else "Everything carried was lost. Banked supplies and creature evolution remain safe.")
	var header := _panel(menu_root, Rect2(20, 101, 1112, 66), Color("163e43") if successful else Color("472038"), outline, 3)
	_text(header, "EXTRACTED  •  REWARDS SECURED" if successful else ("EXTRACTION FAILED  •  RUN ABANDONED" if abandoned else "YOU WERE DEFEATED  •  LOOT LOST"), Rect2(19, 7, 746, 46), 24, accent)
	var creature_id: String = str(report.get("creature", "koikoi"))
	var creature_form: String = str(report.get("form", "normal"))
	if CREATURES.has(creature_id):
		_portrait_form(header, creature_id, Rect2(875, 2, 58, 58), creature_form)
		_text(header, str(CREATURES[creature_id]["name"]) + "  •  " + creature_form.to_upper(), Rect2(939, 10, 160, 42), 14, Color("f9e7bf"))
	var performance := _panel(menu_root, Rect2(20, 180, 532, 370), Color("152448"), Color("4765a5"), 3)
	_text(performance, "RUN PERFORMANCE", Rect2(18, 8, 490, 36), 22, Color("ffda87"))
	var elapsed := int(report.get("seconds", 0))
	_run_report_line(performance, 53, "Time survived", "%02d:%02d" % [int(elapsed / 60), elapsed % 60])
	_run_report_line(performance, 91, "Wave reached", str(int(report.get("wave", 1))))
	_run_report_line(performance, 129, "Enemies defeated", str(int(report.get("kills", 0))))
	_run_report_line(performance, 167, "Rare enemies spotted", str(int(report.get("variants_seen", 0))))
	_run_report_line(performance, 205, "Combat level reached", str(int(report.get("level", 1))))
	_run_report_line(performance, 243, "Run XP collected", str(int(report.get("xp_earned", 0))))
	_run_report_line(performance, 281, "Damage dealt", str(int(roundf(float(report.get("damage_dealt", 0.0))))))
	_run_report_line(performance, 319, "HP damage taken", str(int(roundf(float(report.get("damage_taken", 0.0))))))
	var rewards := _panel(menu_root, Rect2(570, 180, 562, 370), Color("142a3e") if successful else Color("382038"), outline, 3)
	_text(rewards, "EXTRACTED MATERIALS" if successful else "MATERIALS LOST", Rect2(18, 8, 523, 36), 22, accent)
	var rewards_label := "BANKED" if successful else "LOST"
	_text(rewards, rewards_label, Rect2(419, 13, 128, 29), 14, accent, HORIZONTAL_ALIGNMENT_RIGHT)
	_text(rewards, "◆ POKER CHIPS", Rect2(19, 49, 334, 31), 17, Color("f2dea6"))
	_text(rewards, "+%d" % int(report.get("chips", 0)) if successful else "-%d" % int(report.get("chips", 0)), Rect2(357, 49, 185, 31), 18, accent, HORIZONTAL_ALIGNMENT_RIGHT)
	var midas_gold := int(report.get("midas_gold", 0))
	_text(rewards, "● GOLD (MIDAS +%d)" % midas_gold, Rect2(19, 82, 334, 29), 16, Color("ffe38b"))
	_text(rewards, ("+%d" if successful else "-%d") % int(report.get("gold", 0)), Rect2(357, 82, 185, 29), 18, accent, HORIZONTAL_ALIGNMENT_RIGHT)
	var materials: Dictionary = report.get("materials", {})
	for i in range(MATERIAL_IDS.size()):
		var id: String = MATERIAL_IDS[i]
		var row_y: float = 118.0 + 41.0 * i
		_text(rewards, "◆ " + str(MATERIAL_NAMES[id]), Rect2(19, row_y, 334, 29), 16, _material_color(id))
		var material_qty := int(materials.get(id, 0))
		_text(rewards, ("+%d" if successful else "-%d") % material_qty, Rect2(357, row_y, 185, 29), 18, accent, HORIZONTAL_ALIGNMENT_RIGHT)
	var variants: Array = report.get("variants", [])
	_text(rewards, "RARE FORMS SECURED" if successful else "RARE FORMS LOST", Rect2(19, 242, 365, 26), 17, Color("e6bfff"))
	_text(rewards, str(variants.size()), Rect2(398, 242, 143, 26), 18, accent, HORIZONTAL_ALIGNMENT_RIGHT)
	var forms_text := "None" if variants.is_empty() else ", ".join(PackedStringArray(variants))
	_text(rewards, forms_text, Rect2(21, 268, 518, 38), 12, Color("d9c8f3"))
	_text(rewards, "EVOLUTION XP BANKED" if successful else "POTENTIAL EVO XP LOST", Rect2(19, 304, 376, 27), 16, Color("c2e4ff"))
	_text(rewards, ("+%d" if successful else "-%d") % int(report.get("evo_xp", 0)), Rect2(399, 304, 142, 27), 18, accent, HORIZONTAL_ALIGNMENT_RIGHT)
	_text(rewards, "TOTAL MATERIALS IN CAMP: %d" % _banked_material_count(), Rect2(19, 342, 522, 19), 13, Color("b3c6dd"), HORIZONTAL_ALIGNMENT_RIGHT)
	var camp := _button(menu_root, "⌂  RETURN TO CAMP", Rect2(20, 566, 356, 58), "violet")
	camp.pressed.connect(_open_page.bind("home"))
	var replay := _button(menu_root, "▶  PLAY AGAIN", Rect2(389, 566, 356, 58), "gold")
	replay.pressed.connect(_start_run)
	var collection := _button(menu_root, "✿  CREATURE COLLECTION", Rect2(758, 566, 374, 58), "blue")
	collection.pressed.connect(_open_page.bind("collection"))
	ghost_report_buttons.clear()
	if not ghost_reveal_pending.is_empty():
		# Leave the report visible for 2.8s before the spirit reveal.
		# Disable navigation until after the rare celebration so it cannot be missed.
		for b in [camp, replay, collection]:
			b.disabled = true
			ghost_report_buttons.append(b)

func _screen_background(title: String, subtitle: String) -> void:
	var main := ColorRect.new()
	main.color = Color("101936")
	main.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	main.mouse_filter = Control.MOUSE_FILTER_IGNORE
	menu_root.add_child(main)
	_panel(menu_root, Rect2(0, 0, 1152, 51), Color("2c845d"), Color("123c40"), 0)
	_panel(menu_root, Rect2(0, 51, 1152, 597), Color("0f1d45"), Color("243e79"), 3)
	_text(menu_root, "✿  " + title, Rect2(15, 2, 730, 43), 26, Color("f4fff5"))
	_text(menu_root, subtitle, Rect2(28, 57, 850, 35), 15, Color("adc5ff"))
	var back := _button(menu_root, "✕", Rect2(1086, 4, 57, 43), "violet")
	back.pressed.connect(_open_page.bind("home"))

func _perm_rank(id: String, creature_id: String = "") -> int:
	var species: String = selected_creature if creature_id == "" else creature_id
	var species_upgrades: Dictionary = permanent_upgrades.get(species, {})
	return int(species_upgrades.get(id, 0))

func _perm_price(id: String, rank: int) -> int:
	var base: int = int(PERMANENT_UPGRADES[id]["base_cost"])
	return base * (rank + 1) + 15 * rank * rank

func _build_permanent_upgrades_menu() -> void:
	_screen_background("UPGRADES", "Permanent upgrades for %s  •  shared across all forms, including Gold" % str(CREATURES[selected_creature]["name"]))
	shop_rows.clear()
	var wallet := _panel(menu_root, Rect2(875, 7, 198, 38), Color("0b1533"), Color("4c699e"), 2)
	shop_gold_label = _text(wallet, "●  %d GOLD" % gold, Rect2(8, 3, 182, 31), 17, Color("ffde73"), HORIZONTAL_ALIGNMENT_CENTER)
	var scroll_frame := _panel(menu_root, Rect2(15, 99, 1122, 538), Color("0b1735"), Color("38569a"), 2)
	var scroll := ScrollContainer.new()
	scroll.position = Vector2(9, 8)
	scroll.size = Vector2(1103, 522)
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	scroll_frame.add_child(scroll)
	var grid := GridContainer.new()
	grid.columns = 2
	grid.add_theme_constant_override("h_separation", 15)
	grid.add_theme_constant_override("v_separation", 11)
	scroll.add_child(grid)
	for id in PERMANENT_UPGRADE_ORDER:
		var row := _panel(grid, Rect2(Vector2.ZERO, Vector2(536, 98)), Color("315a47"), Color("091c32"), 4)
		row.custom_minimum_size = Vector2(536, 98)
		row.size_flags_horizontal = Control.SIZE_SHRINK_BEGIN
		var border := _panel(row, Rect2(6, 6, 522, 86), Color("447a5c"), Color("86bca0"), 2)
		border.mouse_filter = Control.MOUSE_FILTER_IGNORE
		var icon_back := _panel(row, Rect2(12, 14, 61, 66), Color("0b1832"), Color("1a304e"), 3)
		icon_back.mouse_filter = Control.MOUSE_FILTER_IGNORE
		_text(icon_back, str(PERMANENT_UPGRADES[id]["icon"]), Rect2(0, 7, 61, 49), 36, Color("ffe28b"), HORIZONTAL_ALIGNMENT_CENTER).mouse_filter = Control.MOUSE_FILTER_IGNORE
		_text(row, str(PERMANENT_UPGRADES[id]["name"]), Rect2(85, 8, 270, 26), 19, Color("ffe083")).mouse_filter = Control.MOUSE_FILTER_IGNORE
		var stars := _text(row, "", Rect2(85, 33, 280, 27), 20, Color("ffca55"))
		stars.mouse_filter = Control.MOUSE_FILTER_IGNORE
		_text(row, str(PERMANENT_UPGRADES[id]["detail"]), Rect2(85, 67, 310, 22), 11, Color("e3f6e6")).mouse_filter = Control.MOUSE_FILTER_IGNORE
		var purchase := _button(row, "", Rect2(396, 25, 127, 48), "gold")
		purchase.add_theme_font_size_override("font_size", 17)
		purchase.pressed.connect(_buy_permanent_upgrade.bind(id))
		shop_rows[id] = {"stars": stars, "button": purchase}
	_refresh_shop_rows()

func _refresh_shop_rows() -> void:
	if is_instance_valid(shop_gold_label):
		shop_gold_label.text = "●  %d GOLD" % gold
	for id in PERMANENT_UPGRADE_ORDER:
		if not shop_rows.has(id):
			continue
		var data: Dictionary = shop_rows[id]
		var stars: Label = data["stars"]
		var purchase: Button = data["button"]
		var rank: int = _perm_rank(id)
		var cap: int = int(PERMANENT_UPGRADES[id]["max"])
		stars.text = ("★".repeat(rank) + "☆".repeat(cap - rank)) + "   %d/%d" % [rank, cap]
		if rank >= cap:
			purchase.text = "MAX"
			purchase.disabled = true
			purchase.tooltip_text = "Fully upgraded"
		else:
			var cost: int = _perm_price(id, rank)
			purchase.text = "● %d" % cost
			purchase.disabled = gold < cost
			purchase.tooltip_text = "Spend %d gold for the next rank" % cost

func _buy_permanent_upgrade(id: String) -> void:
	if state != "MENU" or menu_page != "upgrades" or not PERMANENT_UPGRADES.has(id):
		return
	var cap: int = int(PERMANENT_UPGRADES[id]["max"])
	var rank: int = _perm_rank(id)
	if rank >= cap:
		return
	var price: int = _perm_price(id, rank)
	if gold < price:
		return
	gold -= price
	var creature_upgrades: Dictionary = permanent_upgrades.get(selected_creature, {}).duplicate()
	creature_upgrades[id] = rank + 1
	permanent_upgrades[selected_creature] = creature_upgrades
	_save_collection()
	_refresh_shop_rows()

func _apply_earned_xp(amount: int) -> void:
	var earned: float = float(amount) * (1.0 + 0.03 * float(_perm_rank("wisdom"))) + xp_remainder
	var whole: int = int(floorf(earned))
	xp_remainder = earned - float(whole)
	xp += whole
	run_xp_earned += whole # Records ALL XP collected, even after spending in-run levels.

func _pickup_radius() -> float:
	return PICKUP_RADIUS * (1.0 + 0.05 * float(_perm_rank("magnet")))

func _cooldown_factor() -> float:
	return 1.0 - 0.03 * float(_perm_rank("reflexes"))

func _gold_reward(base_amount: int) -> int:
	return maxi(1, int(roundi(float(base_amount) * (1.0 + 0.05 * float(_perm_rank("fortune"))))))


func _collect_run_gold(amount: int) -> void:
	var base := maxi(0, amount)
	pending_gold += base
	if _has_trait(selected_variant, "gold"):
		midas_fraction += float(base) * 0.5
		var bonus := int(floorf(midas_fraction))
		midas_fraction -= float(bonus)
		pending_gold += bonus
		run_midas_gold += bonus

func _build_collection_menu() -> void:
	_screen_background("CREATURES", "Browse your collection. Choose an unlocked creature to play as.")
	var counter := _panel(menu_root, Rect2(850, 8, 216, 35), Color("0c1635"), Color("2c567e"), 2)
	collection_count_label = _text(counter, "%d / %d UNLOCKED" % [_normal_unlocked_count(), CREATURES.size()], Rect2(10, 2, 197, 29), 16, Color("eef7ff"), HORIZONTAL_ALIGNMENT_CENTER)
	var search := LineEdit.new()
	search.position = Vector2(22, 101)
	search.size = Vector2(314, 42)
	search.placeholder_text = "Search creature name..."
	search.text = collection_query
	search.add_theme_font_size_override("font_size", 17)
	search.add_theme_color_override("font_color", Color("eef5ff"))
	var search_style := StyleBoxFlat.new()
	search_style.bg_color = Color("0a1434")
	search_style.border_color = Color("466bb6")
	search_style.set_border_width_all(3)
	search.add_theme_stylebox_override("normal", search_style)
	menu_root.add_child(search)
	search.text_changed.connect(_on_search_changed)
	var form_filter := OptionButton.new()
	form_filter.position = Vector2(350, 101)
	form_filter.size = Vector2(190, 42)
	form_filter.add_item("ALL FORMS", 0)
	form_filter.add_item("NORMAL", 1)
	form_filter.add_item("CORRUPT", 2)
	form_filter.add_item("BLESSED", 3)
	form_filter.add_item("GOLD", 4)
	form_filter.add_item("GHOST", 5)
	form_filter.add_item("SHINY", 6)
	form_filter.add_item("SHINY + BLESSED", 7)
	form_filter.add_item("SHINY + CORRUPT", 8)
	form_filter.select((["all"] + OWNABLE_FORMS).find(collection_form))
	menu_root.add_child(form_filter)
	form_filter.item_selected.connect(_set_form_filter)
	var owned_filter := OptionButton.new()
	owned_filter.position = Vector2(552, 101)
	owned_filter.size = Vector2(177, 42)
	owned_filter.add_item("SHOW ALL", 0)
	owned_filter.add_item("UNLOCKED", 1)
	owned_filter.add_item("LOCKED", 2)
	owned_filter.select(["all", "owned", "locked"].find(collection_ownership))
	menu_root.add_child(owned_filter)
	owned_filter.item_selected.connect(_set_ownership_filter)
	var left_panel := _panel(menu_root, Rect2(18, 151, 717, 473), Color("142655"), Color("4268b5"), 2)
	var scroll := ScrollContainer.new()
	scroll.position = Vector2(10, 12)
	scroll.size = Vector2(694, 449)
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	left_panel.add_child(scroll)
	collection_grid = GridContainer.new()
	collection_grid.columns = 5
	collection_grid.add_theme_constant_override("h_separation", 8)
	collection_grid.add_theme_constant_override("v_separation", 9)
	scroll.add_child(collection_grid)
	detail_panel = _panel(menu_root, Rect2(750, 79, 386, 544), Color("17234b"), Color("456dbf"))
	_refresh_collection_grid()
	_refresh_detail_panel()

func _set_form_filter(index: int) -> void:
	collection_form = (["all"] + OWNABLE_FORMS)[index]
	_refresh_collection_grid()

func _set_ownership_filter(index: int) -> void:
	collection_ownership = ["all", "owned", "locked"][index]
	_refresh_collection_grid()

func _on_search_changed(value: String) -> void:
	collection_query = value
	_refresh_collection_grid()

func _owns_form(id: String, form: String) -> bool:
	return bool(unlocked.get(id, false)) if form == "normal" else bool(variant_collection.get("%s|%s" % [id, form], false))

func _refresh_collection_grid() -> void:
	if not is_instance_valid(collection_grid):
		return
	for child in collection_grid.get_children():
		collection_grid.remove_child(child)
		child.queue_free()
	var visible := 0
	for id_key in CREATURES.keys():
		var id: String = str(id_key)
		if not collection_query.is_empty() and not str(CREATURES[id]["name"]).to_lower().contains(collection_query.to_lower()):
			continue
		var forms := OWNABLE_FORMS if collection_form == "all" else [collection_form]
		for form_value in forms:
			var form: String = str(form_value)
			var owned := _owns_form(id, form)
			if form != "normal" and not owned and collection_form == "all":
				continue
			if collection_ownership == "owned" and not owned:
				continue
			if collection_ownership == "locked" and owned:
				continue
			_add_creature_card(collection_grid, id, form, owned)
			visible += 1
	if visible == 0:
		var nothing := Label.new()
		nothing.text = "No creatures match this filter."
		nothing.custom_minimum_size = Vector2(600, 60)
		nothing.add_theme_font_size_override("font_size", 18)
		nothing.add_theme_color_override("font_color", Color("b7c8f6"))
		collection_grid.add_child(nothing)

func _add_creature_card(grid: GridContainer, creature_id: String, form: String, owned: bool) -> void:
	var button := Button.new()
	button.custom_minimum_size = Vector2(127, 139)
	button.size = Vector2(127, 139)
	button.focus_mode = Control.FOCUS_NONE
	button.clip_contents = true
	button.text = ""
	var highlighted: bool = inspected_id == creature_id and inspected_form == form
	var card_style := StyleBoxFlat.new()
	card_style.bg_color = Color("416cab") if owned else Color("606c8c")
	card_style.border_color = Color("ffe27c") if highlighted else Color("0b1634")
	card_style.set_border_width_all(4 if highlighted else 3)
	button.add_theme_stylebox_override("normal", card_style)
	var hover_style: StyleBoxFlat = card_style.duplicate() as StyleBoxFlat
	hover_style.bg_color = Color("648cd4") if owned else Color("7e88a4")
	button.add_theme_stylebox_override("hover", hover_style)
	button.add_theme_stylebox_override("pressed", hover_style)
	grid.add_child(button)
	_portrait_form(button, creature_id, Rect2(21, 16, 85, 84), form, owned)
	var nametag := ColorRect.new()
	nametag.position = Vector2(3, 105)
	nametag.size = Vector2(121, 31)
	nametag.color = Color("111d3c")
	nametag.mouse_filter = Control.MOUSE_FILTER_IGNORE
	button.add_child(nametag)
	var display_name: String = str(CREATURES[creature_id]["name"]) if owned else "???"
	var text_label := _text(button, display_name, Rect2(3, 106, 121, 30), 14, Color.WHITE, HORIZONTAL_ALIGNMENT_CENTER)
	text_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	if not owned:
		var lock_label := _text(button, "LOCKED", Rect2(53, 5, 70, 24), 11, Color("ffdc71"), HORIZONTAL_ALIGNMENT_RIGHT)
		lock_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	elif form != "normal":
		var form_label := _text(button, form.to_upper(), Rect2(5, 3, 116, 25), 11, Color("f3e7ff"))
		form_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	button.pressed.connect(_inspect_creature.bind(creature_id, form))

func _inspect_creature(creature_id: String, form: String) -> void:
	inspected_id = creature_id
	inspected_form = form
	_refresh_collection_grid()
	_refresh_detail_panel()

# Split a collection perk into genuine on-screen lines, using the active UI
# font's measured pixel width rather than an estimated character count.
# This avoids the one-line clipping seen on Tidal Wake and long variant perks.
func _collection_perk_lines(value: String, font: Font, font_size: int, max_line_width: float) -> PackedStringArray:
	var lines := PackedStringArray()
	var current := ""
	for word in value.split(" ", false):
		var proposed: String = word if current.is_empty() else current + " " + word
		if current.is_empty() or font.get_string_size(proposed, HORIZONTAL_ALIGNMENT_LEFT, -1, font_size).x <= max_line_width:
			current = proposed
		else:
			lines.append(current)
			current = word
	if not current.is_empty():
		lines.append(current)
	return lines

func _refresh_detail_panel() -> void:
	if not is_instance_valid(detail_panel):
		return
	for child in detail_panel.get_children():
		detail_panel.remove_child(child)
		child.queue_free()
	var owned := _owns_form(inspected_id, inspected_form)
	var name: String = str(CREATURES[inspected_id]["name"]) if owned else "???"
	_panel(detail_panel, Rect2(13, 14, 359, 218), Color("0a132d"), Color("2e4c82"), 2)
	_portrait_form(detail_panel, inspected_id, Rect2(132, 48, 124, 124), inspected_form, owned)
	# Evolution button fits the marked red box to the LEFT of the name/rarity.
	# Name and rarity controls are deliberately narrowed so they cannot overlap.
	_text(detail_panel, name, Rect2(101, 238, 271, 42), 29, Color("ffda65"), HORIZONTAL_ALIGNMENT_CENTER)
	var rarity := _rarity_name(inspected_id) if owned else "UNDISCOVERED"
	_text(detail_panel, rarity + "  •  " + inspected_form.to_upper(), Rect2(99, 285, 273, 29), 14, Color("cda7ff"), HORIZONTAL_ALIGNMENT_CENTER)
	var evolution: Dictionary = _evo_record(inspected_id, inspected_form)
	var evo_stage: int = int(evolution["stage"])
	var evolve_button := _button(detail_panel, "EVOLVE\nLV %d" % (evo_stage + 1), Rect2(19, 259, 77, 60), "green")
	evolve_button.add_theme_font_size_override("font_size", 12)
	evolve_button.disabled = not owned
	evolve_button.tooltip_text = "Evolution, permanent XP and footstep equipment" if owned else "Unlock this creature form to evolve it"
	if owned:
		evolve_button.pressed.connect(_open_evolution_panel.bind(inspected_id, inspected_form))
		if evo_stage < 5 and int(evolution["xp"]) >= EVO_COSTS[evo_stage]:
			evolve_button.text = "EVOLVE\nREADY!"
	# Confine every line of the perk description to its own card.
	# This is especially important for long perks such as MIDAS + Bubble Pop.
	var perk_card := _panel(detail_panel, Rect2(20, 325, 346, 101), Color("101c3b"), Color("344f8c"), 2)
	perk_card.clip_contents = true
	var hint := "Choose this creature for your next run." if owned else ("Hatch this form in the Hatchery." if inspected_form.contains("shiny") else "Rare death reward: 1 in 10,000." if _has_trait(inspected_form, "ghost") else "Win this creature from the chip slot machine." if inspected_form in ["normal", "gold"] else "Find this variant and extract to unlock it.")
	_text(perk_card, hint, Rect2(9, 3, 328, 25), 13, Color("f5e6cd"), HORIZONTAL_ALIGNMENT_CENTER)
	var signature_title := _signature_name(inspected_id) if owned else "Unknown Signature"
	var signature_text := _signature_desc(inspected_id) if owned else "Unlock this creature to reveal its signature move."
	if owned and _has_trait(inspected_form, "gold"):
		signature_title = "MIDAS  •  " + signature_title
		signature_text = "+50% gold from pickups. " + signature_text
	elif owned and _has_trait(inspected_form, "ghost"):
		signature_title = "GHOST EVASION  •  " + signature_title
		signature_text = "5% chance to negate any incoming damage. " + signature_text
	# Fit the perk heading to the panel instead of cropping Gold / Ghost titles.
	var perk_title := _text(perk_card, signature_title, Rect2(8, 28, 330, 23), 15, Color("ffdf81"), HORIZONTAL_ALIGNMENT_CENTER)
	perk_title.autowrap_mode = TextServer.AUTOWRAP_OFF
	var perk_title_font: Font = perk_title.get_theme_font("font")
	var title_size := 15
	while title_size > 10 and perk_title_font.get_string_size(signature_title, HORIZONTAL_ALIGNMENT_LEFT, -1, title_size).x > 316.0:
		title_size -= 1
	perk_title.add_theme_font_size_override("font_size", title_size)

	# Godot labels can clip rather than wrap when constrained by this panel.
	# Lay out up to three centered lines explicitly, with measured font widths.
	var perk_description := _text(perk_card, "", Rect2(13, 52, 320, 45), 11, Color("d7e8ff"), HORIZONTAL_ALIGNMENT_CENTER)
	var perk_font: Font = perk_description.get_theme_font("font")
	var desc_size := 10
	var desc_lines := PackedStringArray()
	for candidate_size in [12, 11, 10, 9]:
		var candidate_lines := _collection_perk_lines(signature_text, perk_font, candidate_size, 314.0)
		if candidate_lines.size() <= 3 and perk_font.get_height(candidate_size) * float(candidate_lines.size()) <= 44.0:
			desc_size = candidate_size
			desc_lines = candidate_lines
			break
	if desc_lines.is_empty():
		desc_size = 9
		desc_lines = _collection_perk_lines(signature_text, perk_font, desc_size, 314.0)
	perk_description.text = "\n".join(desc_lines)
	perk_description.add_theme_font_size_override("font_size", desc_size)
	perk_description.autowrap_mode = TextServer.AUTOWRAP_OFF
	perk_description.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	perk_description.custom_maximum_size = Vector2(320, 45)
	perk_description.tooltip_text = signature_text

	if owned:
		var choose := _button(detail_panel, "CHOOSE", Rect2(23, 432, 338, 45), "gold")
		choose.pressed.connect(_select_creature.bind(inspected_id, inspected_form))
		if selected_creature == inspected_id and selected_variant == inspected_form:
			choose.text = "✓  CURRENT CREATURE"
	else:
		var locked := _button(detail_panel, "LOCKED", Rect2(23, 432, 338, 45), "dark")
		locked.disabled = true
	var slots := _button(detail_panel, "◆  CREATURE SLOTS", Rect2(23, 488, 338, 38), "violet")
	slots.pressed.connect(_open_page.bind("slots"))

# Each form has its own permanent level, XP balance, and equipped trail.
func _evo_key(creature_id: String, form: String) -> String:
	return "%s|%s" % [creature_id, form]

func _evo_record(creature_id: String, form: String) -> Dictionary:
	var key := _evo_key(creature_id, form)
	var stored: Dictionary = evolution_progress.get(key, {})
	return {"stage": clampi(int(stored.get("stage", 0)), 0, 5),
		"xp": maxi(0, int(stored.get("xp", 0))),
		"equipped": clampi(int(stored.get("equipped", 0)), 0, clampi(int(stored.get("stage", 0)), 0, 5))}

func _equipped_trail() -> int:
	return int(_evo_record(selected_creature, selected_variant)["equipped"])

func _open_evolution_panel(creature_id: String, form: String) -> void:
	if not _owns_form(creature_id, form):
		return
	if is_instance_valid(evolution_overlay):
		evolution_overlay.queue_free()
	# Full-screen modal: all coordinates use the 1152x648 design resolution.
	evolution_overlay = Control.new()
	evolution_overlay.size = Vector2(1152, 648)
	evolution_overlay.mouse_filter = Control.MOUSE_FILTER_STOP
	menu_root.add_child(evolution_overlay)
	var dim := ColorRect.new()
	dim.color = Color(0.02, 0.04, 0.11, 0.88)
	dim.size = Vector2(1152, 648)
	dim.mouse_filter = Control.MOUSE_FILTER_STOP
	evolution_overlay.add_child(dim)
	var window := _panel(evolution_overlay, Rect2(138, 42, 876, 562), Color("17274b"), Color("80c0bb"), 4)
	var name: String = str(CREATURES[creature_id]["name"])
	_text(window, "✿ EVOLUTION  •  " + name.to_upper(), Rect2(22, 8, 760, 39), 26, Color("f6e394"))
	_text(window, form.to_upper() + " FORM  •  PERMANENT PROGRESSION", Rect2(25, 45, 680, 25), 14, Color("b8c9f7"))
	var close := _button(window, "✕", Rect2(811, 12, 49, 40), "violet")
	close.pressed.connect(_close_evolution_panel)
	var record: Dictionary = _evo_record(creature_id, form)
	var stage: int = int(record["stage"])
	var evo_xp: int = int(record["xp"])
	var equipped: int = int(record["equipped"])
	var upper_text := "MAX EVOLUTION REACHED" if stage >= 5 else "NEXT EVOLUTION: %d / %d XP" % [evo_xp, EVO_COSTS[stage]]
	_text(window, "EVOLUTION LEVEL  %d / 6" % (stage + 1), Rect2(25, 78, 360, 32), 20, Color("f3e29d"))
	_text(window, upper_text, Rect2(389, 80, 450, 30), 17, Color("a7e8dc"), HORIZONTAL_ALIGNMENT_RIGHT)
	var bar_back := _panel(window, Rect2(25, 113, 826, 13), Color("0a1730"), Color("3e6494"), 2)
	var fill := ColorRect.new()
	fill.position = Vector2(3, 3)
	fill.size = Vector2(820.0 * (1.0 if stage >= 5 else clampf(float(evo_xp) / float(EVO_COSTS[stage]), 0.0, 1.0)), 7)
	fill.color = Color("64dcb5")
	bar_back.add_child(fill)
	_text(window, "Extract safely to bank 10% of all combat XP earned during the run. Defeat/quit = no evolution XP.", Rect2(25, 131, 828, 33), 14, Color("c3d7f3"), HORIZONTAL_ALIGNMENT_CENTER)
	for level_index in range(1, 6):
		var slot_y := 174 + (level_index - 1) * 60
		var enabled: bool = level_index <= stage
		var strip := _panel(window, Rect2(25, slot_y, 826, 55), Color("25466a") if enabled else Color("172942"), Color("66bbaa") if level_index == equipped and enabled else Color("384e70"), 2)
		_text(strip, "%d   %s" % [level_index, TRAIL_TITLES[level_index]], Rect2(11, 2, 340, 25), 18, Color("a9ffde") if enabled else Color("acbad4"))
		_text(strip, str(TRAIL_DESCRIPTIONS[level_index]), Rect2(12, 25, 582, 25), 12, Color("e3efff"))
		var action := _button(strip, "EQUIPPED" if equipped == level_index else ("EQUIP" if enabled else "LOCKED"), Rect2(675, 8, 134, 39), "green" if enabled else "dark")
		action.add_theme_font_size_override("font_size", 14)
		action.disabled = not enabled or equipped == level_index
		if enabled:
			action.pressed.connect(_equip_evolution_trail.bind(creature_id, form, level_index))
	var cost_line := "ALL 5 FOOTSTEP EVOLUTIONS UNLOCKED" if stage >= 5 else "EVOLUTION %d COST: %d XP     •     BANKED: %d XP" % [stage + 1, EVO_COSTS[stage], evo_xp]
	_text(window, cost_line, Rect2(25, 478, 568, 40), 17, Color("ffe4a9"))
	var evolve := _button(window, "MAX EVOLUTION" if stage >= 5 else "✦ EVOLVE NOW", Rect2(598, 487, 252, 46), "gold")
	evolve.disabled = stage >= 5 or evo_xp < EVO_COSTS[stage]
	if stage < 5:
		evolve.pressed.connect(_purchase_evolution.bind(creature_id, form))

func _close_evolution_panel() -> void:
	if is_instance_valid(evolution_overlay):
		evolution_overlay.queue_free()
		evolution_overlay = null

func _purchase_evolution(creature_id: String, form: String) -> void:
	if not _owns_form(creature_id, form):
		return
	var record := _evo_record(creature_id, form)
	var stage: int = int(record["stage"])
	if stage >= 5 or int(record["xp"]) < EVO_COSTS[stage]:
		return
	record["xp"] = int(record["xp"]) - EVO_COSTS[stage]
	record["stage"] = stage + 1
	record["equipped"] = stage + 1
	evolution_progress[_evo_key(creature_id, form)] = record
	_save_collection()
	_refresh_detail_panel()
	_open_evolution_panel(creature_id, form)

func _equip_evolution_trail(creature_id: String, form: String, tier: int) -> void:
	if not _owns_form(creature_id, form):
		return
	var record := _evo_record(creature_id, form)
	if tier < 0 or tier > int(record["stage"]):
		return
	record["equipped"] = tier
	evolution_progress[_evo_key(creature_id, form)] = record
	_save_collection()
	_open_evolution_panel(creature_id, form)

func _rarity_name(id: String) -> String:
	var weight: int = int(CREATURES[id]["weight"])
	if weight <= 3:
		return "MYTHICAL"
	if weight <= 5:
		return "ULTRA RARE"
	return "COMMON"

func _build_slots_menu() -> void:
	# Two-panel slot arcade: vivid red machine on left, collected results on right.
	var backdrop := ColorRect.new()
	backdrop.color = Color("10152e")
	backdrop.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	menu_root.add_child(backdrop)
	var machine := _panel(menu_root, Rect2(14, 16, 522, 615), Color("c4485c"), Color("401a3f"), 5)
	var results_panel := _panel(menu_root, Rect2(550, 16, 587, 615), Color("17244a"), Color("617bd2"), 5)
	_text(machine, "CREA2RS SLOTS", Rect2(12, 3, 490, 50), 32, Color("ffe078"), HORIZONTAL_ALIGNMENT_CENTER)
	var white_case := _panel(machine, Rect2(27, 65, 466, 221), Color("fff3d4"), Color("3e233b"), 5)
	# Slot reels are real creature portraits, not symbol/leaf placeholders.
	slot_reels.clear()
	for reel_i in range(3):
		var frame := _panel(white_case, Rect2(17 + reel_i * 148, 18, 137, 179), Color("0a1026"), Color("080b1b"), 5)
		frame.clip_contents = true
		var inset := _panel(frame, Rect2(8, 9, 121, 145), Color("111a39"), Color("4c5071"), 3)
		inset.clip_contents = true
		var display_id: String = reel_ids[reel_i]
		var picture := _portrait(inset, display_id, Rect2(15, 23, 91, 91))
		slot_reels.append(picture)
		_text(frame, str(reel_i + 1), Rect2(49, 153, 39, 20), 12, Color("e9d8fd"), HORIZONTAL_ALIGNMENT_CENTER)
	var spin_one := _button(machine, "◆ PULL x1     •     %d CHIP" % SPIN_COST, Rect2(37, 300, 448, 56), "gold")
	spin_one.add_theme_font_size_override("font_size", 23)
	spin_one.disabled = is_spinning or poker_chips < SPIN_COST
	spin_one.pressed.connect(_begin_spin.bind(1))
	var spin_ten := _button(machine, "◆ PULL x10    •    %d CHIPS" % (SPIN_COST * 10), Rect2(37, 365, 448, 56), "gold")
	spin_ten.add_theme_font_size_override("font_size", 23)
	spin_ten.disabled = is_spinning or poker_chips < SPIN_COST * 10
	spin_ten.pressed.connect(_begin_spin.bind(10))
	var spin_hundred := _button(machine, "◆ QUICK x100 •   %d CHIPS" % (SPIN_COST * 100), Rect2(37, 430, 448, 56), "gold")
	spin_hundred.add_theme_font_size_override("font_size", 22)
	spin_hundred.disabled = is_spinning or poker_chips < SPIN_COST * 100
	spin_hundred.pressed.connect(_begin_spin.bind(100))
	var balance := _panel(machine, Rect2(38, 498, 447, 40), Color("671d42"), Color("e88c88"), 2)
	_text(balance, "◆ %d CHIPS          ● %d GOLD" % [poker_chips, gold], Rect2(8, 1, 429, 35), 17, Color("fff0ac"), HORIZONTAL_ALIGNMENT_CENTER)
	var slot_info := "SPINNING..." if is_spinning else ("Match 3 to unlock a creature! All pulls earn rewards." if spin_results.is_empty() else menu_message)
	slot_status = _text(machine, slot_info, Rect2(29, 542, 467, 31), 14, Color("fff8d5"), HORIZONTAL_ALIGNMENT_CENTER)
	spin_label = slot_status
	_text(machine, "RARE  1/100 EACH  •  GOLD  1/1000  •  1 CHIP / PULL", Rect2(22, 573, 482, 20), 12, Color("fff0e0"), HORIZONTAL_ALIGNMENT_CENTER)
	_text(machine, "PITY: RARE %d/100  •  GOLD %d/1000" % [slot_pulls_since_special, slot_pulls_since_gold], Rect2(18, 592, 490, 18), 11, Color("ffe6d9"), HORIZONTAL_ALIGNMENT_CENTER)
	_text(results_panel, "RESULTS", Rect2(11, 5, 565, 38), 26, Color("d6dfff"), HORIZONTAL_ALIGNMENT_CENTER)
	var content := _panel(results_panel, Rect2(11, 48, 565, 495), Color("111a3c"), Color("304783"), 3)
	var scroll := ScrollContainer.new()
	scroll.position = Vector2(10, 9)
	scroll.size = Vector2(542, 476)
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	content.add_child(scroll)
	var grid := GridContainer.new()
	grid.columns = 4
	grid.add_theme_constant_override("h_separation", 7)
	grid.add_theme_constant_override("v_separation", 9)
	scroll.add_child(grid)
	if spin_results.is_empty():
		var help := _text(grid, "Your spin rewards appear here!", Rect2(0, 0, 520, 55), 18, Color("cad5ff"))
		help.custom_minimum_size = Vector2(520, 55)
	else:
		# Last batch remains visible, including each individual x10 result.
		for reward in spin_results:
			_add_slot_reward_card(grid, reward)
	var progress := "SPINNING  %d LEFT" % spins_remaining if is_spinning else "%d RESULT%s" % [spin_results.size(), "" if spin_results.size() == 1 else "S"]
	_text(results_panel, progress, Rect2(15, 554, 264, 38), 17, Color("d5dfff"))
	var dev_slots := _button(results_panel, "DEV [F2]", Rect2(295, 557, 138, 35), "dark")
	dev_slots.add_theme_font_size_override("font_size", 13)
	dev_slots.pressed.connect(_toggle_dev_console)
	var back := _button(results_panel, "← BACK", Rect2(442, 557, 126, 35), "violet")
	back.add_theme_font_size_override("font_size", 15)
	back.disabled = is_spinning
	back.pressed.connect(_open_page.bind("home"))

func _add_slot_reward_card(grid: GridContainer, reward: Dictionary) -> void:
	var jackpot: bool = bool(reward.get("triple", false))
	var creature_id: String = str(reward.get("id", "koikoi"))
	var form: String = str(reward.get("form", "normal"))
	var reward_gold: int = int(reward.get("gold", 0))
	var gold_card: bool = jackpot and form == "gold"
	var card := _panel(grid, Rect2(0, 0, 128, 164), Color("60431b") if gold_card else Color("376b61") if jackpot else Color("3d4872"), Color("ffe07a") if gold_card else Color("c2e4b0") if jackpot else Color("7b87b7"), 3)
	card.custom_minimum_size = Vector2(128, 164)
	# Short reward-card reveal animation (works for each x1 or x10 result).
	card.pivot_offset = Vector2(64, 82)
	if spin_results.size() < 100:
		card.scale = Vector2(0.88, 0.88)
		card.modulate.a = 0.0
		var reveal := create_tween().set_parallel(true)
		reveal.tween_property(card, "scale", Vector2.ONE, 0.20).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
		reveal.tween_property(card, "modulate:a", 1.0, 0.20)
	if jackpot:
		_portrait_form(card, creature_id, Rect2(22, 22, 84, 84), form)
		var title := str(CREATURES[creature_id]["name"])
		_text(card, title, Rect2(4, 114, 119, 25), 14, Color("ffefa6"), HORIZONTAL_ALIGNMENT_CENTER)
		var footer := "+%d GOLD" % reward_gold if reward_gold > 0 else ("NEW " + form.to_upper())
		_text(card, footer, Rect2(4, 139, 119, 20), 11, Color("fff0a2") if reward_gold > 0 else Color("c6ffd9"), HORIZONTAL_ALIGNMENT_CENTER)
		if form != "normal":
			var tag_color := Color("eed0ff")
			if form == "gold":
				tag_color = Color("fff0a0")
			_text(card, form.to_upper(), Rect2(6, 1, 117, 20), 10, tag_color, HORIZONTAL_ALIGNMENT_CENTER)
	else:
		_text(card, "●", Rect2(25, 14, 79, 99), 75, Color("ffcc57"), HORIZONTAL_ALIGNMENT_CENTER)
		_text(card, "GOLD", Rect2(6, 115, 116, 22), 15, Color("fff2ad"), HORIZONTAL_ALIGNMENT_CENTER)
		_text(card, "+%d" % reward_gold, Rect2(4, 139, 120, 20), 13, Color("fff1bb"), HORIZONTAL_ALIGNMENT_CENTER)
# This HUD belongs to the run only. Panels are separate from the menu and the
# upgrade-choice overlay; none of the menu rebuilds can destroy HUD references.
# Layout targets the 1152 x 648 design viewport.
func _hud_panel(parent: Control, bounds: Rect2, background: Color, outline: Color, edge: int = 3) -> Panel:
	var result: Panel = _panel(parent, bounds, background, outline, edge)
	result.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return result

func _hud_text(parent: Control, value: String, bounds: Rect2, size: int = 16, color: Color = Color.WHITE, align: HorizontalAlignment = HORIZONTAL_ALIGNMENT_LEFT) -> Label:
	var result: Label = _text(parent, value, bounds, size, color, align)
	result.mouse_filter = Control.MOUSE_FILTER_IGNORE
	result.autowrap_mode = TextServer.AUTOWRAP_OFF
	return result

func _hud_fill(parent: Control, position: Vector2, height: float, color: Color) -> ColorRect:
	var fill := ColorRect.new()
	fill.position = position
	fill.size = Vector2(0, height)
	fill.color = color
	fill.mouse_filter = Control.MOUSE_FILTER_IGNORE
	parent.add_child(fill)
	return fill

func _build_run_hud() -> void:
	ability_bar = Control.new()
	ability_bar.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	ability_bar.mouse_filter = Control.MOUSE_FILTER_IGNORE
	hud.add_child(ability_bar)

	# Compact semi-transparent HUD, matching the supplied scale reference.
	# These containers never intercept input; only the PAUSE button does.
	# All portrait imagery stays beneath the text and inside its own clipped frame.
	# Top row: name + variant; bottom: portrait, HP, shield, experience.
	var creature_card := _hud_panel(ability_bar, Rect2(16, 16, 307, 112), Color("0e1b35bb"), Color("678fc0"), 2)
	run_name_text = _hud_text(creature_card, "KOIKOI", Rect2(12, 6, 203, 25), 19, Color("ffe5aa"))
	var form_box := _hud_panel(creature_card, Rect2(222, 9, 75, 24), Color("2c305ba8"), Color("987abe"), 1)
	run_form_text = _hud_text(form_box, "NORMAL", Rect2(2, 1, 71, 22), 11, Color("eff4ff"), HORIZONTAL_ALIGNMENT_CENTER)
	run_signature_text = _hud_text(creature_card, "Hunter Fang", Rect2(12, 30, 276, 19), 12, Color("c4d9f4"))
	var portrait_back := _hud_panel(creature_card, Rect2(10, 50, 65, 54), Color("172a4db8"), Color("608db7"), 2)
	portrait_back.clip_contents = true
	# The same 65x54 HUD frame now scales the *whole creature* into a 59x49
	# safe area. Unlike a TextureRect's native-size crop, nothing intersects
	# the name, HP bar or experience bar, even for larger winged creatures.
	run_portrait = RUN_HUD_PORTRAIT.new()
	run_portrait.position = Vector2(3, 2)
	run_portrait.size = Vector2(59, 49)
	run_portrait.set("creature_texture", _form_portrait_texture(selected_creature, selected_variant))
	run_portrait.modulate = _form_color(selected_variant)
	run_portrait.mouse_filter = Control.MOUSE_FILTER_IGNORE
	portrait_back.add_child(run_portrait)
	var health_back := _hud_panel(creature_card, Rect2(83, 55, 160, 24), Color("31283bad"), Color("9e667e"), 1)
	hp_fill = _hud_fill(health_back, Vector2(3, 3), 18.0, Color("e66b82"))
	hp_text = _hud_text(health_back, "♥  100 / 100", Rect2(3, 1, 154, 22), 12, Color("fff9f7"), HORIZONTAL_ALIGNMENT_CENTER)
	shield_text = _hud_text(creature_card, "◆ 0", Rect2(248, 57, 47, 21), 11, Color("b7c8de"), HORIZONTAL_ALIGNMENT_RIGHT)
	var experience_back := _hud_panel(creature_card, Rect2(83, 88, 212, 15), Color("172a42c6"), Color("4e7d9a"), 1)
	xp_fill = _hud_fill(experience_back, Vector2(2, 2), 11.0, Color("57cbca"))
	xp_text = _hud_text(creature_card, "LV 1 • XP 0 / 9", Rect2(85, 85, 209, 22), 10, Color("f2fffb"), HORIZONTAL_ALIGNMENT_CENTER)

	var extraction_card := _hud_panel(ability_bar, Rect2(350, 16, 433, 73), Color("111e3cbb"), Color("6b97b9"), 2)
	run_extraction_title = _hud_text(extraction_card, "◆  EXTRACTION LOCKED", Rect2(9, 4, 415, 27), 17, Color("ffe0a0"), HORIZONTAL_ALIGNMENT_CENTER)
	run_extraction_detail = _hud_text(extraction_card, "Survive to open the portal", Rect2(7, 30, 419, 20), 12, Color("d5e2f8"), HORIZONTAL_ALIGNMENT_CENTER)
	var extraction_track := _hud_panel(extraction_card, Rect2(13, 55, 407, 10), Color("08152fc9"), Color("52748b"), 1)
	run_extraction_fill = _hud_fill(extraction_track, Vector2(2, 2), 6.0, Color("e8b35b"))

	# The button is placed between the extraction banner and run stats.
	# It is the only mouse-interactive element of the combat HUD.
	var pause_button := _button(ability_bar, "II  PAUSE", Rect2(793, 17, 113, 39), "dark")
	pause_button.add_theme_font_size_override("font_size", 14)
	pause_button.pressed.connect(_toggle_pause)
	var dev_in_run := _button(ability_bar, "DEV  [F2]", Rect2(793, 62, 113, 29), "dark")
	dev_in_run.add_theme_font_size_override("font_size", 12)
	dev_in_run.pressed.connect(_toggle_dev_console)

	var stats_card := _hud_panel(ability_bar, Rect2(915, 16, 221, 126), Color("111e3cbb"), Color("6287bb"), 2)
	_hud_text(stats_card, "RUN STATS", Rect2(9, 6, 203, 24), 16, Color("ffe2a9"), HORIZONTAL_ALIGNMENT_CENTER)
	var stats_rule := ColorRect.new()
	stats_rule.position = Vector2(12, 32)
	stats_rule.size = Vector2(197, 1)
	stats_rule.color = Color("6b84a3a0")
	stats_rule.mouse_filter = Control.MOUSE_FILTER_IGNORE
	stats_card.add_child(stats_rule)
	run_wave_text = _hud_text(stats_card, "WAVE 1", Rect2(12, 39, 105, 24), 14, Color("ffe29e"))
	run_time_text = _hud_text(stats_card, "00:00", Rect2(110, 39, 100, 24), 14, Color("f1f5ff"), HORIZONTAL_ALIGNMENT_RIGHT)
	run_kills_text = _hud_text(stats_card, "KILLS 0", Rect2(12, 66, 105, 22), 13, Color("cbdcff"))
	run_chips_text = _hud_text(stats_card, "◆ 0 CHIPS", Rect2(111, 66, 99, 22), 12, Color("ffdb8b"), HORIZONTAL_ALIGNMENT_RIGHT)
	run_materials_text = _hud_text(stats_card, "◆ 0 MATS  •  ● 0 GOLD", Rect2(9, 96, 203, 19), 11, Color("b6cde4"), HORIZONTAL_ALIGNMENT_CENTER)

	run_event_card = _hud_panel(ability_bar, Rect2(355, 101, 427, 39), Color("1a2c4ed3"), Color("90abd6"), 2)
	game_info = _hud_text(run_event_card, "", Rect2(7, 3, 413, 33), 12, Color("fff4cf"), HORIZONTAL_ALIGNMENT_CENTER)
	game_info.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	run_event_card.hide()

	var controls_card := _hud_panel(ability_bar, Rect2(16, 579, 220, 57), Color("111c39bb"), Color("668bb2"), 2)
	_hud_text(controls_card, "CONTROLS", Rect2(9, 3, 201, 19), 12, Color("ffe2a9"))
	_hud_text(controls_card, "WASD  MOVE  •  E  EXTRACT", Rect2(9, 23, 205, 16), 10, Color("d7e7ff"))
	_hud_text(controls_card, "ESC  PAUSE", Rect2(9, 39, 198, 15), 10, Color("c3d3e9"))
	var pickups_card := _hud_panel(ability_bar, Rect2(938, 579, 198, 57), Color("111c39bb"), Color("668bb2"), 2)
	_hud_text(pickups_card, "PICKUPS", Rect2(9, 3, 180, 19), 12, Color("ffe2a9"))
	_hud_text(pickups_card, "◆ CYAN GEMS = XP", Rect2(9, 23, 185, 16), 10, Color("b6f3ed"))
	_hud_text(pickups_card, "◆ CHIPS / GOLD = EXTRACT", Rect2(9, 39, 184, 15), 9, Color("ffdd99"))

	# Compact four-slot hotbar, kept distinct from the two corner helper boxes.
	var dock := _hud_panel(ability_bar, Rect2(257, 564, 641, 72), Color("111e3cc4"), Color("6589c7"), 2)
	var ability_keys: Array[String] = ["Q", "R", "SPACE", "F"]
	var ability_ids: Array[String] = ["heal", "shield", "dash", "nova"]
	var ability_colors: Array[Color] = [Color("75d8a4"), Color("7abafa"), Color("bea0ff"), Color("ffbd78")]
	for i in range(ability_ids.size()):
		var id: String = ability_ids[i]
		var accent: Color = ability_colors[i]
		var tile := _hud_panel(dock, Rect2(7 + i * 158, 7, 154, 58), Color("182b50b3"), Color(accent.r * 0.65, accent.g * 0.65, accent.b * 0.65), 1)
		var key_box := _hud_panel(tile, Rect2(6, 7, 39, 35), Color("111c3ad6"), accent, 2)
		var key_size: int = 10 if ability_keys[i] == "SPACE" else 18
		_hud_text(key_box, ability_keys[i], Rect2(1, 1, 35, 31), key_size, accent, HORIZONTAL_ALIGNMENT_CENTER)
		_hud_text(tile, str(UPGRADE_NAMES[id]), Rect2(46, 7, 103, 20), 11, Color("fff0cd"), HORIZONTAL_ALIGNMENT_CENTER)
		ability_labels[id] = _hud_text(tile, "LOCKED", Rect2(46, 26, 103, 18), 10, Color("a4b0d1"), HORIZONTAL_ALIGNMENT_CENTER)
		var cooldown_back := ColorRect.new()
		cooldown_back.position = Vector2(12, 51)
		cooldown_back.size = Vector2(130, 3)
		cooldown_back.color = Color("101b36")
		cooldown_back.mouse_filter = Control.MOUSE_FILTER_IGNORE
		tile.add_child(cooldown_back)
		ability_cooldown_fills[id] = _hud_fill(tile, Vector2(12, 51), 3.0, accent)
	ability_bar.hide()

func _xp_needed() -> int:
	return 6 + level * 3

func _rank(id: String) -> int:
	return int(move_ranks.get(id, 0))

func _ability_line(id: String, cooldown: float) -> String:
	if _rank(id) <= 0:
		return "LOCKED"
	if cooldown > 0.0:
		return "RANK %d • %.1fs" % [_rank(id), cooldown]
	return "RANK %d • READY" % _rank(id)

func _ability_full_cooldown(id: String) -> float:
	var duration: float = 1.0
	match id:
		"heal": duration = maxf(9.0, 23.0 - 2.5 * _rank("heal"))
		"shield": duration = maxf(12.0, 28.0 - 2.0 * _rank("shield"))
		"dash": duration = maxf(1.15, 4.4 - 0.55 * _rank("dash"))
		"nova": duration = maxf(6.0, 17.0 - 1.55 * _rank("nova"))
	return duration * _cooldown_factor()

func _update_run_hud(delta: float) -> void:
	if state not in ["PLAY", "UPGRADE"]:
		return
	var creature_name: String = str(CREATURES[selected_creature]["name"])
	run_name_text.text = creature_name.to_upper()
	run_name_text.add_theme_font_size_override("font_size", 14 if creature_name.length() > 16 else 16 if creature_name.length() > 12 else 19)
	run_portrait.set("creature_texture", _form_portrait_texture(selected_creature, selected_variant))
	run_portrait.modulate = _form_color(selected_variant)
	run_form_text.text = selected_variant.to_upper()
	match selected_variant:
		"blessed": run_form_text.add_theme_color_override("font_color", Color("fff2b7"))
		"corrupt": run_form_text.add_theme_color_override("font_color", Color("dba8ff"))
		"gold": run_form_text.add_theme_color_override("font_color", Color("ffe38b"))
		"ghost": run_form_text.add_theme_color_override("font_color", Color("9fe6ff"))
		_: run_form_text.add_theme_color_override("font_color", Color("d9edff"))
	run_signature_text.text = _signature_name(selected_creature)
	var shield_amount: int = int(ceilf(maxf(shield_hp, 0.0)))
	shield_text.text = "◆ %d" % shield_amount
	shield_text.add_theme_color_override("font_color", Color("a4e8ff") if shield_amount > 0 else Color("8e9bb8"))

	var hp_target: float = clampf(hp / maxf(max_hp, 1.0), 0.0, 1.0)
	hp_display_ratio = move_toward(hp_display_ratio, hp_target, maxf(delta, 0.0) * 2.8)
	hp_fill.size.x = 154.0 * hp_display_ratio
	hp_fill.color = Color("ed6c80") if hp_target > 0.35 else Color("f0aa59") if hp_target > 0.15 else Color("f05266")
	hp_text.text = "♥  %d / %d" % [int(ceilf(maxf(hp, 0.0))), int(max_hp)]
	var required: int = _xp_needed()
	xp_fill.size.x = 206.0 * clampf(float(xp) / float(maxi(required, 1)), 0.0, 1.0)
	xp_text.text = "LV %d   •   XP %d / %d" % [level, xp, required]

	var minutes: int = int(time_alive / 60.0)
	var seconds: int = int(time_alive) % 60
	run_wave_text.text = "WAVE %d" % wave
	run_wave_text.add_theme_color_override("font_color", Color("ff9d84") if wave >= 7 else Color("ffe29e"))
	run_time_text.text = "%02d:%02d" % [minutes, seconds]
	run_kills_text.text = "KILLS %d" % kills
	run_chips_text.text = "◆ %d CHIPS" % pending_chips
	run_materials_text.text = "◆ %d MATS  •  ● %d GOLD" % [_carried_material_count(), pending_gold]

	var open_gate: bool = time_alive >= EXTRACTION_UNLOCK_SECONDS
	if open_gate:
		run_extraction_title.text = "◆  EXTRACTION AVAILABLE"
		run_extraction_title.add_theme_color_override("font_color", Color("8ff6d7"))
		run_extraction_detail.text = "Return to the glowing portal and press E"
		run_extraction_fill.color = Color("67d7ba")
	else:
		var remaining: int = maxi(0, int(ceilf(EXTRACTION_UNLOCK_SECONDS - time_alive)))
		run_extraction_title.text = "◆  EXTRACTION IN %ds" % remaining
		run_extraction_title.add_theme_color_override("font_color", Color("ffe0a0"))
		run_extraction_detail.text = "Survive until the escape portal activates"
		run_extraction_fill.color = Color("e8b35b")
	run_extraction_fill.size.x = 401.0 * clampf(time_alive / EXTRACTION_UNLOCK_SECONDS, 0.0, 1.0)

	run_event_card.visible = event_timer > 0.0 and not event_message.is_empty()
	game_info.text = event_message if run_event_card.visible else ""
	for id in ["heal", "shield", "dash", "nova"]:
		var cd: float = 0.0
		match id:
			"heal": cd = heal_cooldown
			"shield": cd = shield_cooldown
			"dash": cd = dash_cooldown
			"nova": cd = nova_cooldown
		var rank: int = _rank(id)
		var label: Label = ability_labels[id] as Label
		label.text = _ability_line(id, cd)
		label.add_theme_color_override("font_color", Color("8ce6ca") if rank > 0 and cd <= 0.0 else Color("ffd4a1") if rank > 0 else Color("96a4c5"))
		var fill: ColorRect = ability_cooldown_fills[id] as ColorRect
		fill.size.x = 130.0 * clampf(1.0 - cd / maxf(_ability_full_cooldown(id), 0.01), 0.0, 1.0) if rank > 0 else 0.0

# V25 -- Four permanent farm plots with real-time breeding and inherited forms.
func _hatchery_init() -> void:
	if not hatchery_slots.is_empty():
		return
	for n in range(HATCHERY_SLOT_COUNT):
		hatchery_slots.append({"parents": [{"id": "koikoi", "form": "normal"}, {"id": "koikoi", "form": "normal"}], "phase": "idle", "remaining": 0.0, "child_id": "", "child_form": "normal"})
	if hatchery_last_wall_time <= 0.0:
		hatchery_last_wall_time = Time.get_unix_time_from_system()

func _breeding_choices() -> Array[Dictionary]:
	var choices: Array[Dictionary] = []
	for key in CREATURES.keys():
		var species: String = str(key)
		for form in OWNABLE_FORMS:
			if _owns_form(species, str(form)):
				choices.append({"id": species, "form": str(form)})
	return choices

func _breed_parent_valid(parent: Dictionary) -> bool:
	return CREATURES.has(str(parent.get("id", ""))) and _owns_form(str(parent.get("id", "")), str(parent.get("form", "normal")))

func _roll_offspring(slot: Dictionary, forced_form: String = "") -> Dictionary:
	var parents: Array = slot.get("parents", [])
	var chosen: Dictionary = parents[rng.randi_range(0, 1)]
	var species: String = str(chosen.get("id", "koikoi"))
	if not CREATURES.has(species):
		species = "koikoi"
	if forced_form != "":
		return {"id": species, "form": forced_form}
	# Traits can only come from breeding; shiny is a new 5% mutation for any egg.
	var shiny: bool = rng.randf() < HATCHERY_SHINY_CHANCE
	var available_traits: Dictionary = {}
	for parent_value in parents:
		if not (parent_value is Dictionary):
			continue
		var parent_form: String = str(parent_value.get("form", "normal"))
		for trait_name in ["ghost", "gold", "blessed", "corrupt"]:
			if _has_trait(parent_form, trait_name):
				available_traits[trait_name] = true
	var trait_roll := "normal"
	# One primary trait, avoiding contradictory Blessed + Corrupt offspring.
	if available_traits.has("ghost") and rng.randf() < HATCHERY_GHOST_INHERIT:
		trait_roll = "ghost"
	elif available_traits.has("gold") and rng.randf() < HATCHERY_GOLD_INHERIT:
		trait_roll = "gold"
	else:
		# The 0.75% stacking rate is per egg, not 0.75% of only the 5% shiny eggs.
		# When Shiny fires (5%), 15% of those eggs can inherit a matching trait.
		var bless_chance: float = HATCHERY_STACK_CHANCE / HATCHERY_SHINY_CHANCE if shiny else HATCHERY_BLESSED_INHERIT
		var curse_chance: float = HATCHERY_STACK_CHANCE / HATCHERY_SHINY_CHANCE if shiny else HATCHERY_CORRUPT_INHERIT
		var bless: bool = available_traits.has("blessed") and rng.randf() < bless_chance
		var curse: bool = available_traits.has("corrupt") and rng.randf() < curse_chance
		if bless and curse:
			trait_roll = "blessed" if rng.randf() < 0.5 else "corrupt"
		elif bless:
			trait_roll = "blessed"
		elif curse:
			trait_roll = "corrupt"
	# Gold or Ghost override shiny: those rare single forms retain their unique art.
	# Shiny may coexist with Blessed or Corrupt and uses the custom Shiny artwork.
	if shiny and trait_roll in ["normal", "blessed", "corrupt"]:
		trait_roll = "shiny" if trait_roll == "normal" else "shiny+" + trait_roll
	return {"id": species, "form": trait_roll}

func _hatchery_advance() -> void:
	if hatchery_slots.is_empty():
		return
	var now: float = Time.get_unix_time_from_system()
	var passed: float = clampf(now - hatchery_last_wall_time, 0.0, 3600.0 * 24.0 * 30.0)
	if passed <= 0.0:
		return
	hatchery_last_wall_time = now
	# While actively adventuring, hatching advances at 110% real speed.
	var breeding_delta: float = passed
	var egg_delta: float = passed * (1.1 if state == "PLAY" else 1.0)
	var changed: bool = false
	for i in range(hatchery_unlocked):
		var slot: Dictionary = hatchery_slots[i]
		var phase: String = str(slot.get("phase", "idle"))
		if phase == "breeding":
			var remains: float = float(slot.get("remaining", 0.0)) - breeding_delta
			if remains <= 0.0:
				var child: Dictionary = _roll_offspring(slot)
				slot["child_id"] = str(child["id"])
				slot["child_form"] = str(child["form"])
				slot["phase"] = "egg"
				# If a long offline interval crossed the breeding boundary,
				# credit the leftover time to incubation at the correct rate.
				slot["remaining"] = HATCHERY_EGG_SECONDS + remains * (1.1 if state == "PLAY" else 1.0)
				changed = true
			else:
				slot["remaining"] = remains
		elif phase == "egg":
			slot["remaining"] = float(slot["remaining"]) - egg_delta
		if str(slot["phase"]) == "egg" and float(slot["remaining"]) <= 0.0:
			slot["remaining"] = 0.0
			slot["phase"] = "ready"
			changed = true
		hatchery_slots[i] = slot
		if hatchery_status_labels.has(i) and is_instance_valid(hatchery_status_labels[i]):
			if str(slot["phase"]) == "breeding":
				hatchery_status_labels[i].text = "BREEDING  %s / 01:00" % _hatchery_timer(float(slot["remaining"]))
			elif str(slot["phase"]) == "egg":
				hatchery_status_labels[i].text = "INCUBATING  %s / 09:00" % _hatchery_timer(float(slot["remaining"]))
	hatchery_save_clock += passed
	if changed or hatchery_save_clock >= 10.0:
		hatchery_save_clock = 0.0
		_save_collection()
		if state == "MENU" and menu_page == "hatchery" and changed:
			_rebuild_menu()

func _hatchery_select_parent(selected: int, plot: int, which: int, choices: Array[Dictionary]) -> void:
	if plot >= hatchery_unlocked or selected < 0 or selected >= choices.size():
		return
	var slot: Dictionary = hatchery_slots[plot]
	if str(slot["phase"]) != "idle":
		return
	var parents: Array = slot["parents"]
	parents[which] = choices[selected].duplicate(true)
	slot["parents"] = parents
	hatchery_slots[plot] = slot
	_save_collection()
	_rebuild_menu()

func _hatchery_unlock(plot: int) -> void:
	if plot != hatchery_unlocked or plot >= HATCHERY_SLOT_COUNT:
		return
	var price: int = HATCHERY_UNLOCK_COST[plot]
	if gold < price:
		hatchery_message = "Need %d more gold for this farm plot." % (price - gold)
		_rebuild_menu()
		return
	gold -= price
	hatchery_unlocked += 1
	hatchery_message = "New breeding plot unlocked!"
	_save_collection()
	_rebuild_menu()

func _hatchery_begin(plot: int) -> void:
	if plot >= hatchery_unlocked:
		return
	var slot: Dictionary = hatchery_slots[plot]
	if str(slot["phase"]) != "idle":
		return
	for parent in slot["parents"]:
		if not _breed_parent_valid(parent):
			hatchery_message = "Choose two creatures you already own."
			_rebuild_menu()
			return
	slot["phase"] = "breeding"
	slot["remaining"] = HATCHERY_BREED_SECONDS
	slot["child_id"] = ""
	slot["child_form"] = "normal"
	hatchery_slots[plot] = slot
	hatchery_message = "Plot %d: Breeding started! 1 minute to make an egg." % (plot + 1)
	_save_collection()
	_rebuild_menu()

func _hatchery_claim(plot: int) -> void:
	var slot: Dictionary = hatchery_slots[plot]
	if str(slot["phase"]) != "ready":
		return
	var id: String = str(slot.get("child_id", ""))
	var form: String = str(slot.get("child_form", "normal"))
	if not CREATURES.has(id) or form not in OWNABLE_FORMS:
		return
	var new_form: bool = not _owns_form(id, form)
	if form == "normal":
		unlocked[id] = true
	else:
		variant_collection["%s|%s" % [id, form]] = true
	# Claiming a normal parent species does not erase its special forms.
	hatchery_message = "%s %s hatched! %s" % [str(CREATURES[id]["name"]), form.to_upper(), "NEW FORM!" if new_form else "Already collected."]
	slot["phase"] = "idle"
	slot["remaining"] = 0.0
	slot["child_id"] = ""
	slot["child_form"] = "normal"
	hatchery_slots[plot] = slot
	_save_collection()
	_rebuild_menu()
	_queue_variant_reveal(id, form, new_form, "hatchery")
	_show_next_variant_reveal()

func _hatchery_timer(seconds: float) -> String:
	var sec: int = maxi(0, int(ceilf(seconds)))
	return "%02d:%02d" % [int(sec / 60), sec % 60]

func _hatchery_nest(parent: Control, center: Vector2, phase: String) -> void:
	var nest: Control = HATCHERY_NEST.new()
	nest.position = center - Vector2(65, 55)
	nest.size = Vector2(130, 102)
	nest.call("setup", phase in ["egg", "ready"])
	parent.add_child(nest)

func _build_hatchery_menu() -> void:
	hatchery_status_labels.clear()
	_screen_background("HATCHERY", "Breed two owned creatures • 1m breeding • 9m incubation • 10% faster in a run")
	var wallet := _panel(menu_root, Rect2(872, 7, 195, 37), Color("101a38"), Color("e3c36e"), 2)
	_text(wallet, "● %d GOLD" % gold, Rect2(5, 3, 186, 29), 16, Color("ffe09a"), HORIZONTAL_ALIGNMENT_CENTER)
	_text(menu_root, hatchery_message, Rect2(27, 94, 1075, 19), 12, Color("ffdf9e"))
	var options: Array[Dictionary] = _breeding_choices()
	for index in range(HATCHERY_SLOT_COUNT):
		var x: float = 18.0 + float(index % 2) * 564.0
		var y: float = 118.0 + float(int(index / 2)) * 255.0
		var plot := _panel(menu_root, Rect2(x, y, 550, 246), Color("284c37"), Color("90a866"), 3)
		var open_plot: bool = index < hatchery_unlocked
		_text(plot, "PLOT %d  •  %s" % [index + 1, "OPEN" if open_plot else "LOCKED"], Rect2(13, 7, 520, 28), 17, Color("e9e2aa"))
		var bed := _panel(plot, Rect2(13, 39, 524, 107), Color("765536") if open_plot else Color("3f4445"), Color("987547"), 2)
		for grass in range(8):
			var plant := ColorRect.new()
			plant.position = Vector2(12 + grass * 65, 10 + (grass % 3) * 24)
			plant.size = Vector2(11, 8)
			plant.color = Color("456b34") if grass % 2 else Color("a0a65b")
			plant.mouse_filter = Control.MOUSE_FILTER_IGNORE
			bed.add_child(plant)
		_hatchery_nest(bed, Vector2(262, 68), str(hatchery_slots[index].get("phase", "idle")) if open_plot else "idle")
		if not open_plot:
			_text(plot, "An empty garden awaiting its new caretakers", Rect2(25, 155, 496, 28), 14, Color("d8e2d1"), HORIZONTAL_ALIGNMENT_CENTER)
			if index == hatchery_unlocked:
				var price: int = HATCHERY_UNLOCK_COST[index]
				var unlock_btn := _button(plot, "UNLOCK FARM PLOT • %d GOLD" % price, Rect2(85, 194, 385, 43), "gold")
				unlock_btn.disabled = gold < price
				unlock_btn.pressed.connect(_hatchery_unlock.bind(index))
			else:
				_text(plot, "Unlock the previous plot first", Rect2(70, 195, 410, 35), 14, Color("bbc4b4"), HORIZONTAL_ALIGNMENT_CENTER)
			continue
		var record: Dictionary = hatchery_slots[index]
		var parents: Array = record["parents"]
		for pindex in range(2):
			var parent_data: Dictionary = parents[pindex]
			var id: String = str(parent_data.get("id", "koikoi"))
			var form: String = str(parent_data.get("form", "normal"))
			if CREATURES.has(id):
				var sprite := _portrait_form(bed, id, Rect2(43 if pindex == 0 else 395, 10, 85, 87), form)
				if pindex == 1:
					sprite.pivot_offset = sprite.size * 0.5
					sprite.scale.x = -1.0
			var selector := OptionButton.new()
			selector.position = Vector2(15 + pindex * 265, 153)
			selector.size = Vector2(253, 35)
			selector.disabled = str(record["phase"]) != "idle"
			var choice_index := 0
			for c in range(options.size()):
				var option: Dictionary = options[c]
				selector.add_item("%s • %s" % [str(CREATURES[str(option["id"])]["name"]), str(option["form"]).to_upper()])
				if id == str(option["id"]) and form == str(option["form"]):
					choice_index = c
			selector.select(choice_index)
			plot.add_child(selector)
			selector.item_selected.connect(_hatchery_select_parent.bind(index, pindex, options))
		var phase: String = str(record["phase"])
		var status: String = "Ready for pairing"
		if phase == "breeding":
			status = "BREEDING  %s / 01:00" % _hatchery_timer(float(record["remaining"]))
		elif phase == "egg":
			status = "INCUBATING  %s / 09:00" % _hatchery_timer(float(record["remaining"]))
		elif phase == "ready":
			status = "EGG HATCHED! REVEAL YOUR OFFSPRING"
		hatchery_status_labels[index] = _text(plot, status, Rect2(16, 196, 307, 40), 14, Color("e8f9e0"))
		var label: String = "BREED" if phase == "idle" else "CLAIM EGG" if phase == "ready" else "IN PROGRESS"
		var act := _button(plot, label, Rect2(331, 196, 202, 42), "gold" if phase == "ready" else "green")
		act.disabled = phase not in ["idle", "ready"]
		act.pressed.connect(_hatchery_claim.bind(index) if phase == "ready" else _hatchery_begin.bind(index))

func _dev_choose_egg_form(index: int) -> void:
	dev_hatch_form = str(HATCHERY_FORMS[index])

func _dev_fill_eggs() -> void:
	_dev_run_command("eggs " + dev_hatch_form)

func _dev_inject_eggs(form: String) -> String:
	var injected := 0
	for i in range(hatchery_unlocked):
		var slot: Dictionary = hatchery_slots[i]
		var good: bool = true
		for p in slot["parents"]:
			if not _breed_parent_valid(p):
				good = false
		if not good:
			continue
		var child: Dictionary = _roll_offspring(slot, form)
		slot["child_id"] = child["id"]
		slot["child_form"] = child["form"]
		slot["phase"] = "egg"
		slot["remaining"] = 2.0
		hatchery_slots[i] = slot
		injected += 1
	_save_collection()
	return "Filled %d open plots with %s eggs (hatch in 2s)." % [injected, form.to_upper()]

func _process(delta: float) -> void:
	if reset_reload_pending:
		return
	if not ghost_reveal_pending.is_empty() and state == "MENU" and menu_page == "run_result" and not is_instance_valid(ghost_reveal_overlay):
		ghost_reveal_delay -= delta
		if ghost_reveal_delay <= 0.0:
			_start_ghost_reveal()
	# Hatchery keeps wall-clock time, but wild-capture cut-ins freeze the run,
	# wave timer, enemy attacks, pickups and extraction countdown completely.
	_hatchery_advance()
	if is_instance_valid(variant_reveal_overlay) or is_instance_valid(gold_reveal_overlay):
		queue_redraw()
		return
	if is_instance_valid(dev_console_overlay):
		player_camera.position = player
		queue_redraw()
		return
	if state == "PLAY":
		_update_run(delta)
	elif is_spinning and not is_instance_valid(gold_reveal_overlay):
		spin_timer -= delta
		spin_preview_clock -= delta
		if spin_preview_clock <= 0.0:
			spin_preview_clock = 0.065
			_update_slot_reels()
		if spin_timer <= 0.0:
			_finish_spin()
	if state in ["PLAY", "UPGRADE"]:
		_update_run_hud(delta)
	player_camera.position = player
	queue_redraw()
	# Start pending rewards after the current physics/gameplay update is over.
	# This avoids interrupting an enemy loop or a batch of slot results halfway.
	_show_next_variant_reveal()

func _signature_for(creature_id: String) -> Dictionary:
	return CREATURE_SIGNATURES.get(creature_id, {"name": "Wild Shot", "style": "basic", "bonus": {}, "desc": "A simple reliable attack."})

func _signature_name(creature_id: String) -> String:
	return str(_signature_for(creature_id).get("name", "Wild Shot"))

func _signature_desc(creature_id: String) -> String:
	return str(_signature_for(creature_id).get("desc", "A simple reliable attack."))

func _apply_signature_starting_bonuses() -> void:
	var signature: Dictionary = _signature_for(selected_creature)
	var bonus: Dictionary = signature.get("bonus", {})
	for key in bonus.keys():
		var rank_key: String = str(key)
		move_ranks[rank_key] = max(_rank(rank_key), int(bonus[key]))
	if _rank("vitality") > 0:
		max_hp += 25.0 * float(_rank("vitality"))
		hp = max_hp

func _spawn_player_shot(position: Vector2, velocity: Vector2, damage: float, life: float, radius: float, outer: Color, inner: Color, pierce: int = 0, aoe: float = 0.0) -> void:
	var reach_bonus: float = float(_perm_rank("reach"))
	shots.append({"p": position, "v": velocity, "life": life * (1.0 + 0.04 * reach_bonus), "damage": damage, "radius": radius * (1.0 + 0.05 * reach_bonus), "outer": outer, "inner": inner, "pierce": pierce, "aoe": aoe, "hit_ids": []})

func _fire_player_attack(direction: Vector2) -> void:
	var signature: Dictionary = _signature_for(selected_creature)
	var style: String = str(signature.get("style", "basic"))
	var base_damage := (33.0 + _rank("power") * 11.0) * (1.0 + 0.04 * float(_perm_rank("phys_atk")))
	var base_pos := player + Vector2(0, -25)
	var extra := _rank("multishot")
	match style:
		"double":
			var side := direction.orthogonal().normalized()
			for n in range(2 + min(extra, 2)):
				var offset_index := float(n) - float(1 + min(extra, 2)) * 0.5
				_spawn_player_shot(base_pos + side * offset_index * 12.0, direction * 500.0, base_damage * 0.82, 1.2, 7.0, Color("ffd36f"), Color.WHITE)
			attack_clock = 0.57 * pow(0.87, _rank("rapid"))
		"pierce":
			for n in range(1 + min(extra, 1)):
				var angle := (float(n) - float(min(extra, 1)) * 0.5) * 0.08
				_spawn_player_shot(base_pos, direction.rotated(angle) * 530.0, base_damage * 1.05, 1.55, 8.5, Color("8de7ff"), Color.WHITE, 2)
			attack_clock = 0.63 * pow(0.87, _rank("rapid"))
		"wave":
			for n in range(2 + extra):
				var angle := (float(n) - float(1 + extra) * 0.5) * 0.18
				_spawn_player_shot(base_pos, direction.rotated(angle) * 365.0, base_damage * 0.72, 1.55, 10.0, Color("6ad8ff"), Color("f3ffff"), 1)
			attack_clock = 0.78 * pow(0.87, _rank("rapid"))
		"blast":
			_spawn_player_shot(base_pos, direction * 440.0, base_damage * 1.55, 1.15, 10.5, Color("ff715b"), Color("ffe59d"), 0, 28.0)
			for n in range(extra):
				var angle := (float(n) - float(max(extra - 1, 0)) * 0.5) * 0.16
				_spawn_player_shot(base_pos, direction.rotated(angle) * 450.0, base_damage * 0.55, 0.9, 6.0, Color("ff715b"), Color.WHITE)
			attack_clock = 0.72 * pow(0.87, _rank("rapid"))
		"seed":
			_spawn_player_shot(base_pos, direction * 330.0, base_damage * 1.15, 1.65, 10.5, Color("89c85b"), Color("fff7b0"), 0, 32.0)
			for n in range(extra):
				var angle := (float(n) - float(max(extra - 1, 0)) * 0.5) * 0.14
				_spawn_player_shot(base_pos, direction.rotated(angle) * 340.0, base_damage * 0.52, 1.2, 6.5, Color("89c85b"), Color("eefbd4"))
			attack_clock = 0.74 * pow(0.87, _rank("rapid"))
		"shell":
			for n in range(4 + extra):
				var angle := (float(n) - float(3 + extra) * 0.5) * 0.16
				_spawn_player_shot(base_pos, direction.rotated(angle) * 470.0, base_damage * 0.48, 0.68, 5.0, Color("b8ebff"), Color.WHITE)
			attack_clock = 0.71 * pow(0.87, _rank("rapid"))
		"bubble":
			for n in range(1 + int(max(1, extra) / 2)):
				var angle := (float(n) - float(int(max(1, extra) / 2)) * 0.5) * 0.13
				_spawn_player_shot(base_pos, direction.rotated(angle) * 305.0, base_damage * 1.02, 1.55, 11.0, Color("7fe9ff"), Color("ffffff"), 0, 20.0)
			attack_clock = 0.69 * pow(0.87, _rank("rapid"))
		"shadow":
			for n in range(2 + extra):
				var angle := (float(n) - float(1 + extra) * 0.5) * 0.16
				_spawn_player_shot(base_pos, direction.rotated(angle) * 470.0, base_damage * 0.76, 1.35, 7.0, Color("9b67ff"), Color("f0d8ff"), 1)
			attack_clock = 0.61 * pow(0.87, _rank("rapid"))
		"feather":
			for n in range(2 + extra):
				var angle := (float(n) - float(1 + extra) * 0.5) * 0.11
				_spawn_player_shot(base_pos, direction.rotated(angle) * 560.0, base_damage * 0.72, 1.25, 6.2, Color("fff0aa"), Color.WHITE)
			attack_clock = 0.52 * pow(0.87, _rank("rapid"))
		"prism":
			for n in range(3 + extra):
				var angle := (float(n) - float(2 + extra) * 0.5) * 0.14
				_spawn_player_shot(base_pos, direction.rotated(angle) * 490.0, base_damage * 0.64, 1.2, 6.5, Color("9fd6ff"), Color("ecfffc"))
			attack_clock = 0.58 * pow(0.87, _rank("rapid"))
		_:
			var shot_count := 1 + extra
			for n in range(shot_count):
				var angle := (float(n) - float(shot_count - 1) * 0.5) * 0.20
				_spawn_player_shot(base_pos, direction.rotated(angle) * 510.0, base_damage, 1.25, 7.0, Color("f8dd89"), Color.WHITE)
			attack_clock = 0.55 * pow(0.87, _rank("rapid"))

# Trail percentages scale from the creature's current ATTACK, never enemy HP.
func _creature_attack_power() -> float:
	return (33.0 + 11.0 * float(_rank("power"))) * (1.0 + 0.04 * float(_perm_rank("phys_atk")))

func _trail_damage_fraction(stage: int) -> float:
	match stage:
		1: return 0.0075
		2: return 0.01
		3, 4: return 0.015
		5: return 0.02
	return 0.0

func _update_footprints(delta: float, old_position: Vector2) -> void:
	# Age and remove every print after two seconds; keep a hard rendering cap.
	for j in range(footprints.size() - 1, -1, -1):
		footprints[j]["time"] = float(footprints[j]["time"]) - delta
		if float(footprints[j]["time"]) <= 0.0:
			footprints.remove_at(j)
	var equipped := _equipped_trail()
	if equipped == 0:
		return
	trail_clock += delta
	if player.distance_to(last_trail_position) >= TRAIL_STEP_DISTANCE and trail_clock >= TRAIL_INTERVAL:
		trail_clock = 0.0
		footstep_alternate = not footstep_alternate
		var moving: Vector2 = (player - old_position).normalized()
		if moving.length_squared() < 0.01:
			moving = last_move
		last_trail_position = player
		footprints.append({"p": player - moving * 11.0, "facing": moving,
			"time": TRAIL_LIFETIME, "stage": equipped, "left": footstep_alternate,
			"hit_ids": []})
		if footprints.size() > 60:
			footprints.pop_front()

func _enemy_is_boss(enemy: Dictionary) -> bool:
	return bool(enemy.get("boss", false)) or bool(enemy.get("is_boss", false)) or str(enemy.get("kind", enemy.get("type", ""))) == "boss"

func _update_trail_effects(delta: float) -> void:
	if _coop_client():
		return # Host alone applies enemy trail / damage-over-time effects.
	for i in range(enemies.size() - 1, -1, -1):
		var foe: Dictionary = enemies[i]
		var uid: int = int(foe.get("uid", -1))
		var boss_factor := 0.5 if _enemy_is_boss(foe) else 1.0
		# Slow is refreshed while touching a trail and fades soon after leaving it.
		foe["trail_slow_left"] = maxf(0.0, float(foe.get("trail_slow_left", 0.0)) - delta)
		foe["trail_touch_at"] = float(foe.get("trail_touch_at", -1.0))
		for type_name in ["burn", "poison"]:
			var remaining_key := "%s_left" % type_name
			var tick_key := "%s_tick" % type_name
			var damage_key := "%s_damage" % type_name
			var previous: float = float(foe.get(remaining_key, 0.0))
			if previous <= 0.0:
				continue
			foe[remaining_key] = maxf(0.0, previous - delta)
			foe[tick_key] = float(foe.get(tick_key, TRAIL_DOT_INTERVAL)) - delta
			if float(foe[tick_key]) <= 0.0:
				foe[tick_key] = TRAIL_DOT_INTERVAL
				var dot_damage := float(foe.get(damage_key, 0.0))
				if dot_damage > 0.0:
					_damage_enemy(i, dot_damage)
					if i >= enemies.size() or int(enemies[i].get("uid", -1)) != uid:
						break
		if i >= enemies.size() or int(enemies[i].get("uid", -1)) != uid:
			continue
		if time_alive < float(foe["trail_touch_at"]):
			continue
		var active_trails: Array = online_lobby.team_footprints() if _coop_host() else footprints
		for step in active_trails:
			var hit_ids: Array = step["hit_ids"]
			if hit_ids.has(uid):
				continue
			if Vector2(foe["p"]).distance_squared_to(Vector2(step["p"])) > TRAIL_RADIUS * TRAIL_RADIUS:
				continue
			hit_ids.append(uid)
			step["hit_ids"] = hit_ids
			var stage: int = int(step["stage"])
			foe["trail_touch_at"] = time_alive + TRAIL_HIT_COOLDOWN
			if stage == 3 or stage == 5:
				foe["trail_slow_left"] = maxf(float(foe.get("trail_slow_left", 0.0)), 0.65)
			# Burn and poison tick every 1.5 sec while their 3.1 sec status lasts.
			if stage == 2 or stage == 4:
				var status := "burn" if stage == 2 else "poison"
				if float(foe.get("%s_left" % status, 0.0)) <= 0.0:
					foe["%s_tick" % status] = TRAIL_DOT_INTERVAL
				foe["%s_left" % status] = TRAIL_STATUS_DURATION
				foe["%s_damage" % status] = float(step.get("power", _creature_attack_power())) * 0.0025 * boss_factor
			_damage_enemy(i, float(step.get("power", _creature_attack_power())) * _trail_damage_fraction(stage) * boss_factor)
			break

# Visible pixel-art pair of foot-shaped marks; no external assets needed.
func _draw_footprints() -> void:
	_draw_footprint_marks(footprints)

func _draw_footprint_marks(marks: Array) -> void:
	for mark in marks:
		var life: float = clampf(float(mark["time"]) / TRAIL_LIFETIME, 0.0, 1.0)
		var stage: int = int(mark["stage"])
		var base := Color("65db68")
		match stage:
			2: base = Color("ff9538")
			3: base = Color("8adffc")
			4: base = Color("b76af7")
			5: base = Color.from_hsv(fposmod(time_alive * 0.52 + Vector2(mark["p"]).x * 0.001, 1.0), 0.82, 1.0)
		var facing: Vector2 = Vector2(mark["facing"])
		var across := facing.orthogonal() * (7.0 if bool(mark["left"]) else -7.0)
		var pos: Vector2 = Vector2(mark["p"]) + across
		var core := Color(base.r, base.g, base.b, 0.62 * life)
		draw_circle(pos, 11.0, Color(base.r, base.g, base.b, 0.13 * life))
		draw_set_transform(pos, facing.angle() + PI * 0.5, Vector2(0.78, 1.16))
		draw_circle(Vector2.ZERO, 6.8, core)
		draw_circle(Vector2(-5.5, -7.3), 2.8, core)
		draw_circle(Vector2(-1.1, -9.1), 2.9, core)
		draw_circle(Vector2(3.7, -8.6), 2.5, core)
		draw_set_transform(Vector2.ZERO)
		match stage:
			1:
				# Slimy footprint with little green droplets.
				draw_circle(pos + Vector2(7, 7), 2.8, Color(0.65, 1.0, 0.42, 0.48 * life))
				draw_circle(pos - Vector2(8, 1), 1.9, Color(0.5, 0.9, 0.46, 0.4 * life))
			2:
				# Flame tongues flicker behind the foot.
				var tail := pos - facing * 12.0
				draw_colored_polygon(PackedVector2Array([tail + facing.orthogonal() * 6.0, tail - facing * 11.0, tail - facing.orthogonal() * 6.0]), Color(1.0, 0.35, 0.1, 0.48 * life))
				draw_circle(pos - facing * 7.0, 3.5, Color(1.0, 0.88, 0.30, 0.62 * life))
			3:
				# Ice crystals sparkle in a small snowflake pattern.
				for a in range(3):
					var ray: Vector2 = Vector2.RIGHT.rotated(float(a) * PI / 3.0) * 8.0
					draw_line(pos - ray, pos + ray, Color(0.86, 1.0, 1.0, 0.7 * life), 1.6)
			4:
				# Poison bubbles rise and vanish with the print.
				for j in range(3):
					draw_circle(pos + Vector2(6.0 + float(j) * 3.0, -9.0 - float(j) * 5.0), 3.0 - float(j) * 0.55, Color(0.75, 0.41, 1.0, 0.52 * life))
			5:
				# RGB toes cycle through three separate rainbow hues.
				for j in range(3):
					var hue := fposmod(time_alive * 0.6 + float(j) / 3.0, 1.0)
					var rainbow: Color = Color.from_hsv(hue, 0.95, 1.0, 0.8 * life)
					draw_circle(pos + Vector2(float(j - 1) * 5.0, -8.0), 3.0, rainbow)

func _coop_client() -> bool:
	return is_instance_valid(online_lobby) and online_lobby.coop_active and multiplayer.has_multiplayer_peer() and not multiplayer.is_server()

func _coop_host() -> bool:
	return is_instance_valid(online_lobby) and online_lobby.coop_active and multiplayer.has_multiplayer_peer() and multiplayer.is_server()

func _update_run(delta: float) -> void:
	var spectator_host: bool = _coop_host() and (online_lobby.local_extracted or online_lobby.dedicated_room)
	if spectator_host:
		player = online_lobby.remaining_player_position()
	time_alive += delta
	event_timer = maxf(0.0, event_timer - delta)
	if not spectator_host and time_alive >= EXTRACTION_UNLOCK_SECONDS and player.distance_to(EXTRACTION_POINT) < EXTRACTION_RADIUS and Input.is_key_pressed(KEY_E):
		if is_instance_valid(online_lobby) and online_lobby.coop_active:
			online_lobby.request_extraction()
		else:
			_extract_run()
		return
	var previous_wave := wave
	wave = 1 + int(time_alive / WAVE_SECONDS)
	if wave > previous_wave and event_timer < 1.0:
		event_message = "WAVE %d • DANGER RISING! Watch the red and purple attack markers." % wave
		event_timer = 3.0
	for id in ["heal", "shield", "dash", "nova"]:
		match id:
			"heal": heal_cooldown = maxf(0.0, heal_cooldown - delta)
			"shield": shield_cooldown = maxf(0.0, shield_cooldown - delta)
			"dash": dash_cooldown = maxf(0.0, dash_cooldown - delta)
			"nova": nova_cooldown = maxf(0.0, nova_cooldown - delta)
	shield_time = maxf(0.0, shield_time - delta)
	if shield_time <= 0.0:
		shield_hp = 0.0
	dash_invulnerability = maxf(0.0, dash_invulnerability - delta)
	nova_flash_time = maxf(0.0, nova_flash_time - delta)
	projectile_grace = maxf(0.0, projectile_grace - delta)
	for fx_index in range(impact_effects.size() - 1, -1, -1):
		impact_effects[fx_index]["remaining"] = float(impact_effects[fx_index]["remaining"]) - delta
		if float(impact_effects[fx_index]["remaining"]) <= 0.0:
			impact_effects.remove_at(fx_index)
	for number_index in range(floating_damage_numbers.size() - 1, -1, -1):
		floating_damage_numbers[number_index]["remaining"] = float(floating_damage_numbers[number_index]["remaining"]) - delta
		if float(floating_damage_numbers[number_index]["remaining"]) <= 0.0:
				floating_damage_numbers.remove_at(number_index)
	if not spectator_host:
		var old_player_position := player
		var move := Input.get_vector("ui_left", "ui_right", "ui_up", "ui_down")
		if Input.is_key_pressed(KEY_A): move.x -= 1.0
		if Input.is_key_pressed(KEY_D): move.x += 1.0
		if Input.is_key_pressed(KEY_W): move.y -= 1.0
		if Input.is_key_pressed(KEY_S): move.y += 1.0
		move = move.normalized()
		if move.length_squared() > 0.05:
			last_move = move
		if absf(move.x) >= 0.12:
			player_facing_left = move.x < 0.0
		if Input.is_key_pressed(KEY_Q): _cast_heal()
		if Input.is_key_pressed(KEY_R): _cast_shield()
		if Input.is_key_pressed(KEY_F): _cast_nova()
		if Input.is_key_pressed(KEY_SPACE) and dash_cooldown <= 0.0: _cast_dash(move)
		if dash_time > 0.0:
			player = _move_player_around_trees(player, dash_direction * (575.0 + 48.0 * _rank("dash")) * delta)
			dash_time = maxf(0.0, dash_time - delta)
		else:
			player = _move_player_around_trees(player, move * (230.0 * (1.0 + 0.025 * float(_perm_rank("stride")))) * delta)
		if hp > 0.0 and _perm_rank("regrowth") > 0:
			hp = minf(max_hp, hp + float(_perm_rank("regrowth")) * 0.2 * delta)
		player = player.clamp(Vector2(35, 35), WORLD - Vector2(35, 35))
		# Only the visible creature is mirrored, not collision, attacks or UI.
		var movement: Vector2 = player - old_player_position
		player_is_moving = movement.length_squared() > 0.05
		if dash_time > 0.0 and absf(movement.x) > 0.12:
			player_facing_left = movement.x < 0.0
		run_pose_strength = move_toward(run_pose_strength, 1.0 if player_is_moving else 0.0, delta * 8.0)
		if player_is_moving:
			run_stride_phase += delta * (19.0 if dash_time > 0.0 else 12.0)
		_update_footprints(delta, old_player_position)
	_update_trail_effects(delta)
	if not _coop_client():
		spawn_clock += delta
	if not _coop_client() and spawn_clock >= maxf(0.39, 1.85 - float(wave - 1) * 0.13) and enemies.size() < 65:
		spawn_clock = 0.0
		_spawn_enemy()
	attack_clock -= delta
	if not spectator_host and attack_clock <= 0.0 and not enemies.is_empty():
		var target_index := 0
		var best_dist := INF
		for i in range(enemies.size()):
			var distance: float = player.distance_squared_to(Vector2(enemies[i]["p"]))
			if distance < best_dist:
				best_dist = distance
				target_index = i
		if best_dist < 460.0 * 460.0:
			var direction: Vector2 = (Vector2(enemies[target_index]["p"]) - player).normalized()
			_fire_player_attack(direction)

	if not _coop_client():
		_update_host_enemies(delta)
	else:
		# Each player takes contact damage from the same replicated enemies.
		for foe in enemies:
			if Vector2(foe["p"]).distance_to(player) < 29.0:
				_apply_player_damage(float(foe.get("contact_dps", 18.0)) * delta)
	for j in range(shots.size() - 1, -1, -1):
		var shot: Dictionary = shots[j]
		shot["p"] = Vector2(shot["p"]) + Vector2(shot["v"]) * delta
		shot["life"] = float(shot["life"]) - delta
		var removed := false
		var already_hit: Array = shot.get("hit_ids", [])
		for i in range(enemies.size() - 1, -1, -1):
			var uid: int = int(enemies[i].get("uid", -1))
			if already_hit.has(uid):
				continue
			var hit_radius := 28.0 + float(shot.get("radius", 7.0))
			if Vector2(shot["p"]).distance_to(Vector2(enemies[i]["p"]) + Vector2(0, -22)) < hit_radius:
				already_hit.append(uid)
				var struck_pos: Vector2 = enemies[i]["p"]
				if _coop_client():
					online_lobby.request_hit(uid, float(shot.get("damage", 33.0)))
				else:
					_damage_enemy(i, float(shot.get("damage", 33.0)))
				var splash := float(shot.get("aoe", 0.0))
				if splash > 0.0:
					for k in range(enemies.size() - 1, -1, -1):
						if int(enemies[k].get("uid", -1)) != uid and Vector2(enemies[k]["p"]).distance_to(struck_pos) <= splash:
							if _coop_client():
								online_lobby.request_hit(int(enemies[k].get("uid", -1)), float(shot.get("damage", 33.0)) * 0.55)
							else:
								_damage_enemy(k, float(shot.get("damage", 33.0)) * 0.55)
				var pierce := int(shot.get("pierce", 0))
				if pierce > 0:
					shot["pierce"] = pierce - 1
				else:
					removed = true
				break
		shot["hit_ids"] = already_hit
		if removed or float(shot["life"]) <= 0.0:
			shots.remove_at(j)
		else:
			shots[j] = shot

	for i in range(enemy_bullets.size() - 1, -1, -1):
		var bullet: Dictionary = enemy_bullets[i]
		bullet["p"] = Vector2(bullet["p"]) + Vector2(bullet["v"]) * delta
		bullet["life"] = float(bullet["life"]) - delta
		if Vector2(bullet["p"]).distance_to(player + Vector2(0, -21)) < float(bullet.get("radius", 7.0)) + 15.0:
			_apply_player_damage(float(bullet.get("damage", 13.0)), true, true)
			enemy_bullets.remove_at(i)
		elif float(bullet["life"]) <= 0.0:
			enemy_bullets.remove_at(i)
		else:
			enemy_bullets[i] = bullet

	# In co-op only the host removes world loot. Clients display the host's
	# authoritative drops and receive an individual award after host validation.
	if _coop_client():
		if hp <= 0.0:
			_end_run(true)
			return
		if xp >= _xp_needed():
			xp -= _xp_needed()
			level += 1
			_offer_upgrades()
		return
	if spectator_host:
		return  # Keep the dungeon alive, but never collect or level the extracted host.
	var collect_radius: float = _pickup_radius()
	for i in range(chip_drops.size() - 1, -1, -1):
		if player.distance_to(Vector2(chip_drops[i]["p"])) < collect_radius:
			chip_drops.remove_at(i)
			if _coop_host(): online_lobby.award_team_loot("chip", 1)
			else: pending_chips += 1
	for i in range(gold_drops.size() - 1, -1, -1):
		if player.distance_to(Vector2(gold_drops[i]["p"])) < collect_radius:
			if _coop_host(): online_lobby.award_team_loot("gold", int(gold_drops[i]["amount"]))
			else: _collect_run_gold(int(gold_drops[i]["amount"]))
			gold_drops.remove_at(i)
	for i in range(xp_drops.size() - 1, -1, -1):
		if player.distance_to(Vector2(xp_drops[i]["p"])) < collect_radius:
			var earned_amount: int = int(xp_drops[i]["amount"])
			if _coop_host():
				online_lobby.award_team_xp(earned_amount)
			else:
				_apply_earned_xp(earned_amount)
			xp_drops.remove_at(i)
	for i in range(material_drops.size() - 1, -1, -1):
		var pickup: Dictionary = material_drops[i]
		if player.distance_to(Vector2(pickup["p"])) < collect_radius:
			var material_id: String = str(pickup["id"])
			if _coop_host(): online_lobby.award_team_loot("material", 1, material_id)
			else: carried_materials[material_id] = int(carried_materials.get(material_id, 0)) + 1
			material_drops.remove_at(i)
	if hp <= 0.0:
		_end_run(true)
		return
	if xp >= _xp_needed():
		xp -= _xp_needed()
		level += 1
		_offer_upgrades()

func _update_host_enemies(delta: float) -> void:
	# Warnings have a visible cap so a crowded room is difficult, not unreadable.
	var active_warnings := 0
	for candidate in enemies:
		if float(candidate.get("warning_timer", 0.0)) > 0.0:
			active_warnings += 1
	for i in range(enemies.size() - 1, -1, -1):
		var enemy: Dictionary = enemies[i]
		var pos: Vector2 = enemy["p"]
		var previous_position := pos
		var charging := float(enemy.get("charge_timer", 0.0)) > 0.0
		var warning := float(enemy.get("warning_timer", 0.0)) > 0.0
		if charging:
			# Charging enemies travel along their warned straight line, never home in.
			var charge_step := minf(delta, float(enemy["charge_timer"]))
			pos += Vector2(enemy["attack_dir"]) * float(enemy["charge_speed"]) * charge_step
			enemy["charge_timer"] = maxf(0.0, float(enemy["charge_timer"]) - delta)
			enemy["p"] = pos.clamp(Vector2(175, 255), WORLD - Vector2(175, 175))
			if not bool(enemy.get("charge_hit", false)) and player.distance_to(Vector2(enemy["p"])) < 35.0:
				_apply_player_damage(float(enemy["attack_damage"]), true)
				enemy["charge_hit"] = true
		elif warning:
			# Windup freezes the attacker's position, keeping the indicator accurate.
			enemy["warning_timer"] = maxf(0.0, float(enemy["warning_timer"]) - delta)
			if float(enemy["warning_timer"]) <= 0.0:
				_resolve_enemy_attack(enemy)
		else:
			var target_pos: Vector2 = online_lobby.closest_target(pos) if _coop_host() else player
			var heading: Vector2 = (target_pos - pos).normalized()
			var slow_amount := 0.25 * (0.5 if _enemy_is_boss(enemy) else 1.0) if float(enemy.get("trail_slow_left", 0.0)) > 0.0 else 0.0
			pos += heading * float(enemy.get("speed", 60.0)) * (1.0 - slow_amount) * delta
			enemy["p"] = pos.clamp(Vector2(175, 255), WORLD - Vector2(175, 175))
			if Vector2(enemy["p"]).distance_to(player) < 29.0:
				_apply_player_damage(float(enemy.get("contact_dps", 18.0)) * delta)
			if int(enemy.get("ranged", 0)) == 1:
				enemy["fire_clock"] = float(enemy.get("fire_clock", 2.0)) - delta
				var distance := player.distance_to(Vector2(enemy["p"]))
				if float(enemy["fire_clock"]) <= 0.0 and distance < 600.0 and distance > 75.0 and active_warnings < MAX_ATTACK_WARNINGS and enemy_bullets.size() < MAX_ENEMY_PROJECTILES - 8:
					_begin_enemy_warning(enemy)
					active_warnings += 1
		_update_enemy_walking(enemy, previous_position, delta, charging)
		enemies[i] = enemy


func _apply_player_damage(damage: float, discrete_hit: bool = false, special: bool = false) -> void:
	if _coop_host() and (online_lobby.local_extracted or online_lobby.dedicated_room):
		return
	var defense_id: String = "sp_def" if special else "phys_def"
	damage *= 1.0 - 0.04 * float(_perm_rank(defense_id))
	if discrete_hit and projectile_grace > 0.0:
		return
	if dash_invulnerability > 0.0:
		return
	# Ghost forms have a permanent, independent 5% chance to avoid each hit.
	# Evaded damage does not drain the shield, HP, or grant projectile grace.
	if damage > 0.0 and _has_trait(selected_variant, "ghost") and rng.randf() < GHOST_EVASION_CHANCE:
		_show_combat_number(player + Vector2(0, -63), "EVADE!", Color("89eaff"))
		return
	if shield_hp > 0.0:
		var absorbed := minf(damage, shield_hp)
		shield_hp -= absorbed
		damage -= absorbed
	var actual_hp_damage := minf(hp, maxf(0.0, damage))
	run_damage_taken += actual_hp_damage
	hp = maxf(0.0, hp - damage)
	if discrete_hit:
		projectile_grace = 0.38

func _show_combat_number(position: Vector2, label: String, tint: Color = Color("fff0b3")) -> void:
	if floating_damage_numbers.size() >= DAMAGE_NUMBER_LIMIT:
		floating_damage_numbers.remove_at(0)
	floating_damage_numbers.append({"p": position + Vector2(rng.randf_range(-10.0, 10.0), 0.0),
		"text": label, "tint": tint, "remaining": DAMAGE_NUMBER_LIFETIME})

func _damage_enemy(index: int, damage: float) -> void:
	if _coop_client():
		return
	if index < 0 or index >= enemies.size():
		return
	var enemy: Dictionary = enemies[index]
	var actual_damage: float = minf(maxf(0.0, damage), maxf(0.0, float(enemy.get("hp", 30.0))))
	if actual_damage > 0.0:
		run_damage_dealt += actual_damage
		var value: String = "%.2f" % actual_damage if actual_damage < 1.0 else "%.1f" % actual_damage if actual_damage < 10.0 else str(int(roundf(actual_damage)))
		_show_combat_number(Vector2(enemy["p"]) + Vector2(0, -86), "-" + value)
	enemy["hp"] = float(enemy.get("hp", 30.0)) - damage
	if float(enemy["hp"]) > 0.0:
		enemies[index] = enemy
		return
	var defeated_at: Vector2 = Vector2(enemy["p"])
	var variant_kind: String = str(enemy.get("variant", "normal"))
	if variant_kind != "normal":
		var variant_key := "%s|%s" % [str(enemy["id"]), variant_kind]
		var first_capture: bool = not bool(variant_collection.get(variant_key, false)) and not bool(pending_variants.get(variant_key, false))
		pending_variants[variant_key] = true
		_queue_variant_reveal(str(enemy["id"]), variant_kind, first_capture, "wild")
		event_message = "%s %s collected! Extract to keep it." % [variant_kind.capitalize(), str(CREATURES[str(enemy["id"])]["name"])]
		event_timer = 5.0
	enemies.remove_at(index)
	if _coop_host():
		online_lobby.announce_enemy_defeat(int(enemy.get("uid", -1)), str(enemy["id"]), variant_kind, defeated_at)
	kills += 1
	# Materials drop as collectable world pickups rather than appearing for free.
	if rng.randf() < MATERIAL_DROP_CHANCE and material_drops.size() < 110:
		var loot_roll := rng.randf()
		var material_id: String = "grove_fiber" if loot_roll < 0.56 else ("crystal_shards" if loot_roll < 0.86 else "ember_fragments")
		material_drops.append({"p": defeated_at + Vector2(rng.randf_range(-13.0, 13.0), rng.randf_range(-11.0, 11.0)),
			"id": material_id, "phase": rng.randf_range(0.0, TAU)})
	var xp_amount: int = 3 if variant_kind != "normal" else 2
	if xp_drops.size() < 360:
		xp_drops.append({"p": defeated_at + Vector2(rng.randf_range(-11.0, 11.0), rng.randf_range(-8.0, 8.0)), "amount": xp_amount, "phase": rng.randf_range(0.0, TAU)})
	else:
		# Preserve XP if many gems have piled up: add to a nearby gem.
		var nearest: int = 0
		var nearest_distance: float = INF
		for orb_index in range(xp_drops.size()):
			var distance: float = Vector2(xp_drops[orb_index]["p"]).distance_squared_to(defeated_at)
			if distance < nearest_distance:
				nearest_distance = distance
				nearest = orb_index
		xp_drops[nearest]["amount"] = int(xp_drops[nearest]["amount"]) + xp_amount
	if rng.randf() < CHIP_DROP_CHANCE:
		chip_drops.append({"p": defeated_at, "phase": rng.randf_range(0.0, TAU)})
	if rng.randf() < 0.12 and gold_drops.size() < 90:
		gold_drops.append({"p": defeated_at + Vector2(10, -4), "phase": rng.randf_range(0.0, TAU), "amount": rng.randi_range(2, 5)})

func _coop_receive_defeat(uid: int, creature: String, variant: String, where: Vector2) -> void:
	if not _coop_client():
		return
	for i in range(enemies.size() - 1, -1, -1):
		if int(enemies[i].get("uid", -1)) == uid:
			enemies.remove_at(i)
			break
	kills += 1
	if variant != "normal" and CREATURES.has(creature):
		var key := "%s|%s" % [creature, variant]
		var first := not bool(variant_collection.get(key, false)) and not bool(pending_variants.get(key, false))
		pending_variants[key] = true
		_queue_variant_reveal(creature, variant, first, "wild")
		_show_combat_number(where + Vector2(0, -85), variant.to_upper() + " FOUND", Color("f9d574"))

func _cast_heal() -> void:
	if _rank("heal") == 0 or heal_cooldown > 0.0 or hp >= max_hp:
		return
	hp = minf(max_hp, hp + 26.0 + 13.0 * float(_rank("heal") - 1))
	heal_cooldown = maxf(9.0, 23.0 - 2.5 * _rank("heal")) * _cooldown_factor()
	event_message = "LIFE BLOOM!"
	event_timer = 1.1

func _cast_shield() -> void:
	if _rank("shield") == 0 or shield_cooldown > 0.0:
		return
	shield_hp = 36.0 + 21.0 * _rank("shield")
	shield_time = 4.0 + 0.8 * _rank("shield")
	shield_cooldown = maxf(12.0, 28.0 - 2.0 * _rank("shield")) * _cooldown_factor()
	event_message = "AEGIS WARD!"
	event_timer = 1.1

func _cast_dash(move: Vector2) -> void:
	if _rank("dash") == 0:
		return
	dash_direction = move if move.length_squared() > 0.05 else last_move
	dash_time = 0.18 + float(_rank("dash")) * 0.035
	dash_invulnerability = dash_time + 0.13
	dash_cooldown = maxf(1.15, 4.4 - 0.55 * _rank("dash")) * _cooldown_factor()

func _cast_nova() -> void:
	if _rank("nova") == 0 or nova_cooldown > 0.0:
		return
	var radius := 145.0 + 42.0 * _rank("nova")
	var power := (48.0 + 36.0 * _rank("nova") + 7.0 * _rank("power")) * (1.0 + 0.04 * float(_perm_rank("sp_atk")))
	for i in range(enemies.size() - 1, -1, -1):
		if player.distance_to(Vector2(enemies[i]["p"])) <= radius:
			if _coop_client(): online_lobby.request_hit(int(enemies[i].get("uid", -1)), power)
			else: _damage_enemy(i, power)
	for i in range(enemy_bullets.size() - 1, -1, -1):
		if player.distance_to(Vector2(enemy_bullets[i]["p"])) <= radius:
			enemy_bullets.remove_at(i)
	nova_cooldown = maxf(6.0, 17.0 - 1.55 * _rank("nova")) * _cooldown_factor()
	nova_flash_origin = player
	nova_flash_time = 0.42
	event_message = "METEOR NOVA!"
	event_timer = 1.0

func _upgrade_detail(id: String, next_rank: int) -> String:
	match id:
		"heal": return "Q • Restore %d HP instantly. Higher ranks increase healing and lower cooldowns so you can survive longer fights." % (26 + 13 * (next_rank - 1))
		"shield": return "R • Summon a ward that absorbs %d damage for several seconds. Later ranks make it tougher and last longer." % (36 + 21 * next_rank)
		"dash": return "SPACE • Burst forward while invulnerable. Higher ranks extend the dash and shorten its cooldown."
		"nova": return "F • Detonate a Meteor Nova for %d damage around you, clearing bullets and blasting nearby foes." % (48 + 36 * next_rank + 7 * _rank("power"))
		"power": return "Passive • Auto attacks gain +11 damage per rank, improving every creature signature attack."
		"rapid": return "Passive • Attack 13%% faster per rank, letting signature attacks fire much more often."
		"vitality": return "Passive • Gain +25 maximum HP and immediately restore 25 HP. Great for tankier runs."
		"multishot": return "Passive • Fire one additional projectile per volley, or enhance spread-style attacks."
	return "Upgrade your creature for this run."

func _offer_repertoire_choice() -> void:
	# This one-time permanent perk lets the player select an EXTRA unlocked
	# active skill, without consuming a level or advancing the XP meter.
	level_choices.clear()
	for id in ["heal", "shield", "nova"]:
		if _rank(id) == 0:
			level_choices.append(id)
	if level_choices.is_empty():
		return
	starting_bonus_choice = true
	state = "UPGRADE"
	_show_upgrade_screen()

func _offer_upgrades() -> void:
	state = "UPGRADE"
	level_choices.clear()
	var candidates: Array[String] = []
	for id in UPGRADE_POOL:
		if _rank(id) < int(MAX_RANKS[id]):
			candidates.append(id)
	# Guarantee early access to at least one active move.
	if level <= 3:
		var active: Array[String] = []
		for id in ["heal", "shield", "nova"]:
			if _rank(id) == 0 and candidates.has(id):
				active.append(id)
		if not active.is_empty():
			var first := active[rng.randi_range(0, active.size() - 1)]
			level_choices.append(first)
			candidates.erase(first)
	for n in range(3 - level_choices.size()):
		if candidates.is_empty(): break
		var pick := rng.randi_range(0, candidates.size() - 1)
		level_choices.append(candidates[pick])
		candidates.remove_at(pick)
	if level_choices.is_empty():
		max_hp += 10.0
		hp = minf(max_hp, hp + 25.0)
		state = "PLAY"
		event_message = "All skills mastered! +10 maximum HP"
		event_timer = 2.0
		return
	_show_upgrade_screen()

func _show_upgrade_screen() -> void:
	if is_instance_valid(upgrade_overlay):
		upgrade_overlay.queue_free()
	upgrade_overlay = Control.new()
	upgrade_overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	hud.add_child(upgrade_overlay)
	var dim := ColorRect.new()
	dim.color = Color(0.02, 0.05, 0.14, 0.84)
	dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	upgrade_overlay.add_child(dim)
	var back := _panel(upgrade_overlay, Rect2(96, 67, 960, 514), Color("12214a"), Color("71a7eb"), 5)
	var upgrade_header: String = "STARTING BONUS  •  CHOOSE A MOVE" if starting_bonus_choice else "LEVEL %d  •  CHOOSE AN UPGRADE" % level
	_text(back, upgrade_header, Rect2(20, 16, 920, 58), 32, Color("ffe27f"), HORIZONTAL_ALIGNMENT_CENTER)
	var upgrade_subtitle: String = "Repertoire: choose an extra starting move for this run." if starting_bonus_choice else "Choose one. Every upgrade lasts for this run only."
	_text(back, upgrade_subtitle, Rect2(20, 72, 920, 31), 17, Color("cbdaf8"), HORIZONTAL_ALIGNMENT_CENTER)
	var palettes := [Color("385f93"), Color("5f4a9a"), Color("3f776c")]
	for i in range(level_choices.size()):
		var id: String = level_choices[i]
		var next_rank := _rank(id) + 1
		var card := _panel(back, Rect2(26 + i * 302, 124, 286, 350), Color("18284d"), Color("aec8ff"), 4)
		var header := _panel(card, Rect2(12, 12, 262, 86), palettes[i], Color("f1d37f"), 3)
		_text(header, "✦", Rect2(9, 3, 244, 40), 36, Color("fff0a0"), HORIZONTAL_ALIGNMENT_CENTER)
		var type_line := "ACTIVE SKILL" if ["heal", "shield", "dash", "nova"].has(id) else "PASSIVE BOOST"
		_text(header, type_line, Rect2(8, 11, 246, 18), 11, Color("e6f1ff"), HORIZONTAL_ALIGNMENT_CENTER)
		_text(header, str(UPGRADE_NAMES[id]), Rect2(8, 31, 246, 32), 22, Color("fff0bc"), HORIZONTAL_ALIGNMENT_CENTER)
		_text(header, "RANK %d  →  %d" % [_rank(id), next_rank], Rect2(8, 60, 246, 18), 13, Color("d7fff0"), HORIZONTAL_ALIGNMENT_CENTER)
		var desc_back := _panel(card, Rect2(16, 112, 254, 146), Color("0d1733"), Color("6e8dc8"), 2)
		var desc := RichTextLabel.new()
		desc.position = Vector2(23, 119)
		desc.size = Vector2(238, 132)
		desc.fit_content = false
		desc.scroll_active = true
		desc.bbcode_enabled = false
		desc.text = _upgrade_detail(id, next_rank)
		desc.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		desc.add_theme_font_size_override("normal_font_size", 15)
		desc.add_theme_color_override("default_color", Color("f8fbff"))
		desc.add_theme_color_override("font_outline_color", Color("0a1027"))
		desc.add_theme_constant_override("outline_size", 1)
		desc.scroll_following = false
		card.add_child(desc)
		var footer := _panel(card, Rect2(16, 268, 254, 30), Color("162246"), Color("536ea9"), 2)
		var footer_text := "Upgrades this run only • stacks with creature signature"
		_text(footer, footer_text, Rect2(6, 3, 242, 22), 11, Color("cddfff"), HORIZONTAL_ALIGNMENT_CENTER)
		var choose := _button(card, "CHOOSE", Rect2(39, 306, 208, 36), "gold")
		choose.pressed.connect(_choose_upgrade.bind(id))

func _choose_upgrade(id: String) -> void:
	if state != "UPGRADE" or not level_choices.has(id):
		return
	move_ranks[id] = _rank(id) + 1
	if id == "vitality":
		max_hp += 25.0
		hp = minf(max_hp, hp + 25.0)
	if is_instance_valid(upgrade_overlay):
		upgrade_overlay.queue_free()
		upgrade_overlay = null
	state = "PLAY"
	starting_bonus_choice = false
	event_message = "%s improved to rank %d!" % [str(UPGRADE_NAMES[id]), _rank(id)]
	event_timer = 2.0

# Enemies draw a warning first, lock their aim, then resolve the move. These
# helpers use stored positions; no attack changes aim during its windup.
func _choose_enemy_pattern() -> String:
	var roll := rng.randf()
	if wave <= 1:
		return "line"
	if wave == 2:
		return "circle" if roll < 0.30 else "line"
	if wave == 3:
		return "fan" if roll < 0.21 else ("circle" if roll < 0.60 else "line")
	if wave <= 5:
		return "charge" if roll < 0.17 else ("fan" if roll < 0.47 else ("circle" if roll < 0.72 else "line"))
	return "charge" if roll < 0.24 else ("fan" if roll < 0.56 else ("circle" if roll < 0.81 else "line"))

func _begin_enemy_warning(enemy: Dictionary) -> void:
	var pattern := _choose_enemy_pattern()
	var from_pos: Vector2 = Vector2(enemy["p"]) + Vector2(0, -26)
	var locked_aim: Vector2 = player + Vector2(0, -21)
	var direction := (locked_aim - from_pos).normalized()
	if direction.length_squared() < 0.001:
		direction = Vector2.RIGHT
	enemy["pattern"] = pattern
	enemy["warning_from"] = from_pos
	enemy["warning_target"] = locked_aim if pattern != "charge" else player
	enemy["attack_dir"] = direction if pattern != "charge" else (player - Vector2(enemy["p"])).normalized()
	enemy["blast_radius"] = minf(110.0, 66.0 + 5.5 * float(wave - 1))
	enemy["shot_speed"] = minf(360.0, 185.0 + 16.0 * float(wave - 1))
	enemy["attack_damage"] = minf(40.0, 12.0 + 2.0 * float(wave - 1))
	enemy["fan_count"] = 5 if wave >= 7 else 3
	enemy["charge_speed"] = minf(670.0, 470.0 + 15.0 * float(wave - 1))
	enemy["charge_total"] = 0.52
	enemy["warning_total"] = maxf(0.84, 1.45 - 0.065 * float(wave - 1))
	if pattern == "circle":
		enemy["warning_total"] += 0.14
	if pattern == "charge":
		enemy["warning_total"] += 0.12
	enemy["warning_timer"] = float(enemy["warning_total"])
	enemy["fire_clock"] = maxf(1.5, rng.randf_range(2.6, 3.7) - float(wave - 1) * 0.13)

func _add_enemy_projectile(position: Vector2, direction: Vector2, enemy: Dictionary, fan: bool = false) -> void:
	if enemy_bullets.size() >= MAX_ENEMY_PROJECTILES:
		return
	var velocity: Vector2 = direction.normalized() * float(enemy["shot_speed"])
	var tint := Color("d998ff") if fan else Color("ff9072")
	enemy_bullets.append({"p": position, "v": velocity, "life": ATTACK_PATH_LENGTH / maxf(1.0, velocity.length()), "damage": float(enemy["attack_damage"]) * (0.82 if fan else 1.0), "radius": 7.0, "color": tint})

func _resolve_enemy_attack(enemy: Dictionary) -> void:
	var pattern: String = str(enemy.get("pattern", "line"))
	var from_pos: Vector2 = enemy.get("warning_from", Vector2(enemy["p"]) + Vector2(0, -26))
	var aim_dir: Vector2 = enemy.get("attack_dir", Vector2.RIGHT)
	match pattern:
		"circle":
			var center: Vector2 = enemy["warning_target"]
			var radius: float = float(enemy.get("blast_radius", 66.0))
			impact_effects.append({"p": center, "radius": radius, "remaining": BLAST_VISUAL_TIME, "total": BLAST_VISUAL_TIME})
			if player.distance_to(center + Vector2(0, 21)) <= radius:
				_apply_player_damage(float(enemy["attack_damage"]) * 1.3, true, true)
		"fan":
			var count: int = int(enemy.get("fan_count", 3))
			for index in range(count):
				var angle := (float(index) - float(count - 1) * 0.5) * 0.19
				_add_enemy_projectile(from_pos, aim_dir.rotated(angle), enemy, true)
		"charge":
			enemy["charge_timer"] = float(enemy.get("charge_total", 0.52))
			enemy["charge_hit"] = false
		_:
			_add_enemy_projectile(from_pos, aim_dir, enemy)

func _draw_warning_bar(start_pos: Vector2, direction: Vector2, distance: float, width: float, tint: Color, completion: float) -> void:
	var lateral := direction.orthogonal() * width * 0.5
	var end_pos := start_pos + direction * distance
	var alpha := 0.14 + 0.2 * completion + 0.05 * sin(time_alive * 11.0)
	var bright := Color(1.0, 0.97, 0.88, 0.48 + 0.28 * completion)
	draw_colored_polygon(PackedVector2Array([start_pos + lateral, end_pos + lateral, end_pos - lateral, start_pos - lateral]), Color(tint.r, tint.g, tint.b, alpha))
	draw_colored_polygon(PackedVector2Array([
		start_pos + lateral * 0.48,
		start_pos + direction * distance * completion + lateral * 0.18,
		start_pos + direction * distance * completion - lateral * 0.18,
		start_pos - lateral * 0.48
	]), Color(bright.r, bright.g, bright.b, 0.12 + 0.16 * completion))
	draw_line(start_pos + lateral, end_pos + lateral, Color(tint.r, tint.g, tint.b, 0.84), 2.0)
	draw_line(start_pos - lateral, end_pos - lateral, Color(tint.r, tint.g, tint.b, 0.84), 2.0)
	draw_line(start_pos, start_pos + direction * distance * completion, bright, 2.4)
	var segments: int = maxi(2, int(distance / 42.0))
	for i in range(segments + 1):
		var t := float(i) / float(segments)
		var pulse := 0.65 + 0.35 * sin(time_alive * 7.5 + t * 4.0)
		var marker_center := start_pos.lerp(end_pos, t)
		var half_tick := lateral.normalized() * (7.0 + 6.0 * completion * pulse)
		draw_line(marker_center - half_tick, marker_center + half_tick, Color(bright.r, bright.g, bright.b, 0.16 + 0.12 * pulse), 1.4)
	draw_circle(end_pos, width * 0.52, Color(tint.r, tint.g, tint.b, 0.12 + 0.08 * completion))
	draw_arc(end_pos, width * 0.52, -PI * 0.5, -PI * 0.5 + TAU * completion, 36, Color(bright.r, bright.g, bright.b, 0.9), 3.0)
	draw_circle(end_pos, 6.0 + width * 0.08, Color(bright.r, bright.g, bright.b, 0.35 + 0.15 * completion))

func _draw_enemy_warning(enemy: Dictionary) -> void:
	var warning_left: float = float(enemy.get("warning_timer", 0.0))
	if warning_left <= 0.0:
		return
	var total: float = maxf(0.01, float(enemy.get("warning_total", 1.0)))
	var completion := clampf(1.0 - warning_left / total, 0.0, 1.0)
	var pulse := 0.5 + 0.5 * sin(time_alive * 10.5)
	var pattern: String = str(enemy.get("pattern", "line"))
	var origin: Vector2 = enemy.get("warning_from", Vector2(enemy["p"]))
	var direction: Vector2 = enemy.get("attack_dir", Vector2.RIGHT)
	match pattern:
		"circle":
			var center: Vector2 = enemy["warning_target"]
			var radius := float(enemy.get("blast_radius", 66.0))
			draw_circle(center, radius, Color(1.0, 0.33, 0.25, 0.08 + 0.12 * completion + 0.05 * pulse))
			draw_arc(center, radius, 0.0, TAU, 72, Color("ff8f68"), 3.0)
			draw_arc(center, radius - 8.0, -PI * 0.5, -PI * 0.5 + TAU * completion, 72, Color("fff3bd"), 4.0)
			draw_arc(center, maxf(6.0, radius * 0.48), 0.0, TAU, 42, Color(1.0, 0.92, 0.78, 0.25 + 0.18 * pulse), 1.6)
			draw_line(center + Vector2(-12, 0), center + Vector2(12, 0), Color("ffe9d7"), 2.0)
			draw_line(center + Vector2(0, -12), center + Vector2(0, 12), Color("ffe9d7"), 2.0)
		"fan":
			var count: int = int(enemy.get("fan_count", 3))
			for index in range(count):
				var angle := (float(index) - float(count - 1) * 0.5) * 0.19
				_draw_warning_bar(origin, direction.rotated(angle), ATTACK_PATH_LENGTH, 44.0, Color("b66dff"), completion)
		"charge":
			var charge_range: float = float(enemy.get("charge_speed", 470.0)) * float(enemy.get("charge_total", 0.52))
			_draw_warning_bar(Vector2(enemy["p"]), direction, charge_range, 72.0, Color("ffad55"), completion)
		_:
			_draw_warning_bar(origin, direction, ATTACK_PATH_LENGTH, 44.0, Color("ff785d"), completion)

# Each enemy owns its gait and idle clock. Only its actual movement can turn it
# or advance its stride; no player input or player animation state is read.
func _update_enemy_walking(enemy: Dictionary, previous_position: Vector2, delta: float, charging: bool) -> void:
	var motion: Vector2 = Vector2(enemy["p"]) - previous_position
	var moving := motion.length_squared() > delta * delta
	enemy["is_walking"] = moving
	if moving and absf(motion.normalized().x) >= 0.12:
		enemy["facing_left"] = motion.x < 0.0
	enemy["walk_strength"] = move_toward(float(enemy.get("walk_strength", 0.0)), 1.0 if moving else 0.0, delta * 8.0)
	var phase: float = float(enemy.get("walk_phase", fposmod(float(enemy.get("uid", 0)) * 2.399963, TAU)))
	if moving:
		phase += delta * (19.0 if charging else 12.0)
	enemy["walk_phase"] = fposmod(phase, TAU)
	enemy["walk_clock"] = float(enemy.get("walk_clock", 0.0)) + delta

func _spawn_enemy() -> void:
	var angle := rng.randf_range(0.0, TAU)
	var position_spawn := (player + Vector2(cos(angle), sin(angle)) * rng.randf_range(360.0, 530.0)).clamp(Vector2(175, 255), WORLD - Vector2(175, 175))
	var enemy_id := _roll_creature_id()
	var form := "normal"
	var variant_roll := rng.randf()
	if variant_roll < BLESSED_CHANCE:
		form = "blessed"
	elif variant_roll < BLESSED_CHANCE + CORRUPT_CHANCE:
		form = "corrupt"
	if form != "normal":
		run_variants_seen += 1
		event_message = "RARE %s %s spotted! Hunt it down and extract!" % [form.to_upper(), str(CREATURES[enemy_id]["name"])]
		event_timer = 7.0
	var pressure := minf(22.0, float(wave - 1))
	var health := 34.0 + pressure * 11.0 + 2.0 * pow(pressure, 1.25)
	if form != "normal":
		health *= 1.20
	next_enemy_uid += 1
	var ranged_chance := minf(0.64, 0.25 + pressure * 0.035)
	enemies.append({"p": position_spawn, "id": enemy_id, "variant": form, "uid": next_enemy_uid,
		"walk_phase": fposmod(float(next_enemy_uid) * 2.399963, TAU),
		"walk_clock": fposmod(float(next_enemy_uid) * 0.618034, TAU), "walk_strength": 0.0,
		"is_walking": false, "facing_left": position_spawn.x > player.x,
		"hp": health, "max_hp": health, "speed": minf(179.0, 60.0 + pressure * 7.5),
		"contact_dps": minf(43.0, 16.0 + pressure * 2.3), "ranged": 1 if rng.randf() < ranged_chance else 0,
		"fire_clock": rng.randf_range(1.8, 3.5), "warning_timer": 0.0,
		"charge_timer": 0.0, "charge_hit": false})

func _start_run() -> void:
	ghost_reveal_pending = ""
	ghost_reveal_delay = 0.0
	ghost_report_buttons.clear()
	_discard_dev_console()
	if is_spinning or not (unlocked.get(selected_creature, false) if selected_variant == "normal" else variant_collection.get("%s|%s" % [selected_creature, selected_variant], false)):
		return
	player = EXTRACTION_POINT
	_generate_world()
	player_camera.position = player
	player_camera.reset_smoothing()
	enemies.clear()
	shots.clear()
	enemy_bullets.clear()
	impact_effects.clear()
	floating_damage_numbers.clear()
	projectile_grace = 0.0
	next_enemy_uid = 0
	chip_drops.clear()
	gold_drops.clear()
	xp_drops.clear()
	material_drops.clear()
	carried_materials.clear()
	run_damage_dealt = 0.0
	run_damage_taken = 0.0
	run_variants_seen = 0
	_dismiss_pause_overlay()
	player_facing_left = false
	player_is_moving = false
	run_stride_phase = 0.0
	run_pose_strength = 0.0
	footprints.clear()
	trail_clock = 0.0
	last_trail_position = player
	footstep_alternate = false
	run_xp_earned = 0
	xp_remainder = 0.0
	starting_bonus_choice = false
	pending_chips = 0
	pending_gold = 0
	run_midas_gold = 0
	midas_fraction = 0.0
	pending_variants.clear()
	event_message = ""
	event_timer = 0.0
	time_alive = 0.0
	spawn_clock = 0.0
	attack_clock = 0.0
	max_hp = 100.0 + 12.0 * float(_perm_rank("hp"))
	hp = max_hp
	hp_display_ratio = 1.0
	shield_hp = 0.0
	shield_time = 0.0
	dash_time = 0.0
	dash_invulnerability = 0.0
	heal_cooldown = 0.0
	shield_cooldown = 0.0
	dash_cooldown = 0.0
	nova_cooldown = 0.0
	nova_flash_time = 0.0
	last_move = Vector2.RIGHT
	move_ranks = {"dash": 1}
	_apply_signature_starting_bonuses()
	level_choices.clear()
	event_message = "%s • %s" % [str(CREATURES[selected_creature]["name"]), _signature_name(selected_creature)]
	event_timer = 2.6
	kills = 0
	level = 1
	xp = 0
	wave = 1
	state = "PLAY"
	menu_root.hide()
	game_info.show()
	ability_bar.show()
	_update_run_hud(0.0)
	for i in range(5):
		_spawn_enemy()
	if _perm_rank("repertoire") > 0:
		_offer_repertoire_choice()

func _run_summary(successful: bool, abandoned: bool) -> Dictionary:
	var variant_names: Array[String] = []
	for key in pending_variants.keys():
		var parts := str(key).split("|")
		if parts.size() == 2 and CREATURES.has(parts[0]):
			variant_names.append(str(CREATURES[parts[0]]["name"]) + " (" + parts[1].capitalize() + ")")
	variant_names.sort()
	return {
		"success": successful, "abandoned": abandoned,
		"creature": selected_creature, "form": selected_variant,
		"seconds": time_alive, "wave": wave, "level": level, "kills": kills,
		"xp_earned": run_xp_earned,
		"damage_dealt": run_damage_dealt, "damage_taken": run_damage_taken,
		"chips": pending_chips, "gold": pending_gold, "materials": carried_materials.duplicate(true),
		"midas_gold": run_midas_gold,
		"variants": variant_names, "variants_seen": run_variants_seen,
		"evo_xp": int(roundi(float(run_xp_earned) * 0.10))
	}

func _extract_run() -> void:
	variant_reveal_queue.clear()
	last_run_summary = _run_summary(true, false)
	poker_chips += pending_chips
	gold += pending_gold
	for id in MATERIAL_IDS:
		banked_materials[id] = int(banked_materials.get(id, 0)) + int(carried_materials.get(id, 0))
	for key in pending_variants.keys():
		variant_collection[key] = true
	var earned_evo_xp: int = int(last_run_summary["evo_xp"])
	if earned_evo_xp > 0:
		var record := _evo_record(selected_creature, selected_variant)
		record["xp"] = int(record["xp"]) + earned_evo_xp
		evolution_progress[_evo_key(selected_creature, selected_variant)] = record
	_save_collection()
	menu_message = "Extracted %d chips, %d gold (%d Midas bonus), %d materials, %d variants and %d evolution XP." % [pending_chips, pending_gold, run_midas_gold, _carried_material_count(), pending_variants.size(), earned_evo_xp]
	pending_chips = 0
	pending_gold = 0
	carried_materials.clear()
	pending_variants.clear()
	_show_run_results()

func _end_run(defeated: bool, force_ghost: bool = false) -> void:
	variant_reveal_queue.clear()
	# Only an actual death checks the 1/10,000 chance. Extracting or exiting
	# cannot create a Ghost; developer testing can bypass the chance, not ownership.
	ghost_reveal_pending = ""
	ghost_reveal_new = false
	ghost_reveal_delay = 0.0
	if defeated and (force_ghost or rng.randi_range(1, GHOST_DEATH_CHANCE) == 1):
		ghost_reveal_pending = selected_creature
		var ghost_key := "%s|ghost" % selected_creature
		ghost_reveal_new = not bool(variant_collection.get(ghost_key, false))
		variant_collection[ghost_key] = true
		ghost_reveal_delay = 2.8
		_save_collection() # Keep the permanent Ghost even if they close the game at the report.
	last_run_summary = _run_summary(false, not defeated)
	last_run_summary["ghost_awakened"] = not ghost_reveal_pending.is_empty()
	last_run_summary["ghost_new"] = ghost_reveal_new
	menu_message = "%s Lost %d chips, %d gold and %d materials, plus %d unextracted variants." % ["DEFEATED!" if defeated else "RUN ABANDONED!", pending_chips, pending_gold, _carried_material_count(), pending_variants.size()]
	pending_chips = 0
	pending_gold = 0
	carried_materials.clear()
	pending_variants.clear()
	_show_run_results()

func _start_ghost_reveal() -> void:
	if ghost_reveal_pending.is_empty() or is_instance_valid(ghost_reveal_overlay):
		return
	if state != "MENU" or menu_page != "run_result":
		return
	var creature_id := ghost_reveal_pending
	ghost_reveal_pending = ""
	ghost_reveal_delay = 0.0
	ghost_reveal_overlay = GHOST_REVEAL.new()
	ghost_reveal_overlay.call("setup", GHOST_PORTRAITS[creature_id], str(CREATURES[creature_id]["name"]), ghost_reveal_new)
	ghost_reveal_overlay.connect("reveal_finished", Callable(self, "_on_ghost_reveal_finished"))
	hud.add_child(ghost_reveal_overlay)

func _on_ghost_reveal_finished() -> void:
	if is_instance_valid(ghost_reveal_overlay):
		ghost_reveal_overlay.queue_free()
	ghost_reveal_overlay = null
	for button in ghost_report_buttons:
		if is_instance_valid(button):
			button.disabled = false
	ghost_report_buttons.clear()
	# The complete death report remains underneath, with all losses and stats.

func _roll_creature_id() -> String:
	var total_weight := 0.0
	for creature_id in CREATURES.keys():
		total_weight += float(CREATURES[creature_id]["weight"])
	var roll := rng.randf_range(0.0, total_weight)
	for creature_id in CREATURES.keys():
		roll -= float(CREATURES[creature_id]["weight"])
		if roll <= 0.0:
			return str(creature_id)
	return "koikoi"

func _normal_unlocked_count() -> int:
	var count := 0
	for id in CREATURES.keys():
		if unlocked.get(id, false):
			count += 1
	return count

func _has_trait(form: String, trait_name: String) -> bool:
	return trait_name in form.split("+", false)

func _form_world_texture(creature_id: String, form: String) -> Texture2D:
	if _has_trait(form, "shiny"):
		return SHINY_TEXTURES[creature_id]
	if _has_trait(form, "ghost"):
		return GHOST_TEXTURES[creature_id]
	if _has_trait(form, "gold"):
		return GOLD_TEXTURES[creature_id]
	return CREATURES[creature_id]["texture"]

func _form_portrait_texture(creature_id: String, form: String) -> Texture2D:
	if _has_trait(form, "shiny"):
		return SHINY_PORTRAITS[creature_id]
	if _has_trait(form, "ghost"):
		return GHOST_PORTRAITS[creature_id]
	if _has_trait(form, "gold"):
		return GOLD_PORTRAITS[creature_id]
	return CREATURES[creature_id]["portrait"]

func _form_color(form: String) -> Color:
	if _has_trait(form, "shiny"):
		return Color.WHITE  # Custom hand-painted shiny art must stay unmodified.
	match form:
		"corrupt":
			return Color(0.38, 0.32, 0.52)
		"blessed":
			return Color(1.0, 0.96, 0.78)
		"gold":
			return Color.WHITE # Gold artwork is already recolored.
		"ghost":
			return Color.WHITE # Ghost artwork is already spectral blue and translucent.
	return Color.WHITE

func _select_creature(creature_id: String, form: String = "normal") -> void:
	var can_use: bool = bool(unlocked.get(creature_id, false)) if form == "normal" else bool(variant_collection.get("%s|%s" % [creature_id, form], false))
	if not can_use or is_spinning:
		return
	selected_creature = creature_id
	selected_variant = form
	menu_message = "%s is now your playable creature." % str(CREATURES[creature_id]["name"])
	_save_collection()
	_rebuild_menu()

# Prefer still-locked creatures on a winning normal roll, without making the
# rarest monsters as common as the starter. The original rarity weights remain.
func _roll_locked_creature_id() -> String:
	var choices: Array[String] = []
	var total_weight := 0.0
	for id_key in CREATURES.keys():
		var id: String = str(id_key)
		if not bool(unlocked.get(id, false)):
			choices.append(id)
			total_weight += float(CREATURES[id]["weight"])
	if choices.is_empty():
		return _roll_creature_id()
	var roll := rng.randf() * total_weight
	for id in choices:
		roll -= float(CREATURES[id]["weight"])
		if roll <= 0.0:
			return id
	return choices[choices.size() - 1]

# Ten-pull safeguard applies to its final pull only if no new normal creature
# appeared on the prior nine pulls, and normal creatures remain locked.
func _prepare_spin_result() -> Dictionary:
	var guarantee_new := spin_batch_size in [10, 100] and spins_remaining == 1 and batch_new_normals == 0 and _normal_unlocked_count() < CREATURES.size()
	return _roll_slot_result(guarantee_new)

func _update_slot_pity(form: String) -> void:
	if form in ["blessed", "corrupt"]:
		slot_pulls_since_special = 0
	else:
		slot_pulls_since_special += 1
	if form == "gold":
		slot_pulls_since_gold = 0
	else:
		slot_pulls_since_gold += 1

func _roll_slot_result(force_new: bool = false) -> Dictionary:
	# Resolve variant rarity per pull before checking the ordinary three-of-a-kind chance.
	# This guarantees actual 1/1000 Gold, 1/100 Blessed and 1/100 Corrupt base chances.
	var form := "normal"
	if slot_pulls_since_gold >= SLOT_GOLD_PITY - 1:
		form = "gold"
	elif slot_pulls_since_special >= SLOT_VARIANT_PITY - 1:
		form = "blessed" if rng.randf() < 0.5 else "corrupt"
	else:
		var result := rng.randf()
		if result < SLOT_GOLD_CHANCE:
			form = "gold"
		elif result < SLOT_GOLD_CHANCE + SLOT_BLESSED_CHANCE:
			form = "blessed"
		elif result < SLOT_GOLD_CHANCE + SLOT_BLESSED_CHANCE + SLOT_CORRUPT_CHANCE:
			form = "corrupt"
	var triple := form != "normal" or force_new or rng.randf() < TRIPLE_CHANCE
	var ids: Array[String] = []
	if triple:
		var creature_id := _roll_locked_creature_id() if (force_new and form == "normal") or rng.randf() < NEW_CREATURE_BIAS else _roll_creature_id()
		ids = [creature_id, creature_id, creature_id]
	else:
		for reel_i in range(3):
			ids.append(_roll_creature_id())
		if ids[0] == ids[1] and ids[1] == ids[2]:
			var alternatives: Array = CREATURES.keys().filter(func(key): return str(key) != ids[2])
			ids[2] = str(alternatives[rng.randi_range(0, alternatives.size() - 1)])
	_update_slot_pity(form)
	return {"ids": ids, "id": ids[0] if triple else "", "form": form, "triple": triple, "gold": 0}

func _apply_spin_reward(reward: Dictionary) -> void:
	var ids: Array = reward["ids"]
	for reel_i in range(3):
		reel_ids[reel_i] = str(ids[reel_i])
	if bool(reward["triple"]):
		var creature_id: String = str(reward["id"])
		var form: String = str(reward["form"])
		var name: String = str(CREATURES[creature_id]["name"])
		if _owns_form(creature_id, form):
			var payout: int = _gold_reward(GOLD_DUPLICATE)
			reward["gold"] = payout
			gold += payout
			menu_message = "TRIPLE %s! Duplicate converted to %d gold." % [name, payout]
		else:
			if form == "normal":
				unlocked[creature_id] = true
				batch_new_normals += 1
			else:
				variant_collection["%s|%s" % [creature_id, form]] = true
			menu_message = "JACKPOT! NEW %s %s unlocked!" % [form.to_upper(), name]
	else:
		var payout: int = _gold_reward(GOLD_NO_MATCH)
		reward["gold"] = payout
		gold += payout
		menu_message = "No triple — collected %d gold." % payout
	spin_results.append(reward)
	if bool(reward["triple"]):
		_queue_variant_reveal(str(reward["id"]), str(reward["form"]), int(reward["gold"]) == 0,
			"slots", int(reward["gold"]), spin_batch_size - spins_remaining + 1, spin_batch_size)

# One queue drives all reward sources; only SLOT MACHINE duplicates skip
# ordinary Blessed/Corrupt reveals. Wild captures and hatches always celebrate
# any variant; Shiny includes stacked Shiny forms.
func _queue_variant_reveal(creature_id: String, form: String, is_new: bool, source: String, payout: int = 0, pull: int = 0, batch: int = 0) -> void:
	if not CREATURES.has(creature_id) or form == "normal":
		return
	var always_rare: bool = form.contains("shiny") or _has_trait(form, "gold") or _has_trait(form, "ghost")
	if source == "slots" and not is_new and not always_rare:
		return
	variant_reveal_queue.append({"id": creature_id, "form": form, "new": is_new, "source": source,
		"payout": payout, "pull": pull, "batch": batch})

func _show_next_variant_reveal() -> void:
	if is_instance_valid(variant_reveal_overlay) or is_instance_valid(gold_reveal_overlay) or is_instance_valid(ghost_reveal_overlay):
		return
	if is_spinning or variant_reveal_queue.is_empty():
		return
	var upcoming: Dictionary = variant_reveal_queue.pop_front()
	var creature_id: String = str(upcoming["id"])
	var form: String = str(upcoming["form"])
	# Preserve the existing custom Golden Jackpot for Gold slot rolls.
	if form == "gold" and str(upcoming["source"]) == "slots":
		gold_reveal_overlay = GOLD_REVEAL.new()
		gold_reveal_overlay.call("setup", GOLD_PORTRAITS[creature_id], str(CREATURES[creature_id]["name"]), bool(upcoming["new"]),
			int(upcoming["payout"]), int(upcoming["pull"]), int(upcoming["batch"]), variant_reveal_queue.size())
		gold_reveal_overlay.connect("reveal_finished", Callable(self, "_on_gold_reveal_finished"))
		hud.add_child(gold_reveal_overlay)
	else:
		variant_reveal_overlay = VARIANT_REVEAL.new()
		variant_reveal_overlay.call("setup", _form_portrait_texture(creature_id, form), str(CREATURES[creature_id]["name"]),
			form, bool(upcoming["new"]), str(upcoming["source"]), variant_reveal_queue.size(), int(upcoming["pull"]), int(upcoming["batch"]))
		variant_reveal_overlay.connect("reveal_finished", Callable(self, "_on_variant_reveal_finished"))
		hud.add_child(variant_reveal_overlay)

func _on_variant_reveal_finished() -> void:
	if is_instance_valid(variant_reveal_overlay):
		variant_reveal_overlay.queue_free()
	variant_reveal_overlay = null
	_show_next_variant_reveal()

func _on_gold_reveal_finished() -> void:
	if is_instance_valid(gold_reveal_overlay):
		gold_reveal_overlay.queue_free()
	gold_reveal_overlay = null
	_show_next_variant_reveal()

func _begin_spin(pull_count: int = 1) -> void:
	if is_spinning or is_instance_valid(gold_reveal_overlay) or is_instance_valid(variant_reveal_overlay) or not variant_reveal_queue.is_empty() or not [1, 10, 100].has(pull_count):
		return
	var total_cost: int = pull_count * SPIN_COST
	if poker_chips < total_cost:
		return
	poker_chips -= total_cost
	_save_collection()
	spin_results.clear()
	spin_batch_size = pull_count
	batch_new_normals = 0
	spins_remaining = pull_count
	is_spinning = true
	spin_duration = 1.50 if pull_count in [1, 100] else 0.72
	spin_timer = spin_duration
	spin_preview_clock = 0.0
	current_spin = _prepare_spin_result()
	menu_message = "Reels spinning..."
	_rebuild_menu()

func _update_slot_reels() -> void:
	if not is_spinning or current_spin.is_empty():
		return
	var stopping_time := [0.45, 0.25, 0.09]
	var final_ids: Array = current_spin["ids"]
	for reel_i in range(3):
		var final_id: String = str(final_ids[reel_i])
		var visible_id := final_id
		if spin_timer > spin_duration * float(stopping_time[reel_i]):
			visible_id = _roll_creature_id()
		reel_ids[reel_i] = visible_id
		if reel_i < slot_reels.size() and is_instance_valid(slot_reels[reel_i]):
			slot_reels[reel_i].texture = CREATURES[visible_id]["portrait"]
	if is_instance_valid(slot_status):
		slot_status.text = "REELS SPINNING...  %d PULL%s LEFT" % [spins_remaining, "" if spins_remaining == 1 else "S"]

func _finish_spin() -> void:
	if not is_spinning or current_spin.is_empty():
		return
	var reward: Dictionary = current_spin.duplicate(true)
	_apply_spin_reward(reward)
	spins_remaining -= 1
	if spin_batch_size == 100:
		# One reel animation finished. All remaining paid pulls resolve immediately.
		while spins_remaining > 0:
			_apply_spin_reward(_prepare_spin_result())
			spins_remaining -= 1
	_save_collection()
	if spins_remaining > 0:
		current_spin = _prepare_spin_result()
		spin_timer = spin_duration
		spin_preview_clock = 0.0
	else:
		is_spinning = false
		current_spin.clear()
		if spin_results.size() > 1:
			var new_count := 0
			var gold_total := 0
			for item in spin_results:
				gold_total += int(item["gold"])
				if bool(item["triple"]) and int(item["gold"]) == 0:
					new_count += 1
			menu_message = "x%d complete: %d new forms, %d gold earned!" % [spin_results.size(), new_count, gold_total]
	_rebuild_menu()
	_show_next_variant_reveal()

func _save_collection() -> void:
	var save_data := {
		"version": 11,
		"fov_percent": fov_percent,
		"banked_materials": banked_materials,
		"evolution_progress": evolution_progress,
		"permanent_upgrades": permanent_upgrades,
		"gold": gold,
		"poker_chips": poker_chips,
		"unlocked": unlocked,
		"selected_creature": selected_creature,
		"selected_variant": selected_variant,
		"variant_collection": variant_collection,
		"hatchery_unlocked": hatchery_unlocked,
		"hatchery_slots": hatchery_slots,
		"hatchery_last_wall_time": hatchery_last_wall_time,
		"slot_pulls_since_special": slot_pulls_since_special,
		"slot_pulls_since_gold": slot_pulls_since_gold
	}
	_write_collection_data(save_data)

func _write_collection_data(save_data: Dictionary) -> bool:
	var file := FileAccess.open(SAVE_PATH, FileAccess.WRITE)
	if file == null:
		push_warning("Could not write collection save: %s" % error_string(FileAccess.get_open_error()))
		return false
	file.store_string(JSON.stringify(save_data))
	file.flush()
	var saved_ok := file.get_error() == OK
	file.close()
	if not saved_ok:
		push_warning("Failed to finish writing local collection save.")
	return saved_ok

func _load_collection() -> void:
	var source_path := SAVE_PATH
	if not FileAccess.file_exists(source_path):
		var legacy_dir := OS.get_user_data_dir().get_base_dir().path_join("Forgotten Grove Prototype")
		var legacy_path := legacy_dir.path_join("forgotten_grove_collection.json")
		if FileAccess.file_exists(legacy_path):
			source_path = legacy_path
		else:
			return
	var file := FileAccess.open(source_path, FileAccess.READ)
	if file == null:
		return
	var data: Variant = JSON.parse_string(file.get_as_text())
	file.close()
	if not (data is Dictionary):
		return
	hatchery_unlocked = clampi(int(data.get("hatchery_unlocked", 1)), 1, HATCHERY_SLOT_COUNT)
	hatchery_last_wall_time = float(data.get("hatchery_last_wall_time", Time.get_unix_time_from_system()))
	var stored_hatchery: Variant = data.get("hatchery_slots", [])
	if stored_hatchery is Array:
		for n in range(mini(HATCHERY_SLOT_COUNT, stored_hatchery.size())):
			if stored_hatchery[n] is Dictionary:
				var record: Dictionary = stored_hatchery[n]
				var phase: String = str(record.get("phase", "idle"))
				if phase not in ["idle", "breeding", "egg", "ready"]:
					phase = "idle"
				var parents: Array = record.get("parents", [])
				var restored: Array = []
				for k in range(2):
					var raw_parent: Variant = parents[k] if k < parents.size() else {}
					if raw_parent is Dictionary and CREATURES.has(str(raw_parent.get("id", ""))):
						restored.append({"id": str(raw_parent.get("id", "koikoi")), "form": str(raw_parent.get("form", "normal"))})
					else:
						restored.append({"id": "koikoi", "form": "normal"})
				hatchery_slots[n] = {"parents": restored, "phase": phase,
					"remaining": maxf(0.0, float(record.get("remaining", 0.0))),
					"child_id": str(record.get("child_id", "")), "child_form": str(record.get("child_form", "normal"))}
	fov_percent = clampi(int(roundi(float(data.get("fov_percent", 100)) / 5.0)) * 5, FOV_MIN, FOV_MAX)
	poker_chips = maxi(0, int(data.get("poker_chips", 0)))
	gold = maxi(0, int(data.get("gold", 0)))
	var old_materials: Variant = data.get("banked_materials", {})
	if old_materials is Dictionary:
		for id in MATERIAL_IDS:
			banked_materials[id] = maxi(0, int(old_materials.get(id, 0)))
	var old_upgrades: Variant = data.get("permanent_upgrades", {})
	if old_upgrades is Dictionary:
		for species_id in old_upgrades.keys():
			if not CREATURES.has(str(species_id)) or not (old_upgrades[species_id] is Dictionary):
				continue
			var kept: Dictionary = {}
			for id in PERMANENT_UPGRADE_ORDER:
				kept[id] = clampi(int(old_upgrades[species_id].get(id, 0)), 0, int(PERMANENT_UPGRADES[id]["max"]))
			permanent_upgrades[str(species_id)] = kept
	var saved_evo: Variant = data.get("evolution_progress", {})
	if saved_evo is Dictionary:
		for key in saved_evo.keys():
			var tokens := str(key).split("|")
			if tokens.size() != 2 or not CREATURES.has(tokens[0]) or not OWNABLE_FORMS.has(tokens[1]):
				continue
			if saved_evo[key] is Dictionary:
				var record: Dictionary = saved_evo[key]
				var stage: int = clampi(int(record.get("stage", 0)), 0, 5)
				evolution_progress[str(key)] = {"stage": stage, "xp": maxi(0, int(record.get("xp", 0))), "equipped": clampi(int(record.get("equipped", stage)), 0, stage)}
	var saved_unlocked: Variant = data.get("unlocked", {})
	if saved_unlocked is Dictionary:
		for creature_id in CREATURES.keys():
			if saved_unlocked.get(creature_id, false) == true:
				unlocked[creature_id] = true
	unlocked["koikoi"] = true
	var saved_variants: Variant = data.get("variant_collection", {})
	if saved_variants is Dictionary:
		for key in saved_variants.keys():
			var parts := str(key).split("|")
			if parts.size() == 2 and CREATURES.has(parts[0]) and OWNABLE_FORMS.has(parts[1]) and parts[1] != "normal" and saved_variants[key] == true:
				variant_collection[key] = true
	var selected := str(data.get("selected_creature", "koikoi"))
	var saved_form := str(data.get("selected_variant", "normal"))
	slot_pulls_since_special = clampi(int(data.get("slot_pulls_since_special", 0)), 0, SLOT_VARIANT_PITY - 1)
	slot_pulls_since_gold = clampi(int(data.get("slot_pulls_since_gold", 0)), 0, SLOT_GOLD_PITY - 1)
	if CREATURES.has(selected):
		if saved_form == "normal" and unlocked.get(selected, false):
			selected_creature = selected
		elif variant_collection.get("%s|%s" % [selected, saved_form], false):
			selected_creature = selected
			selected_variant = saved_form
	if source_path != SAVE_PATH:
		_save_collection()  # Preserve existing progress under the new title.

func _draw() -> void:
	visible_world = get_canvas_transform().affine_inverse() * get_viewport_rect()
	visible_world = visible_world.grow(300.0)
	_draw_world_environment()
	if is_instance_valid(map_border):
		map_border.draw_border(self, visible_world, false)
	for prop in props:
		var p: Vector2 = prop["p"]
		if not visible_world.has_point(p):
			continue
		var scale_value: float = prop["size"]
		match int(prop["kind"]):
			0, 4:
				if state not in ["PLAY", "UPGRADE", "PAUSED"] or p.y <= player.y:
					_draw_obstacle_tree(prop)
			2:
				draw_line(p, p + Vector2(2, -10), Color("7faa61"), 2)
				draw_circle(p + Vector2(-3, -7), 2.5, Color("ffd274"))
				draw_circle(p + Vector2(4, -10), 4, Color("e6b769"))
				draw_circle(p + Vector2(8, -8), 2.2, Color("ffe8ac"))
			3:
				draw_circle(p, 9, Color("244e38"))
				draw_circle(p + Vector2(-3, -4), 6, Color("65965a"))
				draw_circle(p + Vector2(2, -2), 3, Color(0.92, 1.0, 0.8, 0.12))
	if state not in ["PLAY", "UPGRADE", "PAUSED"]:
		return
	_draw_footprints()
	if is_instance_valid(online_lobby):
		online_lobby.draw_teammates(self)
	for enemy in enemies:
		_draw_enemy_warning(enemy)
	for fx in impact_effects:
		var center: Vector2 = fx["p"]
		var radius: float = float(fx["radius"])
		var opacity := clampf(float(fx["remaining"]) / float(fx["total"]), 0.0, 1.0)
		draw_circle(center, radius * 1.08, Color(1.0, 0.34, 0.19, 0.14 * opacity))
		draw_circle(center, radius * 0.72, Color(1.0, 0.69, 0.36, 0.10 * opacity))
		draw_arc(center, radius * (1.08 - 0.08 * opacity), 0.0, TAU, 48, Color(1.0, 0.83, 0.48, 0.92 * opacity), 4.0)
		for spark_index in range(4):
			var spark_angle := time_alive * 4.0 + float(spark_index) * TAU / 4.0
			var from_pt := center + Vector2.RIGHT.rotated(spark_angle) * radius * 0.35
			var to_pt := center + Vector2.RIGHT.rotated(spark_angle) * radius * 0.82
			draw_line(from_pt, to_pt, Color(1.0, 0.91, 0.74, 0.42 * opacity), 1.6)
	for enemy in enemies:
		var p: Vector2 = enemy["p"]
		var enemy_form: String = str(enemy.get("variant", "normal"))
		_draw_shadow(p, 22, 7)
		var creature_center := p + Vector2(0, -28)
		AURA_FX.draw_back(self, creature_center, 39.0, enemy_form, time_alive)
		_draw_walking_creature(CREATURES[str(enemy["id"])]["texture"], p, 64.0, _form_color(enemy_form),
			float(enemy.get("walk_phase", 0.0)), float(enemy.get("walk_strength", 0.0)),
			float(enemy.get("walk_clock", 0.0)), bool(enemy.get("facing_left", false)))
		AURA_FX.draw_front(self, creature_center, 39.0, enemy_form, time_alive)
		if float(enemy.get("warning_timer", 0.0)) > 0.0:
			var total: float = maxf(0.01, float(enemy.get("warning_total", 1.0)))
			var complete := 1.0 - float(enemy["warning_timer"]) / total
			var marker_tint := Color("ffb75b") if str(enemy.get("pattern", "line")) == "charge" else Color("ff7a78")
			draw_arc(p + Vector2(0, -61), 16.0, -PI * 0.5, -PI * 0.5 + TAU * complete, 20, marker_tint, 4.0)
		var enemy_max_hp: float = float(enemy.get("max_hp", 34.0))
		if float(enemy.get("hp", enemy_max_hp)) < enemy_max_hp:
			draw_rect(Rect2(p + Vector2(-22, -77), Vector2(44, 5)), Color("11182f"))
			draw_rect(Rect2(p + Vector2(-21, -76), Vector2(42.0 * clampf(float(enemy["hp"]) / enemy_max_hp, 0.0, 1.0), 3)), Color("f07f77"))
	# Enemy damage numbers are drawn in world space so they follow the camera,
	# rise gently and fade after a fraction of a second. The labels do not block UI.
	var damage_font: Font = ThemeDB.fallback_font
	if damage_font != null:
		for number in floating_damage_numbers:
			var remaining: float = float(number["remaining"])
			var elapsed: float = 1.0 - remaining / DAMAGE_NUMBER_LIFETIME
			var alpha: float = clampf(remaining / 0.29, 0.0, 1.0)
			var number_text: String = str(number["text"])
			var number_size: int = 16 if number_text.begins_with("-") else 14
			var number_position: Vector2 = Vector2(number["p"]) + Vector2(0, -29.0 * elapsed)
			var text_width: float = damage_font.get_string_size(number_text, HORIZONTAL_ALIGNMENT_LEFT, -1, number_size).x
			number_position.x -= text_width * 0.5
			var tint: Color = number["tint"]
			draw_string_outline(damage_font, number_position, number_text, HORIZONTAL_ALIGNMENT_LEFT, -1, number_size, 3, Color(0.05, 0.07, 0.13, alpha * 0.84))
			draw_string(damage_font, number_position, number_text, HORIZONTAL_ALIGNMENT_LEFT, -1, number_size, Color(tint.r, tint.g, tint.b, alpha))
	var rare_position := Vector2.ZERO
	var rare_distance := INF
	var rare_form := ""
	for enemy in enemies:
		var form: String = str(enemy.get("variant", "normal"))
		if form == "normal":
			continue
		var distance := player.distance_squared_to(Vector2(enemy["p"]))
		if distance < rare_distance:
			rare_distance = distance
			rare_position = Vector2(enemy["p"])
			rare_form = form
	if rare_form != "":
		var arrow_direction := (rare_position - player).normalized()
		var pointer := player + arrow_direction * 130.0
		var pointer_color := Color("c58dff") if rare_form == "corrupt" else Color("fff4a7")
		draw_circle(pointer, 14.0, Color(pointer_color.r, pointer_color.g, pointer_color.b, 0.16))
		draw_colored_polygon(PackedVector2Array([
			pointer + arrow_direction * 13.0,
			pointer - arrow_direction * 9.0 + arrow_direction.orthogonal() * 10.0,
			pointer - arrow_direction * 9.0 - arrow_direction.orthogonal() * 10.0
		]), pointer_color)
	for material in material_drops:
		var p: Vector2 = Vector2(material["p"])
		var tint: Color = _material_color(str(material["id"]))
		var hover: float = sin(time_alive * 3.5 + float(material["phase"])) * 2.0
		var gem_center := p + Vector2(0, -10.0 + hover)
		_draw_shadow(p, 11.0, 4.0)
		draw_circle(gem_center, 12.0, Color(tint.r, tint.g, tint.b, 0.15))
		draw_colored_polygon(PackedVector2Array([
			gem_center + Vector2(0, -10), gem_center + Vector2(8, 0),
			gem_center + Vector2(0, 10), gem_center + Vector2(-8, 0)
		]), Color("142038"))
		draw_colored_polygon(PackedVector2Array([
			gem_center + Vector2(0, -7), gem_center + Vector2(6, 0),
			gem_center + Vector2(0, 7), gem_center + Vector2(-6, 0)
		]), tint)
		draw_line(gem_center + Vector2(-1, -5), gem_center + Vector2(1, -6), Color("ffffff"), 1.2)
	for chip in chip_drops:
		var p: Vector2 = chip["p"]
		_draw_shadow(p, 14, 5)
		draw_circle(p + Vector2(0, -11), 14, Color("2a282e"))
		draw_circle(p + Vector2(0, -13), 13, Color("ed6566"))
		draw_arc(p + Vector2(0, -13), 9, 0, TAU, 12, Color("ffebd1"), 3)
		draw_circle(p + Vector2(0, -13), 4, Color("fff5ce"))
	for coin in gold_drops:
		var coin_pos: Vector2 = coin["p"] + Vector2(0, -2.0 * sin(time_alive * 3.0 + float(coin["phase"])))
		draw_circle(coin_pos, 9.0, Color(0.34, 0.19, 0.04, 0.45))
		draw_circle(coin_pos + Vector2(0, -2), 6.8, Color("e39e25"))
		draw_circle(coin_pos + Vector2(-1, -3), 4.2, Color("ffe174"))
		draw_circle(coin_pos + Vector2(-2, -4), 1.3, Color("fff6c0"))
	for orb in xp_drops:
		var origin: Vector2 = orb["p"]
		var hover: float = sin(time_alive * 3.0 + float(orb["phase"])) * 2.7
		var p: Vector2 = origin + Vector2(0, -9 + hover)
		var core_tint := Color("c5a9ff") if int(orb["amount"]) >= 3 else Color("7df0d4")
		draw_circle(p, 11.0, Color(core_tint.r, core_tint.g, core_tint.b, 0.12))
		draw_colored_polygon(PackedVector2Array([p + Vector2(0, -9), p + Vector2(8, 0), p + Vector2(0, 8), p + Vector2(-8, 0)]), Color("125c65"))
		draw_colored_polygon(PackedVector2Array([p + Vector2(0, -7), p + Vector2(6, 0), p + Vector2(0, 6), p + Vector2(-6, 0)]), core_tint)
		draw_line(p + Vector2(-2, -4), p + Vector2(1, -5), Color("faffdf"), 1.6)
	_draw_player_shots(shots)
	for bullet in enemy_bullets:
		var bullet_pos: Vector2 = bullet["p"]
		var radius: float = float(bullet.get("radius", 7.0))
		var tint: Color = bullet.get("color", Color("f25aa1"))
		var velocity: Vector2 = bullet.get("v", Vector2.ZERO)
		var tail_dir := velocity.normalized() if velocity.length() > 0.01 else Vector2.DOWN
		draw_line(bullet_pos - tail_dir * radius * 2.8, bullet_pos, Color(tint.r, tint.g, tint.b, 0.34), maxf(2.0, radius * 0.7))
		draw_circle(bullet_pos, radius + 3.0, Color(tint.r, tint.g, tint.b, 0.16))
		draw_circle(bullet_pos, radius + 1.2, Color(tint.r, tint.g, tint.b, 0.35))
		draw_circle(bullet_pos, radius, tint)
		draw_circle(bullet_pos, 3.0, Color("fff7df"))
	if nova_flash_time > 0.0:
		var nova_factor := 1.0 - nova_flash_time / 0.42
		var nova_radius := (145.0 + 42.0 * _rank("nova")) * nova_factor
		draw_circle(nova_flash_origin, nova_radius, Color(0.96, 0.45, 0.22, 0.11 * (1.0 - nova_factor)))
		draw_arc(nova_flash_origin, nova_radius, 0.0, TAU, 60, Color(1.0, 0.7, 0.32, 0.95 - 0.7 * nova_factor), 7.0)
		draw_arc(nova_flash_origin, maxf(20.0, nova_radius * 0.78), 0.0, TAU, 48, Color(1.0, 0.93, 0.76, 0.55 - 0.4 * nova_factor), 2.4)
	var open_gate := time_alive >= EXTRACTION_UNLOCK_SECONDS
	var gate_center := EXTRACTION_POINT + Vector2(0, -12)
	var gate_color := Color("73e4fa") if open_gate else Color("52696a")
	draw_circle(gate_center, 82, Color(gate_color.r, gate_color.g, gate_color.b, 0.06))
	draw_arc(gate_center, 78, 0, TAU, 48, gate_color, 5)
	draw_circle(gate_center, 38, Color(0.12, 0.68, 0.82, 0.16) if open_gate else Color(0.1, 0.13, 0.15, 0.2))
	if open_gate:
		draw_arc(gate_center, 60, 0, TAU, 32, Color("cafcff"), 2)
		draw_arc(gate_center, 49, -PI * 0.5, -PI * 0.5 + TAU * (0.55 + 0.45 * sin(time_alive * 2.0) * 0.5 + 0.25), 28, Color(0.85, 1.0, 1.0, 0.8), 2.0)
	_draw_shadow(player, 28, 9)
	if shield_hp > 0.0 and shield_time > 0.0:
		var glow := 0.75 + 0.25 * sin(time_alive * 9.0)
		draw_circle(player + Vector2(0, -36), 63, Color(0.35, 0.76, 1.0, 0.12 * glow))
		draw_arc(player + Vector2(0, -36), 59, 0.0, TAU, 50, Color(0.52, 0.86, 1.0, 0.7 * glow), 4.0)
		for shield_index in range(4):
			var shield_angle := time_alive * 1.8 + TAU * float(shield_index) / 4.0
			var orb := player + Vector2(0, -36) + Vector2.RIGHT.rotated(shield_angle) * 58.0
			draw_circle(orb, 4.0, Color(0.85, 0.97, 1.0, 0.55))
	if dash_invulnerability > 0.0:
		draw_arc(player + Vector2(0, -30), 69, 0.0, TAU, 40, Color(0.6, 0.95, 1.0, 0.5), 3.0)
		draw_line(player + Vector2(-18, -42), player + Vector2(18, -18), Color(0.8, 1.0, 1.0, 0.22), 4.0)
	var player_texture: Texture2D = _form_world_texture(selected_creature, selected_variant)
	var player_center := player + Vector2(0, -39)
	AURA_FX.draw_back(self, player_center, 54.0, selected_variant, time_alive)
	_draw_walking_creature(player_texture, player, 95.0, _form_color(selected_variant),
		run_stride_phase, run_pose_strength, time_alive, player_facing_left)
	AURA_FX.draw_front(self, player_center, 54.0, selected_variant, time_alive)
	# Foreground canopies cover creatures walking behind them.
	for prop in props:
		if int(prop["kind"]) in [0, 4] and Vector2(prop["p"]).y > player.y and visible_world.has_point(prop["p"]):
			_draw_obstacle_tree(prop)
	if is_instance_valid(map_border):
		map_border.draw_border(self, visible_world, true)

func _draw_world_environment() -> void:
	draw_rect(Rect2(Vector2.ZERO, WORLD), Color("264736"))
	# Only draw terrain near the camera as the world grows.
	var left := maxi(0, floori(visible_world.position.x / 96.0) * 96)
	var top := maxi(0, floori(visible_world.position.y / 48.0) * 48)
	var right := mini(ceili(WORLD.x), ceili(visible_world.end.x))
	var bottom := mini(ceili(WORLD.y), ceili(visible_world.end.y))
	for x in range(left, right, 96):
		for y in range(top, bottom, 48):
			var noise := terrain_noise.get_noise_2d(float(x), float(y))
			var tint := Color("335840").lerp(Color("244b35"), clampf(noise * 0.8 + 0.5, 0.0, 1.0))
			draw_rect(Rect2(x, y, minf(96.0, WORLD.x - x), minf(48.0, WORLD.y - y)), tint)
	for patch in world_patches:
		var center: Vector2 = patch["p"]
		if visible_world.has_point(center):
			draw_circle(center, float(patch["radius"]), patch["tint"])
	for road in world_roads:
		for index in range(road.size() - 1):
			var bounds := Rect2(road[index], Vector2.ZERO).expand(road[index + 1]).grow(100.0)
			if visible_world.intersects(bounds):
				_draw_path_segment(road[index], road[index + 1], 100.0, Color("8b6d46"), Color("af9266"))
	for index in range(world_grass.size()):
		var point: Vector2 = world_grass[index]
		if visible_world.has_point(point):
			_draw_grass_clump(point, 0.8 + float(index % 3) * 0.16)

func _draw_path_segment(from_pos: Vector2, to_pos: Vector2, width: float, fill: Color, edge: Color) -> void:
	var direction := (to_pos - from_pos).normalized()
	var normal := direction.orthogonal() * width * 0.5
	draw_circle(from_pos, width * 0.5, fill)
	draw_circle(to_pos, width * 0.5, fill)
	draw_colored_polygon(PackedVector2Array([from_pos + normal, to_pos + normal, to_pos - normal, from_pos - normal]), fill)
	draw_line(from_pos + normal * 0.9, to_pos + normal * 0.9, Color(edge.r, edge.g, edge.b, 0.48), 2.0)
	draw_line(from_pos - normal * 0.9, to_pos - normal * 0.9, Color(fill.r * 0.7, fill.g * 0.7, fill.b * 0.7, 0.42), 2.0)
	var steps: int = maxi(1, int(from_pos.distance_to(to_pos) / 34.0))
	for i in range(steps + 1):
		var t := float(i) / float(steps)
		var center := from_pos.lerp(to_pos, t)
		var spot_offset := sin(t * 16.0 + float(i)) * width * 0.09
		draw_circle(center + normal.normalized() * spot_offset, 4.0 + 2.0 * float(i % 2), Color(1.0, 0.95, 0.85, 0.06))

func _draw_grass_clump(center: Vector2, scale_value: float) -> void:
	for blade in range(5):
		var offset := float(blade) - 2.0
		var start := center + Vector2(offset * 4.0 * scale_value, 0)
		var tip := start + Vector2(offset * 1.3, -10.0 - 4.0 * sin(time_alive * 0.7 + float(blade))) * scale_value
		draw_line(start, tip, Color("5d8d57"), 2.0)
		draw_line(start + Vector2(0, 1), tip, Color("8fba75"), 1.0)

# Shared visual style, with independent animation values supplied per creature.
# Only the sprite is transformed: shadows, collision, attacks and UI stay fixed.
func _draw_walking_creature(texture: Texture2D, feet: Vector2, max_dimension: float, tint: Color,
		phase: float, strength: float, idle_clock: float, facing_left: bool) -> void:
	var stride := sin(phase)
	var breath := sin(idle_clock * 2.35) * (1.0 - strength)
	var bob := -absf(stride) * 2.8 * strength - breath * 0.8
	var lean := stride * 0.036 * strength
	var squash := 1.0 + stride * 0.024 * strength + breath * 0.013
	var horizontal_scale := -1.0 if facing_left else 1.0
	horizontal_scale *= 1.0 - breath * 0.006
	draw_set_transform(feet + Vector2(0, bob), lean, Vector2(horizontal_scale, squash))
	_draw_creature(texture, Vector2.ZERO, max_dimension, tint)
	draw_set_transform(Vector2.ZERO)

func _draw_creature(texture: Texture2D, feet: Vector2, max_dimension: float, tint: Color = Color.WHITE) -> void:
	var natural_size := texture.get_size()
	var ratio := minf(max_dimension / natural_size.x, max_dimension / natural_size.y)
	var draw_size := natural_size * ratio
	var top_left := feet + Vector2(-draw_size.x * 0.5, -draw_size.y + 11.0)
	draw_texture_rect(texture, Rect2(top_left, draw_size), false, tint)

func _draw_shadow(p: Vector2, rx: float, ry: float) -> void:
	draw_set_transform(p, 0, Vector2(rx, ry))
	draw_circle(Vector2.ZERO, 1, Color(0.04, 0.09, 0.08, 0.35))
	draw_set_transform(Vector2.ZERO)

func _draw_player_shots(projectiles: Array) -> void:
	for shot in projectiles:
		var radius := float(shot.get("radius", 7.0))
		var shot_pos: Vector2 = shot["p"]
		var outer: Color = shot.get("outer", Color("f8dd89"))
		var inner: Color = shot.get("inner", Color.WHITE)
		var velocity: Vector2 = shot.get("v", Vector2.ZERO)
		var tail_dir := velocity.normalized() if velocity.length() > 0.01 else Vector2.UP
		draw_line(shot_pos - tail_dir * radius * 2.2, shot_pos, Color(outer.r, outer.g, outer.b, 0.34), maxf(2.0, radius * 0.55))
		draw_circle(shot_pos, radius + 2.5, Color(outer.r, outer.g, outer.b, 0.18))
		draw_circle(shot_pos, radius, outer)
		draw_circle(shot_pos, maxf(2.0, radius * 0.45), inner)
		if float(shot.get("aoe", 0.0)) > 0.0:
			draw_arc(shot_pos, radius + 4.0, 0.0, TAU, 20, Color(outer.r, outer.g, outer.b, 0.52), 2.2)

func _coop_visual_state() -> Dictionary:
	var projectiles: Array = []
	for shot in shots.slice(maxi(0, shots.size() - 32)):
		projectiles.append({"p": shot["p"], "v": shot["v"], "life": shot["life"], "radius": shot.get("radius", 7.0),
			"outer": shot.get("outer", Color.WHITE), "inner": shot.get("inner", Color.WHITE), "aoe": shot.get("aoe", 0.0)})
	return {"shots": projectiles, "stride": run_stride_phase, "pose": run_pose_strength, "left": player_facing_left,
		"shield": shield_time if shield_hp > 0.0 else 0.0, "dash": dash_invulnerability,
		"power": _creature_attack_power(), "nova": nova_flash_time, "nova_p": nova_flash_origin, "nova_rank": _rank("nova")}

func _draw_coop_visuals(visual: Dictionary, position: Vector2, age: float) -> void:
	if age > 0.5: return
	var projectiles: Array = []
	for original in visual.get("shots", []):
		if float(original.get("life", 0.0)) <= age: continue
		var shot: Dictionary = original.duplicate()
		shot["p"] = Vector2(shot["p"]) + Vector2(shot["v"]) * age
		projectiles.append(shot)
	_draw_player_shots(projectiles)
	if float(visual.get("shield", 0.0)) > age:
		draw_circle(position + Vector2(0, -36), 63, Color(0.35, 0.76, 1.0, 0.12))
		draw_arc(position + Vector2(0, -36), 59, 0.0, TAU, 50, Color(0.52, 0.86, 1.0, 0.7), 4.0)
	if float(visual.get("dash", 0.0)) > age:
		draw_arc(position + Vector2(0, -30), 69, 0.0, TAU, 40, Color(0.6, 0.95, 1.0, 0.5), 3.0)
	var nova_left: float = float(visual.get("nova", 0.0)) - age
	if nova_left > 0.0:
		var factor: float = 1.0 - nova_left / 0.42
		var radius: float = (145.0 + 42.0 * int(visual.get("nova_rank", 0))) * factor
		draw_arc(visual.get("nova_p", position), radius, 0.0, TAU, 60, Color(1.0, 0.7, 0.32, 0.95 - 0.7 * factor), 7.0)
