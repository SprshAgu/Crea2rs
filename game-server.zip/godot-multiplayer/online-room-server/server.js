'use strict';
// Prototype for private friends: use a reverse proxy with HTTPS/WSS, rate limits,
// authenticated ownership and container isolation before public deployment.
const http = require('node:http');
const https = require('node:https');
const fs = require('node:fs');
const path = require('node:path');
const net = require('node:net');
const crypto = require('node:crypto');
const { spawn } = require('node:child_process');
const proxy = require('http-proxy').createProxyServer({ws:true});
const PORT = Number(process.env.PORT || 3000);
const GODOT = process.env.GODOT_BIN || 'godot';
const PROJECT = path.resolve(process.env.GODOT_PROJECT || '..');
const STATIC = path.resolve(process.env.WEB_DIR || '../web');
const PUBLIC_ORIGIN = String(process.env.PUBLIC_ORIGIN || process.env.RENDER_EXTERNAL_URL || `http://localhost:${PORT}`).replace(/\/$/, '');
const MAX_ROOMS = Number(process.env.MAX_ROOMS || 20);
const ALLOWED_ORIGIN = String(process.env.ALLOWED_ORIGIN || PUBLIC_ORIGIN).replace(/\/$/, '');
const ROOM_TTL = Number(process.env.ROOM_TTL_MS || 90 * 60 * 1000);
const rooms = new Map();
const activeSockets = new Map();
const mime = { '.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.wasm':'application/wasm','.pck':'application/octet-stream','.png':'image/png','.webp':'image/webp','.css':'text/css','.svg':'image/svg+xml','.ico':'image/x-icon' };
function send(res, code, data) { res.writeHead(code, {'content-type':'application/json; charset=utf-8','cache-control':'no-store','access-control-allow-origin':ALLOWED_ORIGIN,'vary':'Origin'}); res.end(JSON.stringify(data)); }
function pickPort() { return new Promise((resolve,reject) => { const s = net.createServer(); s.once('error',reject); s.listen(0,'127.0.0.1',()=> {const port=s.address().port;s.close(()=>resolve(port));});});}
function wsAddress(req){ const host=PUBLIC_ORIGIN.replace(/^https?:\/\//,''); return `${PUBLIC_ORIGIN.startsWith('https:')?'wss':'ws'}://${host}/ws/${req}`; }
function cleanup(code) { const r=rooms.get(code); if(!r)return; rooms.delete(code); try{r.child.kill('SIGTERM')}catch{} for(const socket of (activeSockets.get(code)||[])) socket.destroy();activeSockets.delete(code); }
async function createRoom() {
 if(rooms.size >= MAX_ROOMS) throw Error('All dungeon rooms are currently in use.');
 let code; for(let i=0;i<100;i++){let candidate=String(crypto.randomInt(0,10000)).padStart(4,'0'); if(!rooms.has(candidate)){code=candidate;break;}}
 if(!code) throw Error('No free room code available.');
 const port=await pickPort(), token=crypto.randomBytes(24).toString('hex');
 const child=spawn(GODOT,['--headless','--path',PROJECT,'--','--room-server',`--port=${port}`,`--token=${token}`],{cwd:PROJECT,stdio:['ignore','pipe','pipe']});
 const r={code,port,token,child,ready:false,created:Date.now()}; rooms.set(code,r);
 child.stdout.on('data',b=> { const msg=String(b); if(msg.includes('ROOM SERVER READY'))r.ready=true; process.stdout.write(`[room ${code}] ${msg}`); });
 child.stderr.on('data',b=>process.stderr.write(`[room ${code}] ${String(b)}`));
 child.on('error',err=> {console.error(`Godot launch failure ${code}:`,err);cleanup(code);});
 child.on('exit',()=>cleanup(code));
 // Return only after Godot has opened its WebSocket listener.
 await new Promise((resolve,reject)=>{
   const started=Date.now();
   const timer=setInterval(()=>{
     if(!rooms.has(code)){clearInterval(timer);reject(Error('Godot room process exited before startup'));}
     else if(r.ready){clearInterval(timer);resolve();}
     else if(Date.now()-started>30000){clearInterval(timer);cleanup(code);reject(Error('Godot room startup timed out'));}
   },100);
 });
 return {code, owner_token:token,websocket_url:wsAddress(code)};
}
const server=http.createServer(async(req,res)=> {
 const u = new URL(req.url, 'http://localhost');
 if(req.method==='OPTIONS'){res.writeHead(204,{'access-control-allow-origin':ALLOWED_ORIGIN,'access-control-allow-methods':'GET, POST, OPTIONS','access-control-allow-headers':'Content-Type','vary':'Origin'});return res.end();}
 if(u.pathname==='/api/health') return send(res,200,{ok:true,rooms:rooms.size});
 if(u.pathname==='/api/rooms' && req.method==='POST'){
   try{return send(res,201,await createRoom());}catch(e){return send(res,503,{error:e.message});}
 }
 const m=u.pathname.match(/^\/api\/rooms\/(\d{4})$/);
 if(m && req.method==='GET'){
   const r=rooms.get(m[1]);
   if(!r)return send(res,404,{error:'Room not found. Check the four-digit code.'});
   return send(res,200,{code:r.code,websocket_url:wsAddress(r.code)});
 }
 if(req.method!=='GET' && req.method!=='HEAD')return send(res,405,{error:'Unsupported request'});
 const requested=u.pathname==='/'?'/index.html':decodeURIComponent(u.pathname);
 const file=path.resolve(STATIC, '.'+requested);
 if(!file.startsWith(STATIC+path.sep))return send(res,403,{error:'Forbidden'});
 fs.stat(file,(err,stat)=>{
  if(err||!stat.isFile())return send(res,404,{error:'Web export not yet installed. Export Godot Web build into the web folder.'});
  res.setHeader('content-type',mime[path.extname(file)]||'application/octet-stream');
  // single-threaded Godot web export does not need cross-origin isolation
  const stream=fs.createReadStream(file);stream.on('error',()=>res.destroy());stream.pipe(res);
 });
});
server.on('upgrade',(req,socket,head)=> {
 const m=new URL(req.url,'http://localhost').pathname.match(/^\/ws\/(\d{4})$/);
 if(!m || !rooms.has(m[1]))return socket.destroy();
 const code=m[1],room=rooms.get(code);
 if(Date.now()-room.created>ROOM_TTL)return socket.destroy();
 const set=activeSockets.get(code)||new Set();set.add(socket);activeSockets.set(code,set);
 socket.on('close',()=>set.delete(socket));
 proxy.ws(req,socket,head,{target:`ws://127.0.0.1:${room.port}`});
});
proxy.on('error',(err,req,socket)=> {console.error('WebSocket proxy:',err.message);try{socket.destroy()}catch{}});
setInterval(()=>{for(const [code,r] of rooms)if(Date.now()-r.created>ROOM_TTL)cleanup(code)},30000).unref();
server.listen(PORT,'0.0.0.0',()=>console.log(`Crea2rs room service on :${PORT}; web=${STATIC}; godot=${GODOT}`));
